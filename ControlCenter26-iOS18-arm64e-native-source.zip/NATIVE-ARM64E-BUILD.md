# Native arm64e build

This source copy targets the iPhone XS Max on iOS 18.6 with rootless Dopamine. All Theos subprojects are configured for `arm64e` only. The Debian package still uses the normal rootless `iphoneos-arm64` package tag; the workflow checks that every Mach-O file inside the package is an `arm64e`-only slice.

The workflow is manual. After this source is placed in a GitHub repository, open **Actions → Build rootless arm64e package → Run workflow**. Download the `.deb` from that run's **Artifacts** section.

The workflow installs Theos and standard packaging tools on a macOS runner with Xcode, builds the package, checks the package tag and each Mach-O slice, and uploads the resulting `.deb`. It does not install the package on the phone. Install only after the phone has recovered from any prior SpringBoard crash and you have a way to disable the tweak if needed.

The connectivity layout now enters its expanded state only when Control Center reports that the module is expanded. Ordinary layout dimensions no longer trigger the expanded page's spring animation during SpringBoard startup.
