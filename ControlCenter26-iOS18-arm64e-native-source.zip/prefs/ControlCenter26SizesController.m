#import "ControlCenter26SizesController.h"
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>

static NSString *const kSizesDomain = @"com.controlcenter26.preferences";

// The pane's own strings come from the preference bundle's Localizable.strings, keyed by English.
static NSString *CC26SizesString(NSString *english) {
    NSBundle *bundle = [NSBundle bundleForClass:ControlCenter26SizesController.class];
    return [bundle localizedStringForKey:english value:english table:nil];
}

// "com.apple.mediaremote.controlcenter.nowplaying" → "Nowplaying"; "…Module" endings are dropped.
static NSString *CC26SizesModuleTitle(NSString *mid) {
    NSString *last = [mid componentsSeparatedByString:@"."].lastObject;
    if (last.length > 6 && [last.lowercaseString hasSuffix:@"module"]) {
        last = [last substringToIndex:last.length - 6];
    }
    return last.length ? last.capitalizedString : mid;
}

// "2x2" → "2×2" for display.
static NSString *CC26SizesDisplay(NSString *size) {
    return [size stringByReplacingOccurrencesOfString:@"x" withString:@"×"];
}

// The sizes a module can be given (1 to 4 cells a side); "" keeps the stock size.
static NSArray<NSString *> *CC26SizesOptions(void) {
    return @[@"1x1", @"2x1", @"2x2", @"3x2", @"4x2"];
}

@implementation ControlCenter26SizesController

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *specs = [NSMutableArray array];

        id raw = CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("KnownModules"),
                                                             (__bridge CFStringRef)kSizesDomain));
        NSDictionary<NSString *, NSString *> *known = [raw isKindOfClass:NSDictionary.class] ? raw : @{};

        NSMutableArray<NSString *> *mids = [NSMutableArray array];
        for (NSString *mid in [known.allKeys sortedArrayUsingSelector:@selector(compare:)]) {
            // The connectivity page is the tweak's own; its tiles are not sized here.
            if ([mid.lowercaseString containsString:@"connectivitymodule"]) continue;
            [mids addObject:mid];
        }

        PSSpecifier *group = [PSSpecifier groupSpecifierWithName:CC26SizesString(@"Modules")];
        if (mids.count) {
            [group setProperty:CC26SizesString(@"Choose a size for each module. Stock keeps iOS's size. Respring to apply the change.")
                        forKey:@"footerText"];
        } else {
            [group setProperty:CC26SizesString(@"Open Control Center once so its modules are listed here, then come back.")
                        forKey:@"footerText"];
        }
        [specs addObject:group];

        NSArray<NSString *> *options = CC26SizesOptions();
        for (NSString *mid in mids) {
            NSString *stock = known[mid];
            NSMutableArray *titles = [NSMutableArray arrayWithObject:
                [NSString stringWithFormat:@"%@ (%@)", CC26SizesString(@"Stock"), CC26SizesDisplay(stock)]];
            NSMutableArray *values = [NSMutableArray arrayWithObject:@""];
            for (NSString *size in options) {
                [titles addObject:CC26SizesDisplay(size)];
                [values addObject:size];
            }

            PSSpecifier *spec = [PSSpecifier preferenceSpecifierNamed:CC26SizesModuleTitle(mid)
                                                               target:self
                                                                  set:@selector(setPreferenceValue:specifier:)
                                                                  get:@selector(readPreferenceValue:)
                                                               detail:NSClassFromString(@"PSListItemsController")
                                                                 cell:PSLinkListCell
                                                                 edit:nil];
            [spec setProperty:[@"Size." stringByAppendingString:mid] forKey:@"key"];
            [spec setProperty:kSizesDomain forKey:@"defaults"];
            [spec setProperty:@"" forKey:@"default"];
            [spec setProperty:titles forKey:@"validTitles"];
            [spec setProperty:values forKey:@"validValues"];
            [specs addObject:spec];
        }

        _specifiers = specs;
    }
    return _specifiers;
}

@end
