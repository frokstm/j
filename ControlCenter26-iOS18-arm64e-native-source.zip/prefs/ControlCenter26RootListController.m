#import "ControlCenter26RootListController.h"
#import <Preferences/PSSpecifier.h>
#import <spawn.h>
#import <unistd.h>
#import "ApelinBootstrap.h"

// Settings' own string for a label iOS already shows, from the Settings app's table;
// /Applications never moves, on roothide or rootless.
static NSString *CC26PrefsSystemString(NSString *english) {
    static NSDictionary<NSString *, NSArray<NSString *> *> *map;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        map = @{ @"General": @[@"/Applications/Preferences.app", @"Localizable", @"General"] };
    });
    NSArray<NSString *> *e = map[english];
    if (!e) return nil;
    NSBundle *bundle = [NSBundle bundleWithPath:e[0]];
    NSString *missing = @"\001CC26_MISSING";
    NSString *s = [bundle localizedStringForKey:e[2] value:missing table:e[1]];
    return (s.length && ![s isEqualToString:missing]) ? s : nil;
}

// Root.plist keeps its English text; the bundle's Localizable.strings translates it.
static NSString *CC26PrefsString(NSString *english) {
    if (!english.length) return english;
    NSString *s = CC26PrefsSystemString(english);
    if (s) return s;
    NSBundle *bundle = [NSBundle bundleForClass:NSClassFromString(@"ControlCenter26RootListController")];
    return [bundle localizedStringForKey:english value:english table:nil];
}

@implementation ControlCenter26RootListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
        for (PSSpecifier *spec in _specifiers) {
            if (spec.name.length) spec.name = CC26PrefsString(spec.name);
            id footer = [spec propertyForKey:@"footerText"];
            if ([footer isKindOfClass:NSString.class]) {
                [spec setProperty:CC26PrefsString(footer) forKey:@"footerText"];
            }
        }
    }
    return _specifiers;
}

- (void)respring {
    pid_t pid;
    const char *args[] = { "killall", "-9", "SpringBoard", NULL };
    NSString *killall = ApelinBootstrapPath(@"/usr/bin/killall");
    if (!killall) return;
    posix_spawn(&pid, killall.fileSystemRepresentation, NULL, NULL, (char *const *)args, NULL);
}

@end
