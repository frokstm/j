#import <Preferences/PSListController.h>

// Settings ▸ ControlCenter26 ▸ Module Sizes: one row per module Control Center has shown,
// each with a size picker. The choice is stored as "Size.<module id>" in the tweak's domain.
@interface ControlCenter26SizesController : PSListController
@end
