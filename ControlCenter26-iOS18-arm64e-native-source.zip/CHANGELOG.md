# Changelog

## 1.2.5 — native arm64e build
- Set every Theos target and the Apelin rootless build path to arm64e only.
- Use a native macOS/Xcode GitHub Actions workflow to produce the iOS 18 rootless package.
- Gate the expanded Connectivity layout on Control Center's expanded-module state, avoiding an accidental startup spring animation from ordinary view dimensions.

## 1.2.0 — iOS 18 port target
- Set package support to iOS 18.x.
- Set Theos and Apelin build configurations to rootless arm64 only.
- Corrected the Theos source list to match the files in this source archive and added the separate Settings tweak target.
- Runtime compatibility is not yet confirmed on a device; build and install validation remain outstanding.

## 1.1

### Landscape
- Control Center pages its modules by column in landscape, like iOS 26. Swipe left or right to move between pages; it returns to the first page when you rotate.
- The Connectivity page uses the same wide layout as the expanded Connectivity module.
- The Music page and the expanded Music module use a wide card in landscape: artwork on the left, controls on the right.
- Fixed the sizes of the expanded Connectivity and Music modules in landscape.
- Fixed dark boxes behind some modules in landscape.
- Notched screens are detected the same way in both orientations.

### Connectivity module
- Removed the extra glass from Connectivity buttons that are off.

### Packaging
- Package `com.controlcenter26` 1.1 for roothide (arm64e) and rootless (arm64 and arm64e).
- Depends on ellekit or mobilesubstrate, CCSupport (`com.opa334.ccsupport`) and PreferenceLoader.

## 0.0.8a

### Connectivity module
- Expanding and folding the module now starts from the tile's real on-screen rect, so the animation no longer jumps.
- Collapsing puts the Airplane, Wi-Fi and AirDrop buttons in place at once and only fades them in, so the Wi-Fi button no longer slides to the wrong spot and snaps.
- The stock cellular glyph is hidden at its enlarged size, so no oversized glyph shows through.
- Settings opens from the + button without the long lag: Control Center closes first and Settings opens through SpringBoard.

### Page icons (right edge)
- While a page icon is held or dragged, scrolling of the pages is locked, so the pages no longer shift under the icon.
- Icons ignore touches while Control Center is already scrolling, so a running scroll is not cut off halfway.
- The scroll lock is released when the touch ends outside the icon or Control Center closes mid-hold.

### Media module
- Artwork and AirPlay/routing backgrounds use grey plates over light wallpaper, for readable text.

### Known issues
- A page icon can still disappear in some conditions. Not yet reproduced; a swipe made within about one second after releasing an icon is not blocked.

### Packaging
- Package `com.controlcenter26` 0.0.8a for roothide and rootless (arm64e).
- Depends on ellekit or mobilesubstrate, CCSupport (`com.opa334.ccsupport`) and PreferenceLoader.
