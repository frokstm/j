ControlCenter26 adds an iOS 26-inspired Control Center with custom pages, modules, menus, and animations. It can integrate with Liquid (Gl)ass by winaviation. The project is based on CCock18, with base code by Pawxed (Max); thanks to Lionel for help with development.

## iOS 18 port target

- Target device: iPhone XS Max, iOS 18.6, rootless Dopamine.
- Build architecture: arm64e only. No arm64 slice is produced.
- Package firmware range: iOS 18.0 through 18.x.
- The source has been adjusted for this target but still needs a build and on-device compatibility pass before calling the port complete.
- Use an iOS 18-compatible CCSupport build for the custom Control Center modules; older builds may lose modules after a reboot or SpringBoard restart.

The rootless build is intended to run on macOS with Apple's Xcode toolchain. Use `.github/workflows/build-arm64e.yml` to create and verify the package. Rootless Debian packages use the `iphoneos-arm64` package architecture tag even when the included Mach-O binaries contain only the arm64e slice.
