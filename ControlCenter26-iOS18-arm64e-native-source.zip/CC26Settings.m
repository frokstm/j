// Settings ▸ Control Center (com.apple.Preferences): pages in the "Included Controls" list.
//
// The page dividers (modulebundles/PageBreak.m, ids com.controlcenter26.module.page2…4) are always
// in the included list, drawn as small "PAGE 2" header rows that cannot be removed. Drag a control
// below a header to put it on that page; SpringBoard (CC26Edit.m) lays every module after a divider
// out on the next page. Dividers never show under "More Controls". Labels follow the order, so the
// first header is always "Page 2".
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <substrate.h>

static NSString *const kCC26DividerPrefix = @"com.controlcenter26.module.page";
static const void *kCC26DividerCellKey = &kCC26DividerCellKey;

static BOOL CC26SIsDivider(id mid) {
    return [mid isKindOfClass:NSString.class] && [(NSString *)mid hasPrefix:kCC26DividerPrefix];
}

static NSArray<NSString *> *CC26SDividerIDs(void) {
    return @[ @"com.controlcenter26.module.page2", @"com.controlcenter26.module.page3",
              @"com.controlcenter26.module.page4" ];
}

static NSString *CC26SPageTitle(NSUInteger page) {
    NSString *lang = NSLocale.preferredLanguages.firstObject ?: @"en";
    NSString *fmt = @"PAGE %lu";
    if ([lang hasPrefix:@"ja"]) fmt = @"ページ %lu";
    else if ([lang hasPrefix:@"zh-Hans"] || [lang hasPrefix:@"zh-CN"]) fmt = @"第 %lu 页";
    else if ([lang hasPrefix:@"zh"]) fmt = @"第 %lu 頁";
    return [NSString stringWithFormat:fmt, (unsigned long)page];
}

static NSMutableArray *CC26SIvarArray(id self, const char *name) {
    Ivar iv = class_getInstanceVariable(object_getClass(self), name);
    if (!iv) return nil;
    id v = object_getIvar(self, iv);
    return [v isKindOfClass:NSMutableArray.class] ? v : nil;
}

static NSString *CC26SIdentifierAt(id self, NSIndexPath *ip) {
    if (![self respondsToSelector:@selector(_identifierAtIndexPath:)]) return nil;
    id mid = ((id (*)(id, SEL, id))objc_msgSend)(self, @selector(_identifierAtIndexPath:), ip);
    return [mid isKindOfClass:NSString.class] ? mid : nil;
}

#pragma mark - Hooks

static void (*orig_repopulate)(id, SEL);
static void hook_repopulate(id self, SEL _cmd) {
    orig_repopulate(self, _cmd);
    NSMutableArray *enabled = CC26SIvarArray(self, "_enabledIdentifiers");
    NSMutableArray *disabled = CC26SIvarArray(self, "_disabledIdentifiers");
    for (NSString *mid in CC26SDividerIDs()) {
        [disabled removeObject:mid];
        if (enabled && ![enabled containsObject:mid]) [enabled addObject:mid];
    }
}

static NSMutableArray *(*orig_specifiersForIDs)(id, SEL, NSArray *);
static NSMutableArray *hook_specifiersForIDs(id self, SEL _cmd, NSArray *ids) {
    NSMutableArray *specs = orig_specifiersForIDs(self, _cmd, ids);
    NSUInteger page = 2;
    for (NSUInteger i = 0; i < ids.count && i < specs.count; i++) {
        if (!CC26SIsDivider(ids[i])) continue;
        id spec = specs[i];
        if ([spec respondsToSelector:@selector(setName:)]) {
            ((void (*)(id, SEL, id))objc_msgSend)(spec, @selector(setName:), CC26SPageTitle(page));
        }
        if ([spec respondsToSelector:@selector(removePropertyForKey:)]) {
            ((void (*)(id, SEL, id))objc_msgSend)(spec, @selector(removePropertyForKey:), @"iconImage");
        }
        page++;
    }
    return specs;
}

static UITableViewCell *(*orig_cellForRow)(id, SEL, UITableView *, NSIndexPath *);
static UITableViewCell *hook_cellForRow(id self, SEL _cmd, UITableView *tv, NSIndexPath *ip) {
    UITableViewCell *cell = orig_cellForRow(self, _cmd, tv, ip);
    BOOL divider = CC26SIsDivider(CC26SIdentifierAt(self, ip));
    BOOL wasDivider = [objc_getAssociatedObject(cell, kCC26DividerCellKey) boolValue];
    if (divider) {
        objc_setAssociatedObject(cell, kCC26DividerCellKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        cell.imageView.image = nil;
        cell.textLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
        cell.textLabel.textColor = UIColor.secondaryLabelColor;
        cell.backgroundColor = UIColor.tertiarySystemFillColor;
        cell.editingAccessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    } else if (wasDivider) {
        objc_setAssociatedObject(cell, kCC26DividerCellKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        cell.textLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        cell.textLabel.textColor = UIColor.labelColor;
        cell.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    }
    return cell;
}

static UITableViewCellEditingStyle (*orig_editingStyle)(id, SEL, UITableView *, NSIndexPath *);
static UITableViewCellEditingStyle hook_editingStyle(id self, SEL _cmd, UITableView *tv, NSIndexPath *ip) {
    if (CC26SIsDivider(CC26SIdentifierAt(self, ip))) return UITableViewCellEditingStyleNone;
    return orig_editingStyle(self, _cmd, tv, ip);
}

static BOOL (*orig_shouldIndent)(id, SEL, UITableView *, NSIndexPath *);
static BOOL hook_shouldIndent(id self, SEL _cmd, UITableView *tv, NSIndexPath *ip) {
    if (CC26SIsDivider(CC26SIdentifierAt(self, ip))) return NO;
    return orig_shouldIndent ? orig_shouldIndent(self, _cmd, tv, ip) : YES;
}

// A divider may not leave the included list.
static NSIndexPath *(*orig_targetIndexPath)(id, SEL, UITableView *, NSIndexPath *, NSIndexPath *);
static NSIndexPath *hook_targetIndexPath(id self, SEL _cmd, UITableView *tv, NSIndexPath *from, NSIndexPath *to) {
    NSIndexPath *r = orig_targetIndexPath ? orig_targetIndexPath(self, _cmd, tv, from, to) : to;
    if (r.section != from.section && CC26SIsDivider(CC26SIdentifierAt(self, from))) {
        NSInteger rows = [tv numberOfRowsInSection:from.section];
        return [NSIndexPath indexPathForRow:MAX(0, rows - 1) inSection:from.section];
    }
    return r;
}

// After a drag the headers are numbered again by their new order.
static void (*orig_moveRow)(id, SEL, UITableView *, NSIndexPath *, NSIndexPath *);
static void hook_moveRow(id self, SEL _cmd, UITableView *tv, NSIndexPath *from, NSIndexPath *to) {
    orig_moveRow(self, _cmd, tv, from, to);
    __weak id weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        id s = weakSelf;
        if (!s) return;
        if ([s respondsToSelector:@selector(_repopulateModuleData)]) {
            ((void (*)(id, SEL))objc_msgSend)(s, @selector(_repopulateModuleData));
        }
        if ([s respondsToSelector:@selector(reloadSpecifiers)]) {
            ((void (*)(id, SEL))objc_msgSend)(s, @selector(reloadSpecifiers));
        }
    });
}

#pragma mark - Install

static void CC26SHook(Class cls, SEL sel, IMP hook, IMP *orig) {
    if (!class_getInstanceMethod(cls, sel)) return;
    MSHookMessageEx(cls, sel, hook, orig);
}

static void CC26SInstall(void) {
    static BOOL done = NO;
    if (done) return;
    Class cls = NSClassFromString(@"CCUISettingsListController");
    if (!cls) return;
    done = YES;
    CC26SHook(cls, @selector(_repopulateModuleData), (IMP)hook_repopulate, (IMP *)&orig_repopulate);
    CC26SHook(cls, @selector(_specifiersForIdentifiers:), (IMP)hook_specifiersForIDs, (IMP *)&orig_specifiersForIDs);
    CC26SHook(cls, @selector(tableView:cellForRowAtIndexPath:), (IMP)hook_cellForRow, (IMP *)&orig_cellForRow);
    CC26SHook(cls, @selector(tableView:editingStyleForRowAtIndexPath:), (IMP)hook_editingStyle, (IMP *)&orig_editingStyle);
    CC26SHook(cls, @selector(tableView:moveRowAtIndexPath:toIndexPath:), (IMP)hook_moveRow, (IMP *)&orig_moveRow);

    SEL indent = @selector(tableView:shouldIndentWhileEditingRowAtIndexPath:);
    if (class_getInstanceMethod(cls, indent)) {
        MSHookMessageEx(cls, indent, (IMP)hook_shouldIndent, (IMP *)&orig_shouldIndent);
    } else {
        class_addMethod(cls, indent, (IMP)hook_shouldIndent, "B@:@@");
    }
    SEL target = @selector(tableView:targetIndexPathForMoveFromRowAtIndexPath:toProposedIndexPath:);
    if (class_getInstanceMethod(cls, target)) {
        MSHookMessageEx(cls, target, (IMP)hook_targetIndexPath, (IMP *)&orig_targetIndexPath);
    } else {
        class_addMethod(cls, target, (IMP)hook_targetIndexPath, "@@:@@@");
    }
}

static void CC26SBundleLoaded(__unused CFNotificationCenterRef c, __unused void *o,
                              __unused CFStringRef n, const void *obj, __unused CFDictionaryRef u) {
    NSBundle *b = (__bridge NSBundle *)obj;
    if ([b.bundleIdentifier isEqualToString:@"com.apple.ControlCenterSettings"]) CC26SInstall();
}

__attribute__((constructor)) static void CC26SettingsInit(void) {
    @autoreleasepool {
        if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.Preferences"]) return;
        CC26SInstall();
        CFNotificationCenterAddObserver(CFNotificationCenterGetLocalCenter(), NULL, CC26SBundleLoaded,
                                        (CFStringRef)NSBundleDidLoadNotification, NULL,
                                        CFNotificationSuspensionBehaviorCoalesce);
    }
}
