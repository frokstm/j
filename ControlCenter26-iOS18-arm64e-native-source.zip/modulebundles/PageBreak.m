// A page divider for Control Center (see makefile/build.sh: one bundle per page, -DCC26_PAGE=n).
//
// The user drags "Page 2", "Page 3" and "Page 4" in Settings ▸ Control Center like any other
// control; the ControlCenter26 tweak starts a new page at each divider and hides it (CC26Edit.m,
// CC26DividerPlanForPass). Without the tweak the divider is an empty, clear tile that does nothing.
#import <UIKit/UIKit.h>

@interface CC26_VC_CLASS : UIViewController
@end

@implementation CC26_VC_CLASS
- (void)loadView {
    UIView *root = [UIView new];
    root.backgroundColor = UIColor.clearColor;
    root.userInteractionEnabled = NO;
    self.view = root;
}
- (CGFloat)preferredExpandedContentHeight { return 0.0; }
- (CGFloat)preferredExpandedContentWidth { return 0.0; }
- (BOOL)providesOwnPlatter { return YES; }
- (BOOL)shouldBeginTransitionToExpandedContentModule { return NO; }
@end

@interface CC26_MODULE_CLASS : NSObject
@property (nonatomic, strong) id contentModuleContext;
@end

@implementation CC26_MODULE_CLASS {
    UIViewController *_controller;
}
- (UIViewController *)contentViewController {
    if (!_controller) _controller = [CC26_VC_CLASS new];
    return _controller;
}
- (UIViewController *)backgroundViewController { return nil; }
@end
