// Module sizes chosen in Settings ▸ ControlCenter26 ▸ Module Sizes.
// Edit mode off: the stock Control Center layout still places the modules; only the size of a
// module changes, from the "Size.<module id>" preference ("2x2"). Nothing is read while edit mode
// is on, and nothing dragged in Control Center is saved here.
#import "CC26.h"

static NSString *const kCC26SizesDomain = @"com.controlcenter26.preferences";

// The modules seen so far, as Settings lists them: "KnownModules" maps each module id to its
// stock size ("2x2"). Written only when a module is new or its stock size changed.
void CC26NoteModuleSeen(NSString *mid, NSUInteger w, NSUInteger h) {
    if (!mid.length || !w || !h) return;
    static NSMutableSet<NSString *> *seen = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ seen = [NSMutableSet set]; });
    NSString *stock = [NSString stringWithFormat:@"%lux%lu", (unsigned long)w, (unsigned long)h];
    NSString *token = [mid stringByAppendingFormat:@"|%@", stock];
    if ([seen containsObject:token]) return;
    [seen addObject:token];

    id old = CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("KnownModules"), (__bridge CFStringRef)kCC26SizesDomain));
    NSMutableDictionary *known = [[old isKindOfClass:NSDictionary.class] ? old : @{} mutableCopy];
    if ([known[mid] isEqual:stock]) return;
    known[mid] = stock;
    CFPreferencesSetAppValue(CFSTR("KnownModules"), (__bridge CFPropertyListRef)known,
                             (__bridge CFStringRef)kCC26SizesDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)kCC26SizesDomain);
}

// The size chosen for this module in Settings, when it is a valid "WxH" with 1 to 4 cells a side.
BOOL CC26SettingsSize(NSString *mid, NSUInteger *w, NSUInteger *h) {
    if (!mid.length || !w || !h) return NO;
    NSString *key = [@"Size." stringByAppendingString:mid];
    id value = CFBridgingRelease(CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kCC26SizesDomain));
    if (![value isKindOfClass:NSString.class]) return NO;
    NSArray<NSString *> *parts = [(NSString *)value componentsSeparatedByString:@"x"];
    if (parts.count != 2) return NO;
    NSInteger pw = parts[0].integerValue, ph = parts[1].integerValue;
    if (pw < 1 || ph < 1 || pw > 4 || ph > 4) return NO;
    *w = (NSUInteger)pw;
    *h = (NSUInteger)ph;
    return YES;
}
