#import "CC26.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <math.h>
#import <os/log.h>

#import <substrate.h>
@class CALayer;
@class CCUIButtonModuleView;
@class CCUIContentModuleContainerViewController;
@class CCUIModularControlCenterOverlayViewController;
@class CCUIModuleCollectionViewController;
@class UIViewController;
static void CC26InstallHooks_CC26Edit__ungrouped(void);

#ifdef __cplusplus
extern "C" {
#endif
BOOL CC26LIQIsActive(void);
id CC26LIQBuildGlassFilter(void);
#ifdef __cplusplus
}
#endif

typedef struct CCUILayoutSize  { NSUInteger width;  NSUInteger height; } CCUILayoutSize;
typedef struct CCUILayoutPoint { NSUInteger x;      NSUInteger y;      } CCUILayoutPoint;
typedef struct CCUILayoutRect  { CCUILayoutPoint origin; CCUILayoutSize size; } CCUILayoutRect;
typedef struct { NSUInteger c, r, w, h; } CC26Rect;

static NSUInteger kCC26Cols = 4;
static NSUInteger kCC26Rows = 8;
static NSUInteger gCC26EditEpoch = 0;
static CFTimeInterval gEditModeEnteredAt = 0;
static NSInteger gCC26LastPresentationState = 1;
static CGFloat    kCC26Cell = 67.0;
static CGFloat    kCC26gap  = 12.0;
static CGFloat    kCC26Step = 79.0;

BOOL gEditModeEnabled = NO;
BOOL gEditModeActive  = NO;

// CC26Edit is experimental and off for now: no resizing, moving or saved layout. Control Center
// shows its own stock layout, and nothing is read from or written to the preferences for it.
// Set to 1 to bring edit mode back.
#define CC26_EDIT_MODE_ENABLED 0

// Settings ▸ Module Sizes is off for now: modules keep their stock size. Set to 1 to bring it back.
#define CC26_SETTINGS_SIZES_ENABLED 0

static NSMutableDictionary<NSString *, NSArray<NSNumber *> *> *gEditOrigins;
static NSMutableDictionary<NSString *, NSArray<NSNumber *> *> *gEditSizes;
static NSMutableDictionary<NSString *, NSArray<NSNumber *> *> *gEditBaseSizes;

static NSString *gCC26PendingResizeID = nil;
static CCUILayoutSize gCC26PendingResizeSize = {0, 0};
static NSTimeInterval gCC26PendingResizeLastTouch = 0;

static Class kClsCCUIButtonModuleView;
static Class kClsCCUICAPackageView;
static Class kClsCABackdropLayer;

static const NSInteger kCC26BorderTag       = 182000;
static const NSInteger kCC26RemoveTag       = 182001;
static const NSInteger kCC26ResizeTag       = 182002;
static const NSInteger kCC26HintTag         = 182003;
static const NSInteger kCC26ProxyTag        = 182004;
static const NSInteger kCC26ResetTag        = 182005;
static const NSInteger kCC26ShieldTag       = 182006;
static const NSInteger kCC26ProxyShadowTag  = 182007;

static const void *kCC26BorderKey   = &kCC26BorderKey;
static const void *kCC26RemoveKey   = &kCC26RemoveKey;
static const void *kCC26ResizeKey   = &kCC26ResizeKey;
static const void *kCC26PresKey     = &kCC26PresKey;
static const void *kCC26MidKey      = &kCC26MidKey;
static const void *kCC26StartSzKey  = &kCC26StartSzKey;
static const void *kCC26GestKey     = &kCC26GestKey;
static const void *kCC26DragSrcKey  = &kCC26DragSrcKey;
static const void *kCC26DragProxyKey= &kCC26DragProxyKey;
static const void *kCC26DragGrabKey = &kCC26DragGrabKey;
static const void *kCC26OwnGestureKey = &kCC26OwnGestureKey;
static const void *kCC26DisabledGesturesKey = &kCC26DisabledGesturesKey;
static const void *kCC26ResizedSetKey = &kCC26ResizedSetKey;
static const void *kCC26LastCellKey     = &kCC26LastCellKey;
static const void *kCC26OrigLayoutKey   = &kCC26OrigLayoutKey;
static const void *kCC26LastRadiusKey   = &kCC26LastRadiusKey;
static const void *kCC26LastPresKey     = &kCC26LastPresKey;
static const void *kCC26OrigRadiiKey    = &kCC26OrigRadiiKey;
static const void *kCC26LandscapeCleanKey = &kCC26LandscapeCleanKey;
static const void *kCC26IconPinKey = &kCC26IconPinKey;
static const CGFloat kCC26BorderWidth = 4.0;
static const CGFloat kCC26BorderInset = 3.5;
static CFTimeInterval gCC26RotationQuietUntil = 0;

static NSString *CC26Mid(UIViewController *vc);
static CGRect CC26VisibleFrame(UIViewController *m, UIViewController *overlay);
static UIViewController *CC26ModuleAtPoint(CGPoint pt, UIViewController *overlay);
static CGPoint CC26GridBase(UIViewController *overlay);
static NSUInteger CC26VisibleRowCap(UIViewController *ov);
static NSArray<NSNumber *> *CC26KnownBaseSize(NSString *mid);
static void CC26EnsureBaseSize(UIViewController *m, UIViewController *ov);
static void CC26EffectiveSize(NSString *mid, NSUInteger *w, NSUInteger *h);
static void CC26PresentationSize(NSString *mid, NSUInteger *w, NSUInteger *h);
static BOOL CC26ModuleSupportsResizing(NSString *mid);
static CCUILayoutSize CC26ResizeCandidate(NSString *mid, NSUInteger startW, NSUInteger startH, CGPoint translation);
static BOOL CC26SizeAllowed(NSUInteger w, NSUInteger h);
static void CC26PlaceNewModule(NSString *mid, CCUILayoutSize size, NSArray<NSString *> *ids);
static void CC26SetModulePages(NSUInteger count);
// What the last layout pass used (CC26 Edit's layout or the stock one), to notice a toggle.
static BOOL gCC26LayoutSawEdit = NO;
static BOOL gCC26LayoutSeen = NO;

// Stock iOS size of each module, as moduleLayoutSizeForContentModuleContext: answers it
// before the edit sizes are applied (portrait only).
static NSMutableDictionary<NSString *, NSArray<NSNumber *> *> *CC26NativeSizes(void) {
    static NSMutableDictionary *d = nil;
    if (!d) d = [NSMutableDictionary dictionary];
    return d;
}
static void CC26NoteNativeSize(NSString *mid, CCUILayoutSize s) {
    CC26NativeSizes()[mid] = @[@(s.width), @(s.height)];
}
static NSArray<NSNumber *> *CC26NativeSize(NSString *mid) {
    return mid.length ? CC26NativeSizes()[mid] : nil;
}
static BOOL CC26DragSizeAllowedForModule(NSString *mid, NSUInteger w, NSUInteger h);
static NSString *CC26PrettyNameForModule(UIViewController *m);
static BOOL CC26RectsOverlap(CC26Rect a, CC26Rect b);
static BOOL CC26FindFreeCellFor(NSDictionary<NSString *, NSValue *> *occupied,
                                NSUInteger preferCol, NSUInteger preferRow,
                                NSUInteger w, NSUInteger h,
                                NSUInteger maxRow,
                                NSUInteger *outCol, NSUInteger *outRow);
static id CC26SettingsProvider(void);
static NSArray<NSString *> *CC26ProviderOrderedIdentifiers(void);
static UIView *CC26ModuleButtonView(UIView *moduleView);
static NSArray<UIView *> *CC26CompactGlyphHosts(UIView *view);
static void CC26LayoutModuleIcon(UIViewController *m);
static void CC26RestoreModuleIcon(UIViewController *m);
static CGFloat CC26RadiusForSize(NSUInteger w, NSUInteger h);
static void CC26ApplyRadiusToModule(UIViewController *m);
static void CC26RefreshPresentation(UIViewController *m, UIViewController *ov);
static BOOL CC26WasResizedFromOneByOne(NSString *mid);
static void CC26ApplyChrome(UIViewController *m, UIViewController *ov);
static void CC26StripChrome(UIViewController *m);
static void CC26RestoreModuleRadius(UIViewController *m);
static void CC26InstallGestures(UIViewController *ov);
static BOOL CC26EditAllowed(void);
static BOOL gCC26PendingStockCopy;
static BOOL CC26ApplyStockLayout(UIViewController *ov);
static BOOL CC26IsLandscape(void);
static void CC26TearDownModule(UIViewController *m);
static void CC26TearDownAllModules(UIViewController *ov);
static void CC26ScheduleRotationRefresh(void);

static void CC26InitCachedClasses(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        kClsCCUIButtonModuleView = NSClassFromString(@"CCUIButtonModuleView");
        kClsCCUICAPackageView    = NSClassFromString(@"CCUICAPackageView");
        kClsCABackdropLayer      = NSClassFromString(@"CABackdropLayer");
    });
}

// Stock iOS rect (col, row, w, h; portrait, rows counted from the top of the grid) of each
// module, recorded while CC26 Edit is off; Copy Stock Layout and turning Edit on start from it.
static NSMutableDictionary<NSString *, NSArray<NSNumber *> *> *gCC26StockRects = nil;

static void CC26EnsureStore(void) {
    if (!CC26_EDIT_MODE_ENABLED) {
        // Edit mode is off: nothing is read from the preferences, the stores stay empty in memory.
        if (!gCC26StockRects) gCC26StockRects = [NSMutableDictionary dictionary];
        if (!gEditOrigins) gEditOrigins = [NSMutableDictionary dictionary];
        if (!gEditSizes) gEditSizes = [NSMutableDictionary dictionary];
        if (!gEditBaseSizes) gEditBaseSizes = [NSMutableDictionary dictionary];
        return;
    }
    if (!gCC26StockRects) {
        CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("StockGridRects"), CFSTR("com.controlcenter26.preferences"));
        NSDictionary *d = (__bridge NSDictionary *)v;
        gCC26StockRects = [d isKindOfClass:NSDictionary.class] ? [d mutableCopy] : [NSMutableDictionary dictionary];
        if (v) CFRelease(v);
    }
    if (!gEditOrigins) {
        CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("EditGridOrigins"), CFSTR("com.controlcenter26.preferences"));
        gEditOrigins = [(__bridge NSDictionary *)v mutableCopy] ?: [NSMutableDictionary dictionary];
        if (v) CFRelease(v);
    }
    if (!gEditSizes) {
        CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("EditGridSizes"), CFSTR("com.controlcenter26.preferences"));
        gEditSizes = [(__bridge NSDictionary *)v mutableCopy] ?: [NSMutableDictionary dictionary];
        if (v) CFRelease(v);
    }
    if (!gEditBaseSizes) {
        CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("EditBaseSizes"), CFSTR("com.controlcenter26.preferences"));
        gEditBaseSizes = [(__bridge NSDictionary *)v mutableCopy] ?: [NSMutableDictionary dictionary];
        if (v) CFRelease(v);
    }
}

static void CC26FlushStore(void) {
    CC26EnsureStore();
    CFPreferencesSetAppValue(CFSTR("EditGridOrigins"), (__bridge CFPropertyListRef)[gEditOrigins copy], CFSTR("com.controlcenter26.preferences"));
    CFPreferencesSetAppValue(CFSTR("EditGridSizes"),   (__bridge CFPropertyListRef)[gEditSizes copy],   CFSTR("com.controlcenter26.preferences"));
    CFPreferencesSetAppValue(CFSTR("EditBaseSizes"),   (__bridge CFPropertyListRef)[gEditBaseSizes copy], CFSTR("com.controlcenter26.preferences"));
    CFPreferencesSetAppValue(CFSTR("StockGridRects"),  (__bridge CFPropertyListRef)[gCC26StockRects copy], CFSTR("com.controlcenter26.preferences"));
    CFPreferencesAppSynchronize(CFSTR("com.controlcenter26.preferences"));
}

// The in-memory store is the truth; writing it to cfprefsd on every layout pass made edit
// mode stutter, so writes are coalesced into one flush shortly after the last change.
static BOOL gCC26StoreFlushPending = NO;
static NSUInteger gCC26StoreGeneration = 0;
static void CC26SaveStore(void) {
    if (!CC26_EDIT_MODE_ENABLED) return;   // edit mode is off: nothing is written to the preferences
    CC26EnsureStore();
    gCC26StoreGeneration++;
    if (gCC26StoreFlushPending) return;
    gCC26StoreFlushPending = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        gCC26StoreFlushPending = NO;
        CC26FlushStore();
    });
}

static BOOL CC26IsNotchedDevice(void) {
    UIWindow *w = UIApplication.sharedApplication.keyWindow;
    if (w && w.safeAreaInsets.bottom >= 1.0) return YES;
    return NO;
}

static BOOL CC26IsLandscape(void) {
    UIWindow *win = UIApplication.sharedApplication.keyWindow;
    if (win) {
        CGSize sz = win.bounds.size;
        if (sz.width > 1.0 && sz.height > 1.0) return sz.width > sz.height;
    }
    CGSize sz = UIScreen.mainScreen.bounds.size;
    return sz.width > sz.height;
}

static BOOL CC26IsNonNotchedDevice(void) {
    CGSize size = UIScreen.mainScreen.bounds.size;
    if (MAX(size.width, size.height) >= 800.0) return NO;
    UIWindow *window = UIApplication.sharedApplication.keyWindow;
    if (window && window.safeAreaInsets.bottom >= 1.0) return NO;
    return YES;
}

static void CC26RefreshGridConstants(void) {
    BOOL landscape = CC26IsLandscape();
    kCC26Cols = landscape ? 8 : 4;
    kCC26Rows = landscape ? 4 : 8;
    kCC26Cell = 67.0;
    kCC26gap  = 12.0;
    kCC26Step = kCC26Cell + kCC26gap;
}

static BOOL CC26EditAllowed(void) {
    if (!CC26_EDIT_MODE_ENABLED || !gEnabled || !gEditModeEnabled) return NO;
    if (CC26IsLandscape()) return NO;
    return YES;
}

static NSString *CC26GridKey(NSString *mid) {
    if (!mid.length) return mid;
    return CC26IsLandscape() ? [@"L|" stringByAppendingString:mid]
                            : [@"P|" stringByAppendingString:mid];
}

static NSArray<NSNumber *> *CC26GetOrigin(NSString *mid) {
    if (!mid.length) return nil;
    CC26EnsureStore();
    NSString *key = CC26GridKey(mid);
    NSArray<NSNumber *> *v = gEditOrigins[key];
    if (v) return v;
    if (!CC26IsLandscape()) return gEditOrigins[mid];
    return nil;
}

static void CC26SetOrigin(NSString *mid, NSArray<NSNumber *> *value) {
    if (!mid.length) return;
    CC26EnsureStore();
    NSString *key = CC26GridKey(mid);
    if (value) gEditOrigins[key] = value;
    else       [gEditOrigins removeObjectForKey:key];
}

static void CC26InvalidateOtherOrientationOriginForModule(NSString *mid) {
    if (!mid.length) return;
    CC26EnsureStore();
    BOOL landscape = CC26IsLandscape();
    NSString *otherPrefix = landscape ? @"P|" : @"L|";
    NSString *key = [otherPrefix stringByAppendingString:mid];
    [gEditOrigins removeObjectForKey:key];
    if (!landscape) {
        [gEditOrigins removeObjectForKey:mid];
    }
}

static NSArray<NSNumber *> *CC26SourceOriginForRotation(NSString *mid, BOOL toLandscape) {
    if (!mid.length) return nil;
    NSString *fromPrefix = toLandscape ? @"P|" : @"L|";
    NSArray *v = gEditOrigins[[fromPrefix stringByAppendingString:mid]];
    if (v) return v;
    if (toLandscape) return gEditOrigins[mid];
    return nil;
}

static NSArray<NSNumber *> *CC26TargetOriginForRotation(NSString *mid, BOOL toLandscape) {
    if (!mid.length) return nil;
    NSString *toPrefix = toLandscape ? @"L|" : @"P|";
    return gEditOrigins[[toPrefix stringByAppendingString:mid]];
}

static void CC26MigrateMissingOrigins(UIViewController *ov) {
    if (!ov) return;
    CC26EnsureStore();
    CC26RefreshGridConstants();

    BOOL toLandscape = CC26IsLandscape();
    NSUInteger fromCols = toLandscape ? 4 : 8;
    NSUInteger fromRows = toLandscape ? 8 : 4;
    NSUInteger toCols   = toLandscape ? 8 : 4;
    NSUInteger toRows   = toLandscape ? 4 : 8;
    NSString *toPrefix = toLandscape ? @"L|" : @"P|";

    NSMutableArray<NSDictionary *> *toMigrate = [NSMutableArray array];
    NSMutableArray<NSString *>     *already   = [NSMutableArray array];

    for (UIViewController *m in ModuleControllers(ov)) {
        NSString *mid = CC26Mid(m);
        if (!mid.length) continue;

        if (CC26TargetOriginForRotation(mid, toLandscape)) {
            [already addObject:mid];
            continue;
        }
        NSArray<NSNumber *> *src = CC26SourceOriginForRotation(mid, toLandscape);
        if (src.count < 2) continue;

        NSUInteger c = src[0].unsignedIntegerValue;
        NSUInteger a = src[1].unsignedIntegerValue;
        NSUInteger page = a / fromRows;
        NSUInteger r    = a % fromRows;

        NSUInteger w = 1, h = 1;
        NSArray<NSNumber *> *sz = gEditSizes[mid];
        if (sz.count < 2) sz = gEditBaseSizes[mid];
        if (sz.count >= 2) {
            w = sz[0].unsignedIntegerValue;
            h = sz[1].unsignedIntegerValue;
        }
        if (w > toCols) w = toCols;
        if (h > toRows) h = toRows;
        if (!CC26DragSizeAllowedForModule(mid, w, h)) { w = 1; h = 1; }

        [toMigrate addObject:@{
            @"mid":  mid,
            @"c":    @(c),
            @"r":    @(r),
            @"page": @(page),
            @"w":    @(w),
            @"h":    @(h),
        }];
    }

    if (!toMigrate.count) return;

    [toMigrate sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        for (NSString *k in @[@"page", @"r", @"c"]) {
            NSInteger va = [a[k] integerValue];
            NSInteger vb = [b[k] integerValue];
            if (va != vb) return va < vb ? NSOrderedAscending : NSOrderedDescending;
        }
        return [a[@"mid"] compare:b[@"mid"]];
    }];

    NSMutableDictionary<NSNumber *, NSMutableDictionary<NSString *, NSValue *> *> *pages =
        [NSMutableDictionary dictionary];

    for (NSString *mid in already) {
        NSArray<NSNumber *> *o = CC26TargetOriginForRotation(mid, toLandscape);
        if (o.count < 2) continue;
        NSUInteger c = o[0].unsignedIntegerValue;
        NSUInteger a = o[1].unsignedIntegerValue;
        NSUInteger page = a / toRows;
        NSUInteger r    = a % toRows;

        NSUInteger w = 1, h = 1;
        NSArray<NSNumber *> *sz = gEditSizes[mid];
        if (sz.count < 2) sz = gEditBaseSizes[mid];
        if (sz.count >= 2) {
            w = sz[0].unsignedIntegerValue;
            h = sz[1].unsignedIntegerValue;
        }
        if (w > toCols) w = toCols;
        if (h > toRows) h = toRows;

        NSMutableDictionary *map = pages[@(page)];
        if (!map) { map = [NSMutableDictionary dictionary]; pages[@(page)] = map; }
        CC26Rect pr = {c, r, w, h};
        map[mid] = [NSValue value:&pr withObjCType:@encode(CC26Rect)];
    }

    for (NSDictionary *e in toMigrate) {
        NSString *mid = e[@"mid"];
        NSUInteger srcC = [e[@"c"]    unsignedIntegerValue];
        NSUInteger srcR = [e[@"r"]    unsignedIntegerValue];
        NSUInteger page = [e[@"page"] unsignedIntegerValue];
        NSUInteger w    = [e[@"w"]    unsignedIntegerValue];
        NSUInteger h    = [e[@"h"]    unsignedIntegerValue];

        NSUInteger prefC = (NSUInteger)llround(((double)srcC / (double)fromCols) * (double)toCols);
        NSUInteger prefR = (NSUInteger)llround(((double)srcR / (double)fromRows) * (double)toRows);
        if (prefC + w > toCols) prefC = (toCols >= w) ? (toCols - w) : 0;
        if (prefR + h > toRows) prefR = (toRows >= h) ? (toRows - h) : 0;

        NSMutableDictionary<NSString *, NSValue *> *placed = pages[@(page)];
        if (!placed) { placed = [NSMutableDictionary dictionary]; pages[@(page)] = placed; }

        NSUInteger maxRow = (toRows >= h) ? (toRows - h) : 0;
        NSUInteger outC = prefC, outR = prefR;
        BOOL ok = CC26FindFreeCellFor(placed, prefC, prefR, w, h, maxRow, &outC, &outR);

        if (!ok) {
            NSUInteger p = page + 1;
            while (p < 8) {
                NSMutableDictionary *next = pages[@(p)];
                if (!next) { next = [NSMutableDictionary dictionary]; pages[@(p)] = next; }
                if (CC26FindFreeCellFor(next, 0, 0, w, h, maxRow, &outC, &outR)) {
                    placed = next; page = p; ok = YES; break;
                }
                p++;
            }
        }
        if (!ok) continue;

        CC26Rect pr = {outC, outR, w, h};
        placed[mid] = [NSValue value:&pr withObjCType:@encode(CC26Rect)];
        gEditOrigins[[toPrefix stringByAppendingString:mid]] =
            @[@(outC), @(page * toRows + outR)];
    }

    CC26SaveStore();
}

static NSString *CC26Mid(UIViewController *vc) {
    if (!vc) return nil;
    for (NSString *key in @[@"moduleIdentifier", @"_moduleIdentifier"]) {
        @try { id v = [vc valueForKey:key];
            if ([v isKindOfClass:NSString.class] && [v length]) return v; }
        @catch (__unused NSException *e) {}
    }
    return nil;
}

static CGRect CC26VisibleFrame(UIViewController *m, UIViewController *overlay) {
    if (!m.view || !overlay.view) return CGRectZero;
    CGRect f = [m.view convertRect:m.view.bounds toView:overlay.view];
    UIViewController *col = ModuleCollection(overlay);
    if (col.view) {
        CATransform3D sub = col.view.layer.sublayerTransform;
        if (fabs(sub.m41) > 0.5 || fabs(sub.m42) > 0.5) {
            // The page shift is the collection's sublayerTransform. Add it only when the view
            // conversion above left it out; adding it twice put every page after the first
            // off screen (no edit chrome, no drag there).
            UIView *child = m.view;
            while (child.superview && child.superview != col.view) child = child.superview;
            BOOL included = NO;
            if (child.superview == col.view) {
                CGRect a = [child convertRect:child.bounds toView:col.view];
                CGRect b = child.frame;
                included = fabs((CGRectGetMinY(a) - CGRectGetMinY(b)) - sub.m42) < 1.0 &&
                           fabs((CGRectGetMinX(a) - CGRectGetMinX(b)) - sub.m41) < 1.0;
            }
            if (!included) {
                f.origin.x += sub.m41;
                f.origin.y += sub.m42;
            }
        }
    }
    return f;
}

static UIViewController *CC26ModuleAtPoint(CGPoint pt, UIViewController *overlay) {
    UIViewController *best = nil;
    CGFloat bestD = CGFLOAT_MAX;
    for (UIViewController *m in ModuleControllers(overlay)) {
        CGRect f = CC26VisibleFrame(m, overlay);
        if (CGRectIsEmpty(f)) continue;
        if (CGRectContainsPoint(f, pt)) {
            CGFloat d = hypot(CGRectGetMidX(f) - pt.x, CGRectGetMidY(f) - pt.y);
            if (d < bestD) { bestD = d; best = m; }
        }
    }
    return best;
}

static CGPoint CC26GridBase(UIViewController *overlay) {
    CC26RefreshGridConstants();
    CC26EnsureStore();
    CGFloat bx = CGFLOAT_MAX, by = CGFLOAT_MAX;
    NSUInteger page = (NSUInteger)gCurrentPage;
    for (UIViewController *m in ModuleControllers(overlay)) {
        NSString *mid = CC26Mid(m);
        if (!mid.length) continue;
        NSArray<NSNumber *> *o = CC26GetOrigin(mid);
        if (o.count < 2) continue;
        NSUInteger c = o[0].unsignedIntegerValue;
        NSUInteger a = o[1].unsignedIntegerValue;
        if (a / kCC26Rows != page) continue;
        NSUInteger lr = a % kCC26Rows;
        CGRect f = CC26VisibleFrame(m, overlay);
        if (CGRectIsEmpty(f)) continue;
        CGFloat x = CGRectGetMinX(f) - (CGFloat)c * kCC26Step;
        CGFloat y = CGRectGetMinY(f) - (CGFloat)lr * kCC26Step;
        if (x < bx) bx = x;
        if (y < by) by = y;
    }
    if (bx == CGFLOAT_MAX) {
        CGFloat w = CGRectGetWidth(overlay.view.bounds);
        CGFloat gw = kCC26Cols * kCC26Cell + (kCC26Cols - 1) * kCC26gap;
        bx = (w - gw) * 0.5;
        by = 100.0;
    }
    return CGPointMake(bx, by);
}

static NSUInteger CC26VisibleRowCap(UIViewController *ov) {
    if (!ov || !ov.view) return kCC26Rows - 1;
    CGPoint base = CC26GridBase(ov);
    CGFloat overlayH = CGRectGetHeight(ov.view.bounds);
    CGFloat safeBottom = ov.view.safeAreaInsets.bottom;
    if (safeBottom < 1.0) safeBottom = 20.0;
    CGFloat usableBottom = overlayH - safeBottom - 8.0;
    CGFloat usableH = usableBottom - base.y;
    if (usableH < kCC26Step) return 0;
    NSInteger rows = (NSInteger)floor(usableH / kCC26Step);
    if (rows <= 0) rows = 1;
    NSUInteger cap = (NSUInteger)MAX(0, MIN((NSInteger)kCC26Rows - 1, rows - 1));
    return cap;
}

static NSArray<NSNumber *> *CC26KnownBaseSize(NSString *mid) {
    if (!mid.length) return nil;
    NSString *lower = mid.lowercaseString;
    NSArray<NSArray<NSString *> *> *entries = @[
        @[@"control-center.connectivitymodule", @"2", @"2"],
        @[@"connectivitymodule", @"2", @"2"],
        @[@"mediaremote.controlcenter.nowplaying", @"2", @"2"],
        @[@"mediaremote.controlcenter.audio", @"1", @"2"],
        @[@"control-center.displaymodule", @"1", @"2"],
        @[@"control-center.focusui", @"2", @"1"],
        @[@"focusui", @"2", @"1"],
        @[@"donotdisturb", @"2", @"1"],
    ];
    for (NSArray *entry in entries) {
        if ([lower containsString:entry[0]]) {
            return @[@([entry[1] integerValue]), @([entry[2] integerValue])];
        }
    }
    return nil;
}

static void CC26EnsureBaseSize(UIViewController *m, UIViewController *ov) {
    NSString *mid = CC26Mid(m);
    if (!mid.length) return;

    // A CCSupport module (e.g. a 4x2 weather widget) states its own size; at that size it
    // draws its own content, so it is not a 1x1 module that was resized.
    {
        id module = nil;
        @try { module = [m valueForKey:@"module"]; } @catch (__unused NSException *e) {}
        if (!module) { @try { module = [m valueForKey:@"contentModule"]; } @catch (__unused NSException *e) {} }
        SEL sizeSel = NSSelectorFromString(@"moduleSizeForOrientation:");
        CCUILayoutSize s = {0, 0};
        if ([module respondsToSelector:sizeSel]) {
            s = ((CCUILayoutSize (*)(id, SEL, int))objc_msgSend)(module, sizeSel, 0);
        }
        if (!s.width || !s.height || (s.width == 1 && s.height == 1)) {
            // CCSupport takes the size from the bundle's Info.plist (CCSModuleSize) instead.
            NSBundle *b = module ? [NSBundle bundleForClass:[module class]] : nil;
            NSDictionary *info = b.infoDictionary;
            if (![info[@"CCSModuleSize"] isKindOfClass:NSDictionary.class]) info = [NSBundle bundleWithIdentifier:mid].infoDictionary;
            NSDictionary *cs = info[@"CCSModuleSize"];
            NSDictionary *pt = [cs isKindOfClass:NSDictionary.class] ? cs[@"Portrait"] : nil;
            if ([pt isKindOfClass:NSDictionary.class]) {
                s.width  = (NSUInteger)[pt[@"Width"] integerValue];
                s.height = (NSUInteger)[pt[@"Height"] integerValue];
            }
        }
        {
            if (s.width && s.height && (s.width != 1 || s.height != 1) &&
                s.width <= kCC26Cols && s.height <= kCC26Rows) {
                CC26NoteNativeSize(mid, s);
                NSArray *nat = @[@(s.width), @(s.height)];
                if (![gEditBaseSizes[mid] isEqualToArray:nat]) {
                    gEditBaseSizes[mid] = nat;
                    CC26SaveStore();
                }
                return;
            }
        }
    }

    NSArray<NSNumber *> *known = CC26KnownBaseSize(mid);
    if (known.count == 2) {
        if (![gEditBaseSizes[mid] isEqualToArray:known]) {
            gEditBaseSizes[mid] = known;
            CC26SaveStore();
        }
        return;
    }

    if (gEditSizes[mid]) {
        if (![gEditBaseSizes[mid] isEqualToArray:@[@1, @1]]) {
            gEditBaseSizes[mid] = @[@1, @1];
            CC26SaveStore();
        }
        return;
    }

    NSArray<NSNumber *> *existing = gEditBaseSizes[mid];
    if (existing.count >= 2 &&
        (existing[0].integerValue != 1 || existing[1].integerValue != 1)) {
        gEditBaseSizes[mid] = @[@1, @1];
        CC26SaveStore();
        return;
    }
    if (existing) return;

    CGRect f = CC26VisibleFrame(m, ov);
    if (CGRectIsEmpty(f)) return;
    NSUInteger w = (NSUInteger)MAX(1, MIN((NSInteger)kCC26Cols, (NSInteger)llround((CGRectGetWidth(f) + kCC26gap) / kCC26Step)));
    NSUInteger h = (NSUInteger)MAX(1, MIN((NSInteger)kCC26Rows, (NSInteger)llround((CGRectGetHeight(f) + kCC26gap) / kCC26Step)));
    gEditBaseSizes[mid] = @[@(w), @(h)];
    CC26SaveStore();
}

static void CC26EffectiveSize(NSString *mid, NSUInteger *w, NSUInteger *h) {
    CC26EnsureStore();
    NSArray<NSNumber *> *s = gEditSizes[mid];
    if (!s) s = gEditBaseSizes[mid];
    *w = s.count >= 2 ? s[0].unsignedIntegerValue : 1;
    *h = s.count >= 2 ? s[1].unsignedIntegerValue : 1;
}

static void CC26PresentationSize(NSString *mid, NSUInteger *w, NSUInteger *h) {
    if (gCC26PendingResizeID && [gCC26PendingResizeID isEqualToString:mid] &&
        gCC26PendingResizeSize.width && gCC26PendingResizeSize.height) {
        *w = gCC26PendingResizeSize.width;
        *h = gCC26PendingResizeSize.height;
        return;
    }
    CC26EffectiveSize(mid, w, h);
}

typedef struct { NSTimeInterval duration; CGFloat c1x, c1y, c2x, c2y; } CC26AnimSpec;

static CC26AnimSpec CC26ResizeSpec(void) {
    if (gExperimentalPagingEnabled) return (CC26AnimSpec){0.58, 0.32, 0.72, 0.0, 1.0};
    return (CC26AnimSpec){0.25, 0.25, 0.10, 0.25, 1.0};
}

static CAMediaTimingFunction *CC26ResizeTiming(CC26AnimSpec sp) {
    return [CAMediaTimingFunction functionWithControlPoints:(float)sp.c1x :(float)sp.c1y :(float)sp.c2x :(float)sp.c2y];
}

static BOOL CC26AnimationsAllowed(void) {
    return CACurrentMediaTime() >= gCC26RotationQuietUntil;
}

static BOOL CC26ModuleSupportsResizing(NSString *mid) {
    if (!mid.length) return NO;
    NSString *lower = mid.lowercaseString;
    if ([lower isEqualToString:@"com.apple.control-center.displaymodule"]) return NO;
    if ([lower containsString:@"mediaremote.controlcenter.audio"]) return NO;   // only the now-playing module resizes
    if ([lower isEqualToString:@"com.apple.control-center.connectivitymodule"]) return NO;
    if ([lower containsString:@"connectivitymodule"]) return NO;
    NSArray<NSNumber *> *base = gEditBaseSizes[mid];
    if (!base) base = CC26KnownBaseSize(mid);
    if (base.count < 2) return NO;
    NSUInteger w = base[0].unsignedIntegerValue;
    NSUInteger h = base[1].unsignedIntegerValue;
    if (w == 1 && h == 1) return YES;
    if (w == 2 && h == 2) return YES;
    return NO;
}

static BOOL CC26SizeAllowed(NSUInteger w, NSUInteger h) {
    if (w == 0 || h == 0) return NO;
    if (w > kCC26Cols || h > kCC26Rows) return NO;
    if (w > 4 || h > 4) return NO;
    if (w == 1 && h == 2) return NO;
    if (h == 1 && w == 3) return NO;
    if (h == 1 && w == 4) return NO;
    return YES;
}

static BOOL CC26DragSizeAllowedForModule(NSString *mid, NSUInteger w, NSUInteger h) {
    if (CC26SizeAllowed(w, h)) return YES;
    if (CC26ModuleSupportsResizing(mid)) return NO;
    NSUInteger bw = 1, bh = 1;
    CC26EffectiveSize(mid, &bw, &bh);
    return (w == bw && h == bh);
}

static CCUILayoutSize CC26ResizeCandidate(NSString *mid, NSUInteger startW, NSUInteger startH, CGPoint translation) {
    NSInteger dc = (NSInteger)floor(translation.x / kCC26Step + 0.5);
    NSInteger dr = (NSInteger)floor(translation.y / kCC26Step + 0.5);
    NSInteger nw = MAX(1, MIN(4, (NSInteger)startW + dc));
    NSInteger nh = MAX(1, MIN(4, (NSInteger)startH + dr));
    return (CCUILayoutSize){(NSUInteger)nw, (NSUInteger)nh};
}

static NSString *CC26BundleDisplayName(NSBundle *bundle) {
    if (!bundle) return nil;
    static NSSet<NSString *> *ignored = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        ignored = [NSSet setWithArray:@[
            @"ControlCenter", @"ControlCenterSettings", @"ControlCenterUIKit",
            @"ControlCenterServices", @"ControlCenterUI", @"ControlCenterSettingsBundles",
            @"CCSupport", @"SpringBoard", @"Preferences", @"UIKit", @"Foundation"]];
    });
    NSString *name = [bundle objectForInfoDictionaryKey:@"CFBundleDisplayName"];
    if (!name.length) name = [bundle objectForInfoDictionaryKey:@"CFBundleName"];
    if (!name.length) return nil;
    if ([ignored containsObject:name]) return nil;
    return name;
}

static NSString *CC26PrettyNameForModule(UIViewController *m) {
    if (!m) return CC26L(@"CONTROL", @"Control");

    NSString *mid = CC26Mid(m);
    NSString *lower = mid.lowercaseString;

    if ([lower containsString:@"screencapture"]) return CC26InfoStr(@"ReplayKitModule.bundle", @"Screen Recording");
    if ([lower containsString:@"control-center.displaymodule"] ||
        [lower isEqualToString:@"displaymodule"]) return CC26L(@"BRIGHTNESS", @"Brightness");
    if ([lower containsString:@"controlcenter.audio"]) return CC26MediaStr(@"VOLUME_SPEAKER", @"Volume");
    if ([lower containsString:@"accessibility"]) return CC26InfoStr(@"AccessibilityShorcutsModule.bundle", @"Accessibility Shortcuts");

    id contentModule = nil;
    @try { contentModule = [m valueForKey:@"module"]; } @catch (__unused NSException *e) {}
    for (NSString *key in @[@"displayName", @"title"]) {
        @try {
            id v = [contentModule valueForKey:key];
            if ([v isKindOfClass:NSString.class] && [v length]) return v;
        } @catch (__unused NSException *e) {}
    }

    id prov = CC26SettingsProvider();
    if (prov) {
        id meta = nil;
        SEL metaSel = NSSelectorFromString(@"moduleMetadataForModuleIdentifier:");
        if ([prov respondsToSelector:metaSel]) {
            meta = ((id (*)(id, SEL, id))objc_msgSend)(prov, metaSel, mid);
        }
        if (!meta) {
            @try {
                NSDictionary *all = [prov valueForKey:@"moduleMetadata"];
                if ([all isKindOfClass:NSDictionary.class]) meta = all[mid];
            } @catch (__unused NSException *e) {}
        }
        for (NSString *key in @[@"displayName", @"name", @"title", @"localizedName"]) {
            @try {
                id v = [meta valueForKey:key];
                if ([v isKindOfClass:NSString.class] && [v length]) return v;
            } @catch (__unused NSException *e) {}
        }
        NSURL *bundleURL = nil;
        NSString *bundlePath = nil;
        @try { id v = [meta valueForKey:@"bundleURL"];
            if ([v isKindOfClass:NSURL.class]) bundleURL = v; } @catch (__unused NSException *e) {}
        @try { id v = [meta valueForKey:@"bundlePath"];
            if ([v isKindOfClass:NSString.class]) bundlePath = v; } @catch (__unused NSException *e) {}
        NSBundle *bundle = bundleURL ? [NSBundle bundleWithURL:bundleURL]
                      : bundlePath ? [NSBundle bundleWithPath:bundlePath] : nil;
        NSString *metaBundleName = CC26BundleDisplayName(bundle);
        if (metaBundleName.length) return metaBundleName;
    }

    if (contentModule) {
        NSString *classBundleName = CC26BundleDisplayName([NSBundle bundleForClass:[contentModule class]]);
        if (classBundleName.length) return classBundleName;
    }

    NSString *label = m.view.accessibilityLabel;
    if (label.length) return label;
    UIView *pres = objc_getAssociatedObject(m.view, kCC26PresKey);
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:m.view.subviews];
    while (queue.count) {
        UIView *v = queue.firstObject;
        [queue removeObjectAtIndex:0];
        if (pres && v == pres) continue;
        if (v.accessibilityLabel.length) { label = v.accessibilityLabel; break; }
        [queue addObjectsFromArray:v.subviews];
    }
    if (label.length) return label;

    if (!mid.length) return CC26L(@"CONTROL", @"Control");
    NSString *last = [mid componentsSeparatedByString:@"."].lastObject;
    if ([last hasSuffix:@"Module"] && last.length > 6) last = [last substringToIndex:last.length - 6];
    if (!last.length) return CC26L(@"CONTROL", @"Control");
    NSMutableString *result = [NSMutableString string];
    for (NSUInteger i = 0; i < last.length; i++) {
        unichar c = [last characterAtIndex:i];
        if (i > 0 && [[NSCharacterSet uppercaseLetterCharacterSet] characterIsMember:c]) {
            [result appendString:@" "];
        }
        [result appendFormat:@"%C", c];
    }
    return result.length ? result : CC26L(@"CONTROL", @"Control");
}

static BOOL CC26RectsOverlap(CC26Rect a, CC26Rect b) {
    return (a.c < b.c + b.w && b.c < a.c + a.w &&
            a.r < b.r + b.h && b.r < a.r + a.h);
}

static BOOL CC26FindFreeCellFor(NSDictionary<NSString *, NSValue *> *occupied,
                                NSUInteger preferCol, NSUInteger preferRow,
                                NSUInteger w, NSUInteger h,
                                NSUInteger maxRow,
                                NSUInteger *outCol, NSUInteger *outRow) {
    if (w == 0 || h == 0 || w > kCC26Cols || h > kCC26Rows) return NO;
    NSInteger maxC = (NSInteger)kCC26Cols - (NSInteger)w;
    NSInteger maxR = MIN((NSInteger)maxRow, (NSInteger)kCC26Rows - (NSInteger)h);
    if (maxC < 0 || maxR < 0) return NO;

    BOOL found = NO;
    NSInteger bestScore = NSIntegerMax;
    NSUInteger bestCol = 0, bestRow = 0;

    for (NSInteger r = 0; r <= maxR; r++) {
        for (NSInteger c = 0; c <= maxC; c++) {
            CC26Rect t = {(NSUInteger)c, (NSUInteger)r, w, h};
            BOOL ok = YES;
            for (NSValue *v in occupied.allValues) {
                CC26Rect o = {};
                [v getValue:&o];
                if (CC26RectsOverlap(t, o)) { ok = NO; break; }
            }
            if (!ok) continue;
            NSInteger dx = c - (NSInteger)preferCol;
            NSInteger dy = r - (NSInteger)preferRow;
            NSInteger score = labs((long)dx) + labs((long)dy);
            if (score < bestScore ||
                (score == bestScore && (r < (NSInteger)bestRow ||
                 (r == (NSInteger)bestRow && c < (NSInteger)bestCol)))) {
                bestScore = score;
                bestCol = (NSUInteger)c;
                bestRow = (NSUInteger)r;
                found = YES;
            }
        }
    }
    if (found) { *outCol = bestCol; *outRow = bestRow; }
    return found;
}

static id CC26SettingsProvider(void) {
    Class c = NSClassFromString(@"CCSModuleSettingsProvider");
    SEL s = NSSelectorFromString(@"sharedProvider");
    return (c && [c respondsToSelector:s]) ? ((id (*)(id, SEL))objc_msgSend)(c, s) : nil;
}

static NSArray<NSString *> *CC26ProviderOrderedIdentifiers(void) {
    id prov = CC26SettingsProvider();
    SEL sel = NSSelectorFromString(@"orderedUserEnabledModuleIdentifiers");
    if (!prov || ![prov respondsToSelector:sel]) return nil;
    id list = ((id (*)(id, SEL))objc_msgSend)(prov, sel);
    return [list isKindOfClass:NSArray.class] ? (NSArray<NSString *> *)list : nil;
}

static UIView *CC26ModuleButtonView(UIView *moduleView) {
    if (!moduleView) return moduleView;
    if (kClsCCUIButtonModuleView && [moduleView isKindOfClass:kClsCCUIButtonModuleView]) return moduleView;
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:moduleView.subviews];
    while (queue.count) {
        UIView *v = queue.lastObject;
        [queue removeLastObject];
        if (kClsCCUIButtonModuleView && [v isKindOfClass:kClsCCUIButtonModuleView]) return v;
        if (v.subviews.count) [queue addObjectsFromArray:v.subviews];
    }
    return moduleView;
}

static NSArray<UIView *> *CC26CompactGlyphHosts(UIView *view) {
    if (!view) return @[];
    NSMutableArray<UIView *> *hosts = [NSMutableArray array];
    for (NSString *key in @[@"_glyphImageView", @"glyphImageView", @"_glyphPackageView", @"glyphPackageView"]) {
        @try {
            id cand = [view valueForKey:key];
            if ([cand isKindOfClass:UIView.class] && ![hosts containsObject:cand]) [hosts addObject:cand];
        } @catch (__unused NSException *e) {}
    }
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:view.subviews];
    while (queue.count) {
        UIView *v = queue.lastObject;
        [queue removeLastObject];
        BOOL hit = kClsCCUICAPackageView && [v isKindOfClass:kClsCCUICAPackageView];
        if (!hit) {
            NSString *cls = NSStringFromClass(v.class);
            hit = [cls isEqualToString:@"CCUICAPackageView"] || [cls containsString:@"CAPackage"];
        }
        if (!hit && [v isKindOfClass:UIImageView.class]) {
            UIImageView *iv = (UIImageView *)v;
            CGFloat mn = MIN(CGRectGetWidth(v.bounds), CGRectGetHeight(v.bounds));
            hit = iv.image != nil && mn >= 16.0 && !v.hidden && v.alpha > 0.01;
        }
        if (hit && ![hosts containsObject:v]) [hosts addObject:v];
        if (v.subviews.count) [queue addObjectsFromArray:v.subviews];
    }
    return hosts;
}

static BOOL CC26IsGeometryKeyPath(NSString *keyPath) {
    return [keyPath hasPrefix:@"position"] ||
           [keyPath hasPrefix:@"bounds"] ||
           [keyPath hasPrefix:@"transform"] ||
           [keyPath hasPrefix:@"anchorPoint"];
}

static BOOL CC26ViewIsPinnedGlyph(UIView *view) {
    BOOL glyphSeen = NO;
    UIView *a = view;
    for (NSUInteger i = 0; a && i < 8; i++, a = a.superview) {
        if (objc_getAssociatedObject(a, kCC26IconPinKey)) return glyphSeen;
        NSString *cls = NSStringFromClass(a.class);
        if ([a isKindOfClass:UIImageView.class] || [cls containsString:@"CAPackage"]) glyphSeen = YES;
    }
    return NO;
}

static BOOL CC26ShouldBlockGlyphAnimation(CALayer *layer, CAAnimation *anim) {
    if (![anim isKindOfClass:CAPropertyAnimation.class]) return NO;
    if (!CC26IsGeometryKeyPath(((CAPropertyAnimation *)anim).keyPath)) return NO;
    CALayer *l = layer;
    for (NSUInteger i = 0; l && i < 8; i++, l = l.superlayer) {
        id d = l.delegate;
        if ([d isKindOfClass:UIView.class]) return CC26ViewIsPinnedGlyph((UIView *)d);
    }
    return NO;
}

static void CC26LayoutModuleIcon(UIViewController *m) {
    if (!m || !m.view) return;
    UIView *buttonView = CC26ModuleButtonView(m.view);
    NSArray<UIView *> *glyphs = CC26CompactGlyphHosts(buttonView);
    CGPoint targetInButton = CGPointMake(kCC26Cell * 0.5, kCC26Cell * 0.5);
    objc_setAssociatedObject(buttonView, kCC26IconPinKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    for (UIView *glyph in glyphs) {
        UIView *host = glyph.superview;
        if (!host) continue;
        CGPoint target = [buttonView convertPoint:targetInButton toView:host];

        [UIView performWithoutAnimation:^{
            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            for (NSString *k in [glyph.layer.animationKeys copy]) {
                CAAnimation *a = [glyph.layer animationForKey:k];
                if ([a isKindOfClass:CAPropertyAnimation.class] &&
                    CC26IsGeometryKeyPath(((CAPropertyAnimation *)a).keyPath)) {
                    [glyph.layer removeAnimationForKey:k];
                }
            }
            glyph.layer.transform = CATransform3DIdentity;
            glyph.center = target;
            [CATransaction commit];
        }];
    }
}

static void CC26RestoreModuleIcon(UIViewController *m) {
    if (!m || !m.view) return;
    UIView *buttonView = CC26ModuleButtonView(m.view);
    NSArray<UIView *> *glyphs = CC26CompactGlyphHosts(buttonView);
    for (UIView *glyph in glyphs) {
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        [glyph.layer removeAnimationForKey:@"cc26.glide"];
        glyph.transform = CGAffineTransformIdentity;
        [CATransaction commit];
    }
}

static CGFloat CC26RadiusForSize(NSUInteger w, NSUInteger h) {
    if (w == 0 || h == 0) return 22.0;

    CGFloat widthPt  = (CGFloat)w * kCC26Cell + ((CGFloat)w - 1.0) * kCC26gap;
    CGFloat heightPt = (CGFloat)h * kCC26Cell + ((CGFloat)h - 1.0) * kCC26gap;
    if (widthPt <= 0.0 || heightPt <= 0.0) return 22.0;

    return calculatedRadius(CGRectMake(0.0, 0.0, widthPt, heightPt), 22.0);
}

static void CC26RememberLayerState(UIView *v, NSMapTable<UIView *, NSDictionary *> *table) {
    if (!v || [table objectForKey:v]) return;
    [table setObject:@{ @"r":     @(v.layer.cornerRadius),
                        @"curve": v.layer.cornerCurve ?: kCACornerCurveCircular,
                        @"mask":  @(v.layer.masksToBounds) }
              forKey:v];
}

static BOOL CC26ModuleIsExpanded(UIViewController *m) {
    if (gCCAModuleExpanded) return YES;
    SEL sel = NSSelectorFromString(@"isExpanded");
    if ([m respondsToSelector:sel] && ((BOOL (*)(id, SEL))objc_msgSend)(m, sel)) return YES;
    UIView *root = m.view;
    if (!root) return NO;
    CGSize ms = root.bounds.size;

    NSString *mid = CC26Mid(m);
    if (mid.length && ms.width > 1.0 && ms.height > 1.0) {
        NSUInteger w = 1, h = 1;
        CC26PresentationSize(mid, &w, &h);
        CGFloat ew = (CGFloat)w * kCC26Cell + ((CGFloat)w - 1.0) * kCC26gap;
        CGFloat eh = (CGFloat)h * kCC26Cell + ((CGFloat)h - 1.0) * kCC26gap;
        if (ms.width > ew * 1.35 + 8.0 || ms.height > eh * 1.35 + 8.0) return YES;
    }

    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:root.subviews];
    NSUInteger visited = 0;
    while (queue.count && visited++ < 80) {
        UIView *v = queue.lastObject;
        [queue removeLastObject];
        NSString *cls = NSStringFromClass(v.class);
        if (([cls containsString:@"CCUIContentModuleContentContainer"] || [cls containsString:@"SliderView"]) &&
            (CGRectGetWidth(v.bounds) > ms.width + 14.0 || CGRectGetHeight(v.bounds) > ms.height + 14.0)) {
            return YES;
        }
        [queue addObjectsFromArray:v.subviews];
    }
    return NO;
}

static void CC26SetRadius(CALayer *layer, CGFloat radius, BOOL animate) {
    CGFloat from = radius;
    if (animate) {
        CALayer *pl = layer.presentationLayer;
        from = pl ? pl.cornerRadius : layer.cornerRadius;
    }
    // A continuous corner bigger than half the short side draws as a diamond: never go past it.
    CGSize ls = layer.bounds.size;
    if (ls.width > 1.0 && ls.height > 1.0) radius = MIN(radius, floor(MIN(ls.width, ls.height) * 0.5));
    if (from > radius && ls.width > 1.0 && ls.height > 1.0) from = MIN(from, floor(MIN(ls.width, ls.height) * 0.5));
    layer.cornerRadius = radius;
    layer.cornerCurve = kCACornerCurveContinuous;
    layer.masksToBounds = YES;
    CABasicAnimation *running = (CABasicAnimation *)[layer animationForKey:@"cc26.radius"];
    BOOL sameGoal = running && [running.toValue isKindOfClass:NSNumber.class] &&
                    fabs([running.toValue doubleValue] - radius) < 0.01;
    if (animate && !sameGoal && fabs(from - radius) > 0.5) {
        CC26AnimSpec sp = CC26ResizeSpec();
        CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"cornerRadius"];
        a.fromValue = @(from);
        a.toValue = @(radius);
        a.duration = sp.duration;
        a.timingFunction = CC26ResizeTiming(sp);
        [layer addAnimation:a forKey:@"cc26.radius"];
    }
}

static void CC26RunMaybeWithoutAnimation(void (^block)(void)) {
    if (CACurrentMediaTime() < gCC26RotationQuietUntil) {
        [UIView performWithoutAnimation:^{
            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            block();
            [CATransaction commit];
        }];
    } else {
        block();
    }
}

// CC18LiquidGlass draws its glass with a shader from lgShapeRect and lgShapeCornerRadius.
// A radius past half the shape's short side draws the module as a diamond: clamp it.
static void (*CC26Orig_setLgShapeCornerRadius)(id, SEL, CGFloat);
static void (*CC26Orig_setLgShapeRect)(id, SEL, CGRect);
static CGFloat CC26LGClamp(id obj, CGFloat r) {
    CGRect rect = CGRectZero;
    if ([obj respondsToSelector:NSSelectorFromString(@"lgShapeRect")])
        rect = ((CGRect (*)(id, SEL))objc_msgSend)(obj, NSSelectorFromString(@"lgShapeRect"));
    CGSize s = rect.size;
    if ((s.width < 1.0 || s.height < 1.0) && [obj respondsToSelector:@selector(bounds)])
        s = ((CGRect (*)(id, SEL))objc_msgSend)(obj, @selector(bounds)).size;
    if (s.width >= 1.0 && s.height >= 1.0) r = MIN(r, floor(MIN(s.width, s.height) * 0.5));
    return r;
}
static void CC26Hook_setLgShapeCornerRadius(id self, SEL _cmd, CGFloat r) {
    CC26Orig_setLgShapeCornerRadius(self, _cmd, CC26LGClamp(self, r));
}
static void CC26Hook_setLgShapeRect(id self, SEL _cmd, CGRect rect) {
    CC26Orig_setLgShapeRect(self, _cmd, rect);
    if (CC26Orig_setLgShapeCornerRadius && [self respondsToSelector:NSSelectorFromString(@"lgShapeCornerRadius")]) {
        CGFloat r = ((CGFloat (*)(id, SEL))objc_msgSend)(self, NSSelectorFromString(@"lgShapeCornerRadius"));
        CGFloat c = CC26LGClamp(self, r);
        if (c < r - 0.01) CC26Orig_setLgShapeCornerRadius(self, NSSelectorFromString(@"setLgShapeCornerRadius:"), c);
    }
}
// With lgShapeCornerRadius 0 the shader reads layer.cornerRadius; LiquidGlass sets 35 even on a 54 pt view
// (now playing artwork), which draws a diamond. Clamp the view's and its backdrop/edge layers' radius.
static BOOL CC26ClampLGLayers(UIView *v) {
    CGSize s = v.bounds.size;
    if (s.width < 1.0 || s.height < 1.0) return NO;
    CGFloat maxR = floor(MIN(s.width, s.height) * 0.5);
    BOOL changed = NO;
    if (v.layer.cornerRadius > maxR + 0.01) { v.layer.cornerRadius = maxR; changed = YES; }
    for (CALayer *l in v.layer.sublayers) {
        CGSize ls = l.bounds.size;
        if (ls.width < 1.0 || ls.height < 1.0) continue;
        CGFloat lm = floor(MIN(ls.width, ls.height) * 0.5);
        if (l.cornerRadius > lm + 0.01) { l.cornerRadius = lm; changed = YES; }
    }
    return changed;
}
static void (*CC26Orig_LGLayoutSubviews)(UIView *, SEL);
static void CC26Hook_LGLayoutSubviews(UIView *self, SEL _cmd) {
    CC26ClampLGLayers(self);
    CC26Orig_LGLayoutSubviews(self, _cmd);
    if (CC26ClampLGLayers(self)) CC26Orig_LGLayoutSubviews(self, _cmd);
}
static void CC26HookLGLayout(void) {
    static BOOL done;
    if (done) return;
    Class c = objc_getClass("LGLiveBackdropView");
    if (!c) return;
    done = YES;
    CC26HookMessage(c, @selector(layoutSubviews), (IMP)CC26Hook_LGLayoutSubviews, (IMP *)&CC26Orig_LGLayoutSubviews);
}
static void CC26DiagWrite(NSString *line);
static void CC26HookLGShapeClass(Class c) {
    static BOOL done;
    if (done || !c) return;
    while (class_getSuperclass(c) && [class_getSuperclass(c) instancesRespondToSelector:NSSelectorFromString(@"setLgShapeCornerRadius:")])
        c = class_getSuperclass(c);
    done = YES;
    CC26HookMessage(c, NSSelectorFromString(@"setLgShapeCornerRadius:"), (IMP)CC26Hook_setLgShapeCornerRadius, (IMP *)&CC26Orig_setLgShapeCornerRadius);
    if ([c instancesRespondToSelector:NSSelectorFromString(@"setLgShapeRect:")])
        CC26HookMessage(c, NSSelectorFromString(@"setLgShapeRect:"), (IMP)CC26Hook_setLgShapeRect, (IMP *)&CC26Orig_setLgShapeRect);
    CC26DiagWrite([NSString stringWithFormat:@"lgshape hooked %s", class_getName(c)]);
}
static void CC26FindLGShapeClass(void) {
    CC26HookLGLayout();
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        SEL sel = NSSelectorFromString(@"setLgShapeCornerRadius:");
        for (NSString *name in @[@"LGLiveBackdropView", @"LGGlassRec", @"LGBlurView", @"LGAdjustableBlurView", @"C18ModuleView", @"C18Tile"]) {
            Class c = objc_getClass(name.UTF8String);
            if (c && [c instancesRespondToSelector:sel]) { CC26HookLGShapeClass(c); break; }
        }
    });
}
static void CC26FixLGShape(id obj) {
    if ([obj isKindOfClass:UIView.class] && strcmp(object_getClassName(obj), "LGLiveBackdropView") == 0 && CC26ClampLGLayers(obj))
        [(UIView *)obj setNeedsLayout];
    if (![obj respondsToSelector:NSSelectorFromString(@"lgShapeCornerRadius")] ||
        ![obj respondsToSelector:NSSelectorFromString(@"setLgShapeCornerRadius:")]) return;
    CC26HookLGShapeClass([obj class]);
    CGFloat r = ((CGFloat (*)(id, SEL))objc_msgSend)(obj, NSSelectorFromString(@"lgShapeCornerRadius"));
    CGFloat c = CC26LGClamp(obj, r);
    CGRect rect = [obj respondsToSelector:NSSelectorFromString(@"lgShapeRect")] ?
        ((CGRect (*)(id, SEL))objc_msgSend)(obj, NSSelectorFromString(@"lgShapeRect")) : CGRectZero;
    static int logged;
    if (logged < 60 || c < r - 0.01) {
        logged++;
        CC26DiagWrite([NSString stringWithFormat:@"lgshape %s rect=%@ b=%@ r=%.1f -> %.1f", object_getClassName(obj),
                       NSStringFromCGRect(rect), NSStringFromCGRect(((CGRect (*)(id, SEL))objc_msgSend)(obj, @selector(bounds))), r, c]);
    }
    if (c < r - 0.01) {
        ((void (*)(id, SEL, CGFloat))objc_msgSend)(obj, NSSelectorFromString(@"setLgShapeCornerRadius:"), c);
        if ([obj respondsToSelector:@selector(setNeedsLayout)]) [obj setNeedsLayout];
    }
}

static void CC26ApplyRadiusToModule(UIViewController *m) {
    if (!m || !m.view) return;
    if (CC26IsLandscape()) return;
    objc_setAssociatedObject(m.view, kCC26LandscapeCleanKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    NSString *mid = CC26Mid(m);
    if (!mid.length) return;
    CC26FindLGShapeClass();

    if (CC26ModuleIsExpanded(m)) {
        if (objc_getAssociatedObject(m.view, kCC26LastRadiusKey)) CC26RestoreModuleRadius(m);
        return;
    }

    NSUInteger w = 1, h = 1;
    CC26EffectiveSize(mid, &w, &h);
    CGFloat radius = CC26RadiusForSize(w, h);

    CGSize moduleSize = m.view.bounds.size;
    if (moduleSize.width < 1.0 || moduleSize.height < 1.0) return;

    NSValue *last = objc_getAssociatedObject(m.view, kCC26LastRadiusKey);
    BOOL animateRadius = last != nil && CC26AnimationsAllowed();
    BOOL resizeSettling = gCC26PendingResizeID != nil ||
                          (CACurrentMediaTime() - gCC26PendingResizeLastTouch) < 1.4;
    if (last && !resizeSettling) {
        NSMapTable<UIView *, NSDictionary *> *styled = objc_getAssociatedObject(m.view, kCC26OrigRadiiKey);
        for (UIView *v in styled.keyEnumerator.allObjects) {
            if (!v.window || !v.layer.masksToBounds) continue;
            BOOL sameSizeAsModule = fabs(CGRectGetWidth(v.bounds) - moduleSize.width) < 8.0 &&
                                    fabs(CGRectGetHeight(v.bounds) - moduleSize.height) < 8.0;
            if (sameSizeAsModule && fabs(v.layer.cornerRadius - radius) > 0.5) {
                last = nil;
                break;
            }
        }
    }
    if (last && !resizeSettling) {
        CGSize ls = last.CGSizeValue;
        if (fabs(ls.width  - moduleSize.width)  < 0.5 &&
            fabs(ls.height - moduleSize.height) < 0.5 &&
            fabs(m.view.layer.cornerRadius - radius) < 0.5) {
            return;
        }
    }
    objc_setAssociatedObject(m.view, kCC26LastRadiusKey,
                             [NSValue valueWithCGSize:moduleSize],
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    NSMapTable<UIView *, NSDictionary *> *orig = objc_getAssociatedObject(m.view, kCC26OrigRadiiKey);
    if (!orig) {
        orig = [NSMapTable weakToStrongObjectsMapTable];
        objc_setAssociatedObject(m.view, kCC26OrigRadiiKey, orig, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }

    CC26RunMaybeWithoutAnimation(^{
        CC26RememberLayerState(m.view, orig);
        CC26SetRadius(m.view.layer, radius, animateRadius);

        UIView *buttonView = CC26ModuleButtonView(m.view);
        if (buttonView) {
            CC26RememberLayerState(buttonView, orig);
            CC26SetRadius(buttonView.layer, radius, animateRadius);
        }

        NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:m.view.subviews];
        while (queue.count) {
            UIView *v = queue.lastObject;
            [queue removeLastObject];
            BOOL isPillName = (kClsCCUIButtonModuleView && [v isKindOfClass:kClsCCUIButtonModuleView]);
            if (!isPillName) {
                NSString *cls = NSStringFromClass(v.class);
                isPillName = [cls containsString:@"CCUIButtonModuleView"] ||
                             [cls containsString:@"CCUIContentModuleContentContainer"];
            }
            CGFloat vw = CGRectGetWidth(v.bounds);
            CGFloat vh = CGRectGetHeight(v.bounds);
            BOOL fills = (fabs(vw - moduleSize.width)  < 8.0) &&
                         (fabs(vh - moduleSize.height) < 8.0);
            if (isPillName || fills) {
                CC26RememberLayerState(v, orig);
                CC26SetRadius(v.layer, radius, animateRadius);
            }
            CC26FixLGShape(v);
            CC26FixLGShape(v.layer);
            if (v.subviews.count) [queue addObjectsFromArray:v.subviews];
        }
    });
}

static void CC26RestoreModuleRadius(UIViewController *m) {
    if (!m || !m.view) return;
    objc_setAssociatedObject(m.view, kCC26LastRadiusKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    NSMapTable<UIView *, NSDictionary *> *orig = objc_getAssociatedObject(m.view, kCC26OrigRadiiKey);
    if (!orig) return;

    [UIView performWithoutAnimation:^{
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        for (UIView *v in orig.keyEnumerator.allObjects) {
            NSDictionary *st = [orig objectForKey:v];
            if (!st) continue;
            CGFloat vw = CGRectGetWidth(v.bounds);
            CGFloat vh = CGRectGetHeight(v.bounds);
            BOOL smallSquare = vw > 1.0 && vh > 1.0 && fabs(vw - vh) < 1.5 && MIN(vw, vh) <= 76.0;
            if (smallSquare) {
                v.layer.cornerRadius = MIN(vw, vh) * 0.5;
                v.layer.cornerCurve  = kCACornerCurveContinuous;
            } else {
                v.layer.cornerRadius = [st[@"r"] doubleValue];
                v.layer.cornerCurve  = st[@"curve"] ?: kCACornerCurveCircular;
            }
            v.layer.masksToBounds = [st[@"mask"] boolValue];
        }
        [CATransaction commit];
    }];
}

static void CC26TearDownModule(UIViewController *m) {
    if (!m || !m.view) return;
    UIView *view = m.view;
    CGSize sz = view.bounds.size;
    NSValue *done = objc_getAssociatedObject(view, kCC26LandscapeCleanKey);
    if (done && fabs(done.CGSizeValue.width  - sz.width)  < 0.5 &&
                fabs(done.CGSizeValue.height - sz.height) < 0.5) return;
    objc_setAssociatedObject(view, kCC26LandscapeCleanKey, [NSValue valueWithCGSize:sz],
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    [UIView performWithoutAnimation:^{
        [CATransaction begin];
        [CATransaction setDisableActions:YES];

        UIView *pres = objc_getAssociatedObject(view, kCC26PresKey);
        [pres removeFromSuperview];
        objc_setAssociatedObject(view, kCC26PresKey,     nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(view, kCC26LastPresKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

        CC26StripChrome(m);
        CC26RestoreModuleIcon(m);
        CC26RestoreModuleRadius(m);

        [CC26ModuleButtonView(view) setNeedsLayout];

        [CATransaction commit];
    }];
}

static void CC26TearDownAllModules(UIViewController *ov) {
    if (!ov) return;
    for (UIViewController *m in ModuleControllers(ov)) CC26TearDownModule(m);
}

static BOOL CC26WasResizedFromOneByOne(NSString *mid) {
    if (!mid.length) return NO;

    NSUInteger curW = 1, curH = 1;
    CC26PresentationSize(mid, &curW, &curH);
    if (curW == 1 && curH == 1) return NO;

    // A module shown at its own stock size (a 2x2 or 2x1 module, e.g. after Copy Stock
    // Layout) draws its own content: no title overlay, no icon re-layout.
    NSArray<NSNumber *> *native = CC26NativeSize(mid);
    if (native.count >= 2 && (native[0].unsignedIntegerValue != 1 || native[1].unsignedIntegerValue != 1)) {
        return NO;
    }

    NSArray<NSNumber *> *known = CC26KnownBaseSize(mid);
    if (known.count >= 2) {
        return (known[0].integerValue == 1 && known[1].integerValue == 1);
    }

    NSMutableSet<NSString *> *resized = objc_getAssociatedObject(UIApplication.sharedApplication, kCC26ResizedSetKey);
    if ([resized containsObject:mid]) return YES;

    if (gEditSizes[mid]) return YES;

    NSArray<NSNumber *> *base = gEditBaseSizes[mid];
    if (base.count >= 2) {
        return (base[0].integerValue == 1 && base[1].integerValue == 1);
    }
    return NO;
}

static UIViewPropertyAnimator *CC26BezierAnimator(NSTimeInterval duration,
                                                 CGFloat c1x, CGFloat c1y,
                                                 CGFloat c2x, CGFloat c2y) {
    UICubicTimingParameters *timing =
        [[UICubicTimingParameters alloc] initWithControlPoint1:CGPointMake(c1x, c1y)
                                                controlPoint2:CGPointMake(c2x, c2y)];
    UIViewPropertyAnimator *a = [[UIViewPropertyAnimator alloc] initWithDuration:duration
                                                                timingParameters:timing];
    a.interruptible = YES;
    a.userInteractionEnabled = YES;
    return a;
}

static UIView *CC26MakeBorder(void) {
    UIView *v = [UIView new];
    v.userInteractionEnabled = NO;
    v.backgroundColor = UIColor.clearColor;
    v.layer.cornerCurve = kCACornerCurveContinuous;
    v.layer.masksToBounds = NO;
    
    v.layer.borderColor = [UIColor colorWithWhite:0.75 alpha:0.35].CGColor;
    
    v.layer.borderWidth = kCC26BorderWidth;
    v.layer.shadowColor = UIColor.blackColor.CGColor;
    v.layer.shadowOpacity = 0.08;
    v.layer.shadowRadius = 3.0;
    v.layer.shadowOffset = CGSizeZero;

    CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"opacity"];
    pulse.fromValue = @0.85;
    pulse.toValue = @1.0;
    pulse.duration = 1.6;
    pulse.autoreverses = YES;
    pulse.repeatCount = HUGE_VALF;
    pulse.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [v.layer addAnimation:pulse forKey:@"CC26EditPulse"];
    return v;
}

static UIButton *CC26MakeRemoveButton(NSString *mid) {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.tag = kCC26RemoveTag;
    b.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.94];
    b.frame = CGRectMake(0, 0, 30, 30);
    b.layer.cornerRadius = 15.0;
    b.layer.cornerCurve = kCACornerCurveContinuous;
    b.layer.masksToBounds = NO;
    b.layer.shadowColor = UIColor.blackColor.CGColor;
    b.layer.shadowOpacity = 0.14;
    b.layer.shadowRadius = 4.0;
    b.layer.shadowOffset = CGSizeMake(0, 1);

    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration
        configurationWithPointSize:15 weight:UIImageSymbolWeightBold];
    UIImageView *icon = [[UIImageView alloc]
        initWithImage:[UIImage systemImageNamed:@"minus" withConfiguration:cfg]];
    icon.tintColor = [UIColor colorWithWhite:0.10 alpha:0.85];
    icon.contentMode = UIViewContentModeCenter;
    icon.userInteractionEnabled = NO;
    icon.frame = b.bounds;
    icon.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [b addSubview:icon];

    objc_setAssociatedObject(b, kCC26MidKey, mid, OBJC_ASSOCIATION_COPY_NONATOMIC);
    return b;
}

static UIButton *CC26MakeResizeButton(NSString *mid) {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.tag = kCC26ResizeTag;
    b.backgroundColor = UIColor.clearColor;
    b.frame = CGRectMake(0, 0, 42, 42);

    UIBezierPath *cornerPath = [UIBezierPath bezierPath];
    [cornerPath moveToPoint:CGPointMake(20.29, 40.01)];
    [cornerPath addCurveToPoint:CGPointMake(40.01, 20.29)
                  controlPoint1:CGPointMake(31.20, 40.01)
                  controlPoint2:CGPointMake(40.01, 31.20)];

    UIVisualEffectView *material = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialLight]];
    material.frame = b.bounds;
    material.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    material.userInteractionEnabled = NO;
    CAShapeLayer *materialMask = [CAShapeLayer layer];
    materialMask.path = cornerPath.CGPath;
    materialMask.fillColor = UIColor.clearColor.CGColor;
    materialMask.strokeColor = UIColor.blackColor.CGColor;
    materialMask.lineWidth = 12.0;
    materialMask.lineCap = kCALineCapRound;
    materialMask.lineJoin = kCALineJoinRound;
    material.layer.mask = materialMask;
    [b addSubview:material];

    CAShapeLayer *pill = [CAShapeLayer layer];
    pill.path = cornerPath.CGPath;
    pill.fillColor = UIColor.clearColor.CGColor;
    pill.strokeColor = [UIColor.whiteColor colorWithAlphaComponent:0.82].CGColor;
    pill.lineWidth = 12.5;
    pill.lineCap = kCALineCapRound;
    pill.lineJoin = kCALineJoinRound;
    [b.layer addSublayer:pill];

    objc_setAssociatedObject(b, kCC26MidKey, mid, OBJC_ASSOCIATION_COPY_NONATOMIC);
    return b;
}

static UIButton *CC26MakeResetButton(void) {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.tag = kCC26ResetTag;
    b.backgroundColor = [UIColor colorWithWhite:0.12 alpha:0.90];
    b.layer.cornerRadius = 20.0;
    b.layer.cornerCurve = kCACornerCurveContinuous;
    b.layer.masksToBounds = YES;

    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:14 weight:UIImageSymbolWeightSemibold];
    UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"arrow.counterclockwise" withConfiguration:cfg]];
    icon.tintColor = UIColor.whiteColor;
    icon.contentMode = UIViewContentModeScaleAspectFit;
    icon.userInteractionEnabled = NO;
    icon.tag = 9001;

    UILabel *label = [[UILabel alloc] init];
    label.text = CC26L(@"RESET_LAYOUT", @"Reset Layout");
    label.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    label.textColor = UIColor.whiteColor;
    label.userInteractionEnabled = NO;
    label.tag = 9002;

    CGSize textSize = [label sizeThatFits:CGSizeMake(300, 20)];
    CGFloat iconSide = 18.0;
    CGFloat gap = 7.0;
    CGFloat padX = 16.0;
    CGFloat height = 40.0;
    CGFloat width = padX + iconSide + gap + textSize.width + padX;

    b.bounds = CGRectMake(0, 0, width, height);
    icon.frame = CGRectMake(padX, (height - iconSide) * 0.5, iconSide, iconSide);
    label.frame = CGRectMake(padX + iconSide + gap, 0, textSize.width, height);
    [b addSubview:icon];
    [b addSubview:label];
    return b;
}

static void CC26AnimateChromeEntry(UIView *chrome) {
    if (!chrome) return;
    chrome.transform = CGAffineTransformMakeScale(0.82, 0.82);
    UIViewPropertyAnimator *anim = CC26BezierAnimator(0.45, 0.32, 0.72, 0.0, 1.0);
    [anim addAnimations:^{
        chrome.transform = CGAffineTransformIdentity;
    }];
    [anim startAnimation];
}

static void CC26AnimateChromeEntryDelayed(UIView *chrome, NSTimeInterval delay) {
    if (!chrome) return;
    chrome.transform = CGAffineTransformMakeScale(0.4, 0.4);
    chrome.alpha = 0.0;
    UIViewPropertyAnimator *anim = CC26BezierAnimator(0.42, 0.32, 0.72, 0.0, 1.0);
    [anim addAnimations:^{
        chrome.transform = CGAffineTransformIdentity;
        chrome.alpha = 1.0;
    }];
    [anim startAnimationAfterDelay:delay];
}

@interface CC26EditShield : UIView
@end

@implementation CC26EditShield
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (self.hidden || self.alpha < 0.01 || !self.userInteractionEnabled) return nil;
    return self;
}
@end

@interface CC26LiveGlassProxyView : UIView
@end

@implementation CC26LiveGlassProxyView
+ (Class)layerClass {
    return kClsCABackdropLayer ?: [CALayer class];
}
@end

static UIImage *CC26SnapshotContentOnly(UIView *src, BOOL liquidassActive) {
    CGSize sz = src.bounds.size;
    if (sz.width < 1 || sz.height < 1) return nil;

    UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:sz];

    if (!liquidassActive) {
        return [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
            [src drawViewHierarchyInRect:CGRectMake(0, 0, sz.width, sz.height)
                     afterScreenUpdates:NO];
        }];
    }

    NSMutableArray<UIView *> *hidden = [NSMutableArray array];
    NSMutableArray<UIView *> *queue = [NSMutableArray arrayWithArray:src.subviews];
    while (queue.count) {
        UIView *v = queue.lastObject;
        [queue removeLastObject];
        BOOL isMaterial = (kClsCABackdropLayer && [v.layer isKindOfClass:kClsCABackdropLayer]);
        if (!isMaterial) {
            NSString *cls = NSStringFromClass(v.class);
            isMaterial = [cls containsString:@"MTMaterial"] ||
                         [cls containsString:@"MaterialView"] ||
                         [cls containsString:@"Backdrop"] ||
                         [v isKindOfClass:UIVisualEffectView.class];
        }
        if (isMaterial) {
            if (!v.hidden && v.alpha > 0.01) {
                v.hidden = YES;
                [hidden addObject:v];
            }
        } else {
            if (v.subviews.count) [queue addObjectsFromArray:v.subviews];
        }
    }

    UIColor *savedBg = src.backgroundColor;
    src.backgroundColor = UIColor.clearColor;

    UIImage *result = [renderer imageWithActions:^(UIGraphicsImageRendererContext *ctx) {
        [src drawViewHierarchyInRect:CGRectMake(0, 0, sz.width, sz.height)
                 afterScreenUpdates:YES];
    }];

    for (UIView *v in hidden) v.hidden = NO;
    src.backgroundColor = savedBg;
    return result;
}

static void CC26BringChromeToFront(UIViewController *ov) {
    if (!ov || !ov.view) return;
    UIView *shield = [ov.view viewWithTag:kCC26ShieldTag];
    if (shield) [ov.view bringSubviewToFront:shield];
    for (UIViewController *m in ModuleControllers(ov)) {
        UIButton *rm = objc_getAssociatedObject(m.view, kCC26RemoveKey);
        UIButton *rz = objc_getAssociatedObject(m.view, kCC26ResizeKey);
        if (rm) [ov.view bringSubviewToFront:rm];
        if (rz) [ov.view bringSubviewToFront:rz];
        UIView *pr = objc_getAssociatedObject(m.view, kCC26PresKey);
        if (pr) [ov.view bringSubviewToFront:pr];
    }
    UIView *rp = [ov.view viewWithTag:kCC26ResetTag];
    if (rp) [ov.view bringSubviewToFront:rp];
}

static UIView *CC26ModuleMoverView(UIViewController *m, UIViewController *col) {
    UIView *v = m.view;
    if (!v) return nil;
    UIView *stop = col.view;
    if (!stop) return v;
    UIView *cur = v;
    while (cur.superview && cur.superview != stop) cur = cur.superview;
    return cur.superview == stop ? cur : v;
}

static NSDictionary<NSString *, NSValue *> *CC26CaptureModuleFrames(UIViewController *ov, NSString *excludeMid) {
    NSMutableDictionary<NSString *, NSValue *> *frames = [NSMutableDictionary dictionary];
    for (UIViewController *m in ModuleControllers(ov)) {
        NSString *mid = CC26Mid(m);
        if (!mid.length || [mid isEqualToString:excludeMid]) continue;
        CGRect f = CC26VisibleFrame(m, ov);
        if (CGRectIsEmpty(f)) continue;
        frames[mid] = [NSValue valueWithCGRect:f];
    }
    return frames;
}

static BOOL CC26SlideModules(UIViewController *ov, NSDictionary<NSString *, NSValue *> *oldFrames) {
    if (!ov || !oldFrames.count || !CC26AnimationsAllowed()) return NO;
    UIViewController *col = ModuleCollection(ov);
    CC26AnimSpec sp = CC26ResizeSpec();
    BOOL started = NO;
    for (UIViewController *m in ModuleControllers(ov)) {
        NSString *mid = CC26Mid(m);
        NSValue *oldValue = mid.length ? oldFrames[mid] : nil;
        if (!oldValue) continue;
        CGRect oldF = oldValue.CGRectValue;
        CGRect newF = CC26VisibleFrame(m, ov);
        if (CGRectIsEmpty(newF)) continue;
        CGFloat dx = oldF.origin.x - newF.origin.x;
        CGFloat dy = oldF.origin.y - newF.origin.y;
        if (hypot(dx, dy) < 0.5) continue;

        UIView *mover = CC26ModuleMoverView(m, col);
        if (!mover) continue;
        if ([mover.layer animationForKey:@"position"]) continue;

        CABasicAnimation *running = (CABasicAnimation *)[mover.layer animationForKey:@"cc26.slide"];
        if (running && [running.fromValue isKindOfClass:NSValue.class]) {
            CGPoint rf = [running.fromValue CGPointValue];
            if (hypot(rf.x - dx, rf.y - dy) < 0.5) continue;
        }

        CABasicAnimation *slide = [CABasicAnimation animationWithKeyPath:@"position"];
        slide.additive = YES;
        slide.fromValue = [NSValue valueWithCGPoint:CGPointMake(dx, dy)];
        slide.toValue = [NSValue valueWithCGPoint:CGPointZero];
        slide.duration = sp.duration;
        slide.timingFunction = CC26ResizeTiming(sp);
        [mover.layer addAnimation:slide forKey:@"cc26.slide"];
        started = YES;
    }
    return started;
}

static void CC26AnimateChromeRefreshExcluding(UIViewController *ov, NSString *excludeMid) {
    if (!ov || !ov.view || !gEditModeActive) return;
    CC26AnimSpec sp = CC26ResizeSpec();
    UIViewPropertyAnimator *anim = CC26BezierAnimator(sp.duration, sp.c1x, sp.c1y, sp.c2x, sp.c2y);
    [anim addAnimations:^{
        for (UIViewController *m in ModuleControllers(ov)) {
            if (excludeMid.length && [CC26Mid(m) isEqualToString:excludeMid]) continue;
            CC26ApplyChrome(m, ov);
        }
    }];
    [anim startAnimation];
    CC26BringChromeToFront(ov);
}

static void CC26AnimateChromeRefresh(UIViewController *ov) {
    CC26AnimateChromeRefreshExcluding(ov, nil);
}

static void CC26AdjustStatusBar(UIViewController *ov) {
    if (!ov) return;
    CC26 *cc26 = [CC26 shared];
    if ([cc26 respondsToSelector:@selector(adjustStatusBarForOverlay:)]) {
        [cc26 adjustStatusBarForOverlay:ov];
    }
}

static void CC26SettleEditLayoutEx(UIViewController *ov, BOOL refreshChrome) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (!gEditModeActive) return;
        if (refreshChrome) CC26AnimateChromeRefresh(ov);
        CC26AdjustStatusBar(ov);
    });
    static const double delays[] = { 0.30, 0.65 };
    for (size_t i = 0; i < sizeof(delays) / sizeof(delays[0]); i++) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delays[i] * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (!gEditModeActive) return;
            CC26AdjustStatusBar(ov);
        });
    }
}

static void CC26SettleEditLayout(UIViewController *ov) {
    CC26SettleEditLayoutEx(ov, YES);
}

static void CC26ForceExitEdit(UIViewController *ov) {
    gEditModeActive = NO;
    gCC26EditEpoch++;
    gCC26PendingResizeID = nil;
    gCC26PendingResizeSize = (CCUILayoutSize){0, 0};
    gCC26PendingResizeLastTouch = 0;
    if (!ov || !ov.view) return;
    for (UIViewController *m in ModuleControllers(ov)) CC26StripChrome(m);
    [[ov.view viewWithTag:kCC26ShieldTag] removeFromSuperview];
    [[ov.view viewWithTag:kCC26ResetTag] removeFromSuperview];
    [[ov.view viewWithTag:kCC26HintTag] removeFromSuperview];
    NSArray<UIGestureRecognizer *> *disabled = objc_getAssociatedObject(ov, kCC26DisabledGesturesKey);
    for (UIGestureRecognizer *gr in disabled) gr.enabled = YES;
    objc_setAssociatedObject(ov, kCC26DisabledGesturesKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    UIView *ind = [ov.view viewWithTag:kPageIndicatorTag];
    ind.userInteractionEnabled = YES;
    ind.alpha = 1.0;
}

@interface CC26EditProxy : NSObject <UIGestureRecognizerDelegate>
+ (instancetype)shared;
- (void)bgHold:(UILongPressGestureRecognizer *)g;
- (void)shieldPan:(UIGestureRecognizer *)g;
- (void)shieldTap:(UITapGestureRecognizer *)g;
- (void)resizePan:(UIPanGestureRecognizer *)g;
- (void)removeTap:(UIButton *)b;
- (void)resetTap:(UIButton *)b;
- (void)exitEditOn:(UIViewController *)ov;
- (void)compactGridAfterRemoval:(UIViewController *)ov;
- (void)relayout:(UIViewController *)ov;
- (BOOL)computeArrangementForMid:(NSString *)mid
                             col:(NSUInteger)col
                             row:(NSUInteger)row
                               w:(NSUInteger)w
                               h:(NSUInteger)h
                         overlay:(UIViewController *)ov;
- (void)commitResize:(NSString *)mid w:(NSUInteger)w h:(NSUInteger)h overlay:(UIViewController *)ov;
@end

@implementation CC26EditProxy
+ (instancetype)shared {
    static CC26EditProxy *s; static dispatch_once_t o;
    dispatch_once(&o, ^{ s = [self new]; });
    return s;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)g shouldReceiveTouch:(UITouch *)touch {
    if (!CC26EditAllowed()) return NO;
    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return NO;
    if (g.view != ov.view) return YES;
    if ([g isKindOfClass:UILongPressGestureRecognizer.class]) {
        UIView *v = touch.view;
        while (v) {
            for (UIViewController *m in ModuleControllers(ov)) {
                if (m.view == v) return NO;
            }
            if (v == ov.view) break;
            v = v.superview;
        }
    }
    return YES;
}

- (void)bgHold:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    if (!CC26EditAllowed()) return;
    CC26RefreshGridConstants();
    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;

    if (gEditModeActive) {
    if ([ov.view viewWithTag:kCC26ShieldTag].superview) return;
    CC26ForceExitEdit(ov);
    return;
    }

    CGPoint lp = [g locationInView:ov.view];
    if (CC26ModuleAtPoint(lp, ov)) return;

    gEditModeActive = YES;
    gCC26EditEpoch++;
    gEditModeEnteredAt = CACurrentMediaTime();
    gCC26PendingResizeID = nil;
    gCC26PendingResizeSize = (CCUILayoutSize){0, 0};
    gCC26PendingResizeLastTouch = 0;
    if (gHapticsEnabled) Haptic();

    for (UIViewController *m in ModuleControllers(ov)) {
        CC26EnsureBaseSize(m, ov);
        CC26ApplyRadiusToModule(m);
    }

    CC26EditShield *shield = (CC26EditShield *)[ov.view viewWithTag:kCC26ShieldTag];
    if (!shield) {
        shield = [[CC26EditShield alloc] initWithFrame:ov.view.bounds];
        shield.tag = kCC26ShieldTag;
        shield.backgroundColor = UIColor.clearColor;
        shield.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        shield.userInteractionEnabled = YES;

        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(shieldPan:)];
        pan.maximumNumberOfTouches = 1;
        pan.cancelsTouchesInView = YES;

        UILongPressGestureRecognizer *hold = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(shieldPan:)];
        hold.minimumPressDuration = 0.22;
        hold.allowableMovement = 12.0;
        hold.cancelsTouchesInView = YES;

        [pan requireGestureRecognizerToFail:hold];

        [shield addGestureRecognizer:pan];
        [shield addGestureRecognizer:hold];

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(shieldTap:)];
        tap.cancelsTouchesInView = NO;
        [shield addGestureRecognizer:tap];

        [ov.view addSubview:shield];
    } else if (shield.superview != ov.view) {
        [shield removeFromSuperview];
        [ov.view addSubview:shield];
    }
    shield.hidden = NO;
    shield.frame = ov.view.bounds;

    NSMutableArray<UIGestureRecognizer *> *disabled = [NSMutableArray array];
    UIView *walk = ov.view.superview;
    while (walk) {
        for (UIGestureRecognizer *gr in walk.gestureRecognizers) {
            if (!gr.enabled) continue;
            if ([gr isKindOfClass:UIPanGestureRecognizer.class] ||
                [gr isKindOfClass:UIPinchGestureRecognizer.class] ||
                [gr isKindOfClass:UISwipeGestureRecognizer.class]) {
                gr.enabled = NO;
                [disabled addObject:gr];
            }
        }
        walk = walk.superview;
    }
    objc_setAssociatedObject(ov, kCC26DisabledGesturesKey, disabled, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    for (UIViewController *m in ModuleControllers(ov)) CC26ApplyChrome(m, ov);

    UIButton *reset = (UIButton *)[ov.view viewWithTag:kCC26ResetTag];
    if (!reset) {
        reset = CC26MakeResetButton();
        [reset addTarget:self action:@selector(resetTap:) forControlEvents:UIControlEventTouchUpInside];
        [ov.view addSubview:reset];
    }
    CGFloat safeTop = ov.view.safeAreaInsets.top;
    if (safeTop < 1.0) safeTop = 20.0;
    reset.center = CGPointMake(CGRectGetMidX(ov.view.bounds), safeTop + 32.0);
    reset.alpha = 0.0;
    reset.transform = CGAffineTransformMakeTranslation(0, -8);
    UIViewPropertyAnimator *resetAnim = CC26BezierAnimator(0.32, 0.32, 0.72, 0.0, 1.0);
    [resetAnim addAnimations:^{
        reset.alpha = 1.0;
        reset.transform = CGAffineTransformIdentity;
    }];
    [resetAnim startAnimationAfterDelay:0.05];
    [ov.view bringSubviewToFront:reset];

    UIView *ind = [ov.view viewWithTag:kPageIndicatorTag];
    ind.userInteractionEnabled = NO;
    [UIView animateWithDuration:0.2 animations:^{ ind.alpha = 0.0; }];
}

- (void)shieldTap:(UITapGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateRecognized) return;
    if (!gEditModeActive) return;
    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;
    CGPoint pt = [g locationInView:ov.view];
    if (CC26ModuleAtPoint(pt, ov)) return;
    [self exitEditOn:ov];
}

- (void)exitEditOn:(UIViewController *)ov {
    if (!gEditModeActive) return;
    gEditModeActive = NO;
    gCC26EditEpoch++;
    NSUInteger epochAtExit = gCC26EditEpoch;
    gCC26PendingResizeID = nil;
    gCC26PendingResizeSize = (CCUILayoutSize){0, 0};
    gCC26PendingResizeLastTouch = 0;
    if (gHapticsEnabled) Haptic();

    NSMutableArray<UIView *> *chromeViews = [NSMutableArray array];
    for (UIViewController *m in ModuleControllers(ov)) {
        UIView *v = m.view;
        if (!v) continue;
        UIView *b = objc_getAssociatedObject(v, kCC26BorderKey);
        UIButton *rm = objc_getAssociatedObject(v, kCC26RemoveKey);
        UIButton *rz = objc_getAssociatedObject(v, kCC26ResizeKey);
        if (b) [chromeViews addObject:b];
        if (rm) [chromeViews addObject:rm];
        if (rz) [chromeViews addObject:rz];
        objc_setAssociatedObject(CC26ModuleButtonView(v), kCC26IconPinKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(v, kCC26BorderKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(v, kCC26RemoveKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(v, kCC26ResizeKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    if (chromeViews.count) {
        UIViewPropertyAnimator *exitAnim = CC26BezierAnimator(0.24, 0.4, 0.0, 0.2, 1.0);
        [exitAnim addAnimations:^{
            for (UIView *v in chromeViews) {
                v.alpha = 0.0;
                v.transform = CGAffineTransformMakeScale(0.85, 0.85);
            }
        }];
        [exitAnim addCompletion:^(__unused UIViewAnimatingPosition pos) {
            if (epochAtExit != gCC26EditEpoch) return;
            for (UIView *v in chromeViews) [v removeFromSuperview];
        }];
        [exitAnim startAnimation];
    }

    UIView *shield = [ov.view viewWithTag:kCC26ShieldTag];
    [shield removeFromSuperview];

    NSArray<UIGestureRecognizer *> *disabled = objc_getAssociatedObject(ov, kCC26DisabledGesturesKey);
    for (UIGestureRecognizer *gr in disabled) gr.enabled = YES;
    objc_setAssociatedObject(ov, kCC26DisabledGesturesKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    UIView *reset = [ov.view viewWithTag:kCC26ResetTag];
    reset.tag = 0;
    UIViewPropertyAnimator *resetOut = CC26BezierAnimator(0.2, 0.4, 0.0, 0.2, 1.0);
    [resetOut addAnimations:^{
        reset.alpha = 0.0;
        reset.transform = CGAffineTransformMakeTranslation(0, -8);
    }];
    [resetOut addCompletion:^(__unused UIViewAnimatingPosition pos) {
        if (epochAtExit != gCC26EditEpoch) return;
        [reset removeFromSuperview];
    }];
    [resetOut startAnimation];

    [[ov.view viewWithTag:kCC26HintTag] removeFromSuperview];

    UIView *ind = [ov.view viewWithTag:kPageIndicatorTag];
    ind.userInteractionEnabled = YES;
    [UIView animateWithDuration:0.2 animations:^{ ind.alpha = 1.0; }];
}

- (BOOL)computeArrangementForMid:(NSString *)mid
                             col:(NSUInteger)col
                             row:(NSUInteger)row
                               w:(NSUInteger)w
                               h:(NSUInteger)h
                         overlay:(UIViewController *)ov {
    CC26EnsureStore();
    NSUInteger page = (NSUInteger)gCurrentPage;

    if (!CC26DragSizeAllowedForModule(mid, w, h)) return NO;

    NSArray<NSNumber *> *oldO = CC26GetOrigin(mid);
    if (oldO.count < 2) return NO;
    NSUInteger oldCol = oldO[0].unsignedIntegerValue;
    NSUInteger oldAbs = oldO[1].unsignedIntegerValue;
    NSUInteger oldRow = oldAbs % kCC26Rows;

    NSUInteger oldW = 1, oldH = 1;
    CC26EffectiveSize(mid, &oldW, &oldH);
    if (oldCol == col && oldRow == row && (oldAbs / kCC26Rows) == page &&
        oldW == w && oldH == h) {
        return NO;
    }

    NSMutableDictionary<NSString *, NSValue *> *snapshot = [NSMutableDictionary dictionary];
    for (UIViewController *m in ModuleControllers(ov)) {
        NSString *oid = CC26Mid(m);
        if (!oid.length || [oid isEqualToString:mid]) continue;
        NSArray<NSNumber *> *o = CC26GetOrigin(oid);
        if (o.count < 2) continue;
        NSUInteger oc = o[0].unsignedIntegerValue;
        NSUInteger oa = o[1].unsignedIntegerValue;
        if (oa / kCC26Rows != page) continue;
        NSUInteger orow = oa % kCC26Rows;
        NSUInteger ow = 1, oh = 1;
        CC26EffectiveSize(oid, &ow, &oh);
        CC26Rect r = {oc, orow, ow, oh};
        snapshot[oid] = [NSValue value:&r withObjCType:@encode(CC26Rect)];
    }

    NSMutableDictionary<NSString *, NSValue *> *placed = [NSMutableDictionary dictionaryWithDictionary:snapshot];
    CC26Rect targetRect = {col, row, w, h};
    placed[mid] = [NSValue value:&targetRect withObjCType:@encode(CC26Rect)];

    NSMutableArray<NSString *> *colliders = [NSMutableArray array];
    for (NSString *oid in snapshot) {
        CC26Rect other = {};
        [snapshot[oid] getValue:&other];
        if (CC26RectsOverlap(targetRect, other)) [colliders addObject:oid];
    }

    [colliders sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
        CC26Rect ra = {}, rb = {};
        [snapshot[a] getValue:&ra];
        [snapshot[b] getValue:&rb];
        if (ra.r != rb.r) return ra.r < rb.r ? NSOrderedAscending : NSOrderedDescending;
        if (ra.c != rb.c) return ra.c < rb.c ? NSOrderedAscending : NSOrderedDescending;
        return [a compare:b];
    }];

    NSUInteger visibleCap = CC26VisibleRowCap(ov);

    for (NSString *oid in colliders) {
        CC26Rect orig = {};
        [snapshot[oid] getValue:&orig];
        [placed removeObjectForKey:oid];
        NSUInteger maxTopRow = (visibleCap + 1 >= orig.h) ? (visibleCap - orig.h + 1) : 0;
        NSUInteger newC = 0, newR = 0;
        if (!CC26FindFreeCellFor(placed, orig.c, orig.r, orig.w, orig.h, maxTopRow, &newC, &newR)) {
            return NO;
        }
        CC26Rect np = {newC, newR, orig.w, orig.h};
        placed[oid] = [NSValue value:&np withObjCType:@encode(CC26Rect)];
    }

    for (NSString *oid in placed) {
        CC26Rect r = {};
        [placed[oid] getValue:&r];
        CC26SetOrigin(oid, @[@(r.c), @(page * kCC26Rows + r.r)]);
    }
    return YES;
}

- (void)shieldPan:(UIGestureRecognizer *)g {
    if (!CC26EditAllowed()) return;
    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;
    CC26RefreshGridConstants();

    if (g.state == UIGestureRecognizerStateBegan) {
        CGPoint pt = [g locationInView:ov.view];
        UIViewController *src = CC26ModuleAtPoint(pt, ov);
        if (!src) return;
        NSString *mid = CC26Mid(src);
        if (!mid.length) return;

        CGRect vis = CC26VisibleFrame(src, ov);
        CGPoint grab = CGPointMake(pt.x - CGRectGetMinX(vis), pt.y - CGRectGetMinY(vis));

        UIView *shadow = [[UIView alloc] initWithFrame:vis];
        shadow.tag = kCC26ProxyShadowTag;
        shadow.userInteractionEnabled = NO;
        shadow.backgroundColor = UIColor.clearColor;
        shadow.layer.shadowColor = UIColor.blackColor.CGColor;
        shadow.layer.shadowOpacity = 0.35;
        shadow.layer.shadowRadius = 16.0;
        shadow.layer.shadowOffset = CGSizeMake(0, 8);
        shadow.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:shadow.bounds
                                                            cornerRadius:src.view.layer.cornerRadius].CGPath;
        [ov.view addSubview:shadow];

        BOOL liquidassActive = CC26LIQIsActive();
        CGFloat proxyRadius = src.view.layer.cornerRadius;

        UIView *proxy;
        if (liquidassActive) {
            proxy = [[CC26LiveGlassProxyView alloc] initWithFrame:shadow.bounds];
        } else {
            proxy = [[UIView alloc] initWithFrame:shadow.bounds];
        }
        proxy.tag = kCC26ProxyTag;
        proxy.userInteractionEnabled = NO;
        proxy.layer.cornerRadius = proxyRadius;
        proxy.layer.cornerCurve = kCACornerCurveContinuous;
        proxy.layer.masksToBounds = YES;

        if (liquidassActive) {
            proxy.backgroundColor = UIColor.clearColor;
            if (kClsCABackdropLayer && [proxy.layer isKindOfClass:kClsCABackdropLayer]) {
                [proxy.layer setValue:@NO  forKey:@"layerUsesCoreImageFilters"];
                [proxy.layer setValue:@YES forKey:@"windowServerAware"];
                [proxy.layer setValue:@"dylv.liquidglass.sharedGroup" forKey:@"groupName"];
                [proxy.layer setValue:@"dylv.liquidglass" forKey:@"groupNamespace"];
                [proxy.layer setValue:@(0.5) forKey:@"scale"];
                id glassFilter = CC26LIQBuildGlassFilter();
                if (glassFilter) proxy.layer.filters = @[glassFilter];
            }
        } else {
            proxy.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.6];
        }

        UIImage *snapImage = CC26SnapshotContentOnly(src.view, liquidassActive);
        if (snapImage) {
            UIImageView *snap = [[UIImageView alloc] initWithImage:snapImage];
            snap.frame = proxy.bounds;
            snap.contentMode = UIViewContentModeScaleToFill;
            snap.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            [proxy addSubview:snap];
        }
        [shadow addSubview:proxy];

        UIView *pres = objc_getAssociatedObject(src.view, kCC26PresKey);
        [UIView animateWithDuration:0.12
                              delay:0.0
                            options:UIViewAnimationOptionCurveEaseOut |
                                    UIViewAnimationOptionBeginFromCurrentState |
                                    UIViewAnimationOptionAllowUserInteraction
                         animations:^{
            src.view.alpha = 0.0;
            pres.alpha = 0.0;
        } completion:nil];
        for (UIViewController *m in ModuleControllers(ov)) CC26StripChrome(m);

        NSDictionary *origLayout = [gEditOrigins copy] ?: @{};
        objc_setAssociatedObject(g, kCC26OrigLayoutKey, origLayout, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

        objc_setAssociatedObject(g, kCC26LastCellKey, @[@(NSIntegerMax), @(NSIntegerMax)], OBJC_ASSOCIATION_RETAIN_NONATOMIC);

        objc_setAssociatedObject(g, kCC26DragSrcKey,   src,    OBJC_ASSOCIATION_ASSIGN);
        objc_setAssociatedObject(g, kCC26DragProxyKey, shadow, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(g, kCC26DragGrabKey,  [NSValue valueWithCGPoint:grab], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        if (gHapticsEnabled) Haptic();

    } else if (g.state == UIGestureRecognizerStateChanged) {
        UIViewController *src = objc_getAssociatedObject(g, kCC26DragSrcKey);
        UIView *shadow = objc_getAssociatedObject(g, kCC26DragProxyKey);
        NSValue *gv = objc_getAssociatedObject(g, kCC26DragGrabKey);
        if (!src || !shadow || !gv) return;
        CGPoint grab = gv.CGPointValue;
        CGPoint pt = [g locationInView:ov.view];
        NSString *mid = CC26Mid(src);
        NSUInteger w = 1, h = 1;
        CC26EffectiveSize(mid, &w, &h);
        CGPoint base = CC26GridBase(ov);

        CGRect f = shadow.frame;
        f.origin = CGPointMake(pt.x - grab.x, pt.y - grab.y);
        shadow.frame = f;

        NSInteger col = (NSInteger)lround((CGRectGetMinX(f) - base.x) / kCC26Step);
        NSInteger row = (NSInteger)lround((CGRectGetMinY(f) - base.y) / kCC26Step);
        col = MAX(0, MIN((NSInteger)kCC26Cols - (NSInteger)w, col));
        NSUInteger cap = CC26VisibleRowCap(ov);
        NSInteger maxRow = MAX(0, (NSInteger)cap - (NSInteger)h + 1);
        row = MAX(0, MIN(maxRow, row));

        NSArray<NSNumber *> *last = objc_getAssociatedObject(g, kCC26LastCellKey);
        if (!last ||
            [last[0] integerValue] != col ||
            [last[1] integerValue] != row) {
            objc_setAssociatedObject(g, kCC26LastCellKey, @[@(col), @(row)], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            if ([self computeArrangementForMid:mid
                                          col:(NSUInteger)col
                                          row:(NSUInteger)row
                                            w:w h:h
                                      overlay:ov]) {
                [self relayout:ov];
            }
        }

    } else if (g.state == UIGestureRecognizerStateEnded ||
               g.state == UIGestureRecognizerStateCancelled ||
               g.state == UIGestureRecognizerStateFailed) {
        UIViewController *src = objc_getAssociatedObject(g, kCC26DragSrcKey);
        UIView *shadow = objc_getAssociatedObject(g, kCC26DragProxyKey);
        __block UIViewController *heldSrc = src;

        if (g.state != UIGestureRecognizerStateEnded) {
            NSDictionary *origLayout = objc_getAssociatedObject(g, kCC26OrigLayoutKey);
            if (origLayout) {
                CC26EnsureStore();
                [gEditOrigins removeAllObjects];
                [gEditOrigins addEntriesFromDictionary:origLayout];
                CC26SaveStore();
                [self relayout:ov];
            }
        } else {
            CC26SaveStore();
        }

        if (shadow) {
            [shadow removeFromSuperview];
        }
        NSUInteger epochAtDragEnd = gCC26EditEpoch;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.06 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (epochAtDragEnd != gCC26EditEpoch) return;
            if (!gEditModeActive) return;
            UIViewController *releaseSrc = heldSrc;
            if (releaseSrc) {
                UIView *pres = objc_getAssociatedObject(releaseSrc.view, kCC26PresKey);
                [UIView animateWithDuration:0.18
                                      delay:0.0
                                    options:UIViewAnimationOptionCurveEaseOut |
                                            UIViewAnimationOptionBeginFromCurrentState |
                                            UIViewAnimationOptionAllowUserInteraction
                                 animations:^{
                    releaseSrc.view.alpha = 1.0;
                    pres.alpha = 1.0;
                } completion:nil];
            }
            for (UIViewController *m in ModuleControllers(ov)) {
                CC26ApplyRadiusToModule(m);
                CC26ApplyChrome(m, ov);
                CC26RefreshPresentation(m, ov);
            }
            UIView *shield = [ov.view viewWithTag:kCC26ShieldTag];
            if (shield) [ov.view bringSubviewToFront:shield];
            for (UIViewController *m in ModuleControllers(ov)) {
                UIButton *rm = objc_getAssociatedObject(m.view, kCC26RemoveKey);
                UIButton *rz = objc_getAssociatedObject(m.view, kCC26ResizeKey);
                if (rm) [ov.view bringSubviewToFront:rm];
                if (rz) [ov.view bringSubviewToFront:rz];
                UIView *pr = objc_getAssociatedObject(m.view, kCC26PresKey);
                if (pr) [ov.view bringSubviewToFront:pr];
            }
            UIView *rp = [ov.view viewWithTag:kCC26ResetTag];
            if (rp) [ov.view bringSubviewToFront:rp];
        });

        objc_setAssociatedObject(g, kCC26DragSrcKey,   nil, OBJC_ASSOCIATION_ASSIGN);
        objc_setAssociatedObject(g, kCC26DragProxyKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(g, kCC26DragGrabKey,  nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(g, kCC26LastCellKey,  nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(g, kCC26OrigLayoutKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}

- (void)compactGridAfterRemoval:(UIViewController *)ov {
    CC26EnsureStore();
    NSUInteger page = (NSUInteger)gCurrentPage;
    NSUInteger cap  = CC26VisibleRowCap(ov);

    NSMutableDictionary<NSString *, NSValue *> *placed = [NSMutableDictionary dictionary];
    NSMutableArray<NSDictionary *> *entries = [NSMutableArray array];

    for (UIViewController *m in ModuleControllers(ov)) {
        NSString *mid = CC26Mid(m);
        if (!mid.length) continue;
        NSArray<NSNumber *> *o = CC26GetOrigin(mid);
        if (o.count < 2) continue;
        NSUInteger abs = o[1].unsignedIntegerValue;
        if (abs / kCC26Rows != page) continue;

        NSUInteger w = 1, h = 1;
        CC26EffectiveSize(mid, &w, &h);
        NSUInteger c = o[0].unsignedIntegerValue;
        NSUInteger r = abs % kCC26Rows;

        CC26Rect rect = {c, r, w, h};
        placed[mid] = [NSValue value:&rect withObjCType:@encode(CC26Rect)];
        [entries addObject:@{@"mid":mid, @"c":@(c), @"r":@(r), @"w":@(w), @"h":@(h)}];
    }

    [entries sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        NSInteger ar = [a[@"r"] integerValue], br = [b[@"r"] integerValue];
        if (ar != br) return ar < br ? NSOrderedAscending : NSOrderedDescending;
        NSInteger ac = [a[@"c"] integerValue], bc = [b[@"c"] integerValue];
        return ac < bc ? NSOrderedAscending : (ac > bc ? NSOrderedDescending : NSOrderedSame);
    }];

    for (NSDictionary *e in entries) {
        NSString *mid = e[@"mid"];
        NSUInteger w = [e[@"w"] unsignedIntegerValue];
        NSUInteger h = [e[@"h"] unsignedIntegerValue];
        NSInteger oc = [e[@"c"] integerValue];
        NSInteger orr = [e[@"r"] integerValue];

        [placed removeObjectForKey:mid];

        NSInteger maxC = (NSInteger)kCC26Cols - (NSInteger)w;
        NSInteger maxR = (NSInteger)MIN(cap, kCC26Rows - 1) - (NSInteger)h + 1;
        NSInteger bestC = oc, bestR = orr;
        NSInteger bestScore = NSIntegerMax;
        BOOL found = NO;

        for (NSInteger r = 0; r <= maxR; r++) {
            for (NSInteger c = 0; c <= maxC; c++) {
                if (r > orr) continue;
                if (r == orr && c >= oc) continue;

                CC26Rect t = {(NSUInteger)c, (NSUInteger)r, w, h};
                BOOL ok = YES;
                for (NSValue *v in placed.allValues) {
                    CC26Rect o = {};
                    [v getValue:&o];
                    if (CC26RectsOverlap(t, o)) { ok = NO; break; }
                }
                if (!ok) continue;

                NSInteger score = r * (NSInteger)kCC26Cols + c;
                if (score < bestScore) {
                    bestScore = score;
                    bestC = c;
                    bestR = r;
                    found = YES;
                }
            }
        }

        CC26Rect rect = {(NSUInteger)bestC, (NSUInteger)bestR, w, h};
        placed[mid] = [NSValue value:&rect withObjCType:@encode(CC26Rect)];
        if (found) {
            CC26SetOrigin(mid, @[@(bestC), @(page * kCC26Rows + bestR)]);
        }
    }
    CC26SaveStore();
}

- (void)relayout:(UIViewController *)ov {
    UIViewController *col = ModuleCollection(ov);
    if (!col) return;

    SEL providerSel = NSSelectorFromString(@"_activePositionProvider");
    id provider = [col respondsToSelector:providerSel]
        ? ((id (*)(id, SEL))objc_msgSend)(col, providerSel) : nil;
    SEL regenSel = NSSelectorFromString(@"regenerateRectsWithOrderedIdentifiers:orderedSizes:");
    if (provider && [provider respondsToSelector:regenSel]) {
        NSMutableArray<NSString *> *ids = [NSMutableArray array];
        NSMutableArray<NSValue *> *sizes = [NSMutableArray array];
        for (UIViewController *m in ModuleControllers(ov)) {
            NSString *mid = CC26Mid(m);
            if (!mid.length) continue;
            NSUInteger w = 1, h = 1;
            CC26EffectiveSize(mid, &w, &h);
            CCUILayoutSize sz = {w, h};
            [ids addObject:mid];
            [sizes addObject:[NSValue value:&sz withObjCType:@encode(CCUILayoutSize)]];
        }
        if (ids.count) {
            ((void (*)(id, SEL, id, id))objc_msgSend)(provider, regenSel, ids, sizes);
        }
    }

    for (UIViewController *m in ModuleControllers(ov)) [m.view setNeedsLayout];
    [col.view setNeedsLayout];

    void (^fixups)(void) = ^{
        for (UIViewController *m in ModuleControllers(ov)) {
            UIView *superview = m.view.superview;
            if (!superview || superview == col.view) continue;
            NSString *sn = NSStringFromClass(superview.class);
            if (![sn containsString:@"ContentModuleContainer"] &&
                ![sn containsString:@"ModuleWrapper"]) continue;
            CGRect target = superview.bounds;
            if (!CGRectEqualToRect(m.view.bounds, target)) {
                m.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                m.view.frame = target;
            }
        }
        for (UIViewController *m in ModuleControllers(ov)) CC26ApplyRadiusToModule(m);
    };

    if (gExperimentalPagingEnabled) {
        UIViewPropertyAnimator *relayout = CC26BezierAnimator(0.58, 0.32, 0.72, 0.0, 1.0);
        [relayout addAnimations:^{
            for (UIViewController *m in ModuleControllers(ov)) [m.view layoutIfNeeded];
            [col.view layoutIfNeeded];
        }];
        [relayout addCompletion:^(UIViewAnimatingPosition finalPosition) {
            if (finalPosition != UIViewAnimatingPositionEnd) return;
            fixups();
        }];
        [relayout startAnimation];
    } else {
        [UIView performWithoutAnimation:^{
            for (UIViewController *m in ModuleControllers(ov)) [m.view layoutIfNeeded];
            [col.view layoutIfNeeded];
        }];
        fixups();
    }
}

static void CC26DiagDump(UIViewController *ov, NSString *why);   // TEMP diagnostic, defined near the end

- (void)resizePan:(UIPanGestureRecognizer *)g {
    if (!CC26EditAllowed()) return;
    UIButton *btn = (UIButton *)g.view;
    NSString *mid = objc_getAssociatedObject(btn, kCC26MidKey);
    if (!mid.length) return;
    CC26RefreshGridConstants();
    gCC26PendingResizeLastTouch = CACurrentMediaTime();
    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;

    if (g.state == UIGestureRecognizerStateBegan) {
        CC26EnsureStore();
        NSUInteger sw = 1, sh = 1;
        CC26EffectiveSize(mid, &sw, &sh);
        objc_setAssociatedObject(g, kCC26StartSzKey, @[@(sw), @(sh)], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        gCC26PendingResizeID = [mid copy];
        gCC26PendingResizeSize = (CCUILayoutSize){sw, sh};
        if (gHapticsEnabled) Haptic();

    } else if (g.state == UIGestureRecognizerStateChanged) {
        NSArray<NSNumber *> *s = objc_getAssociatedObject(g, kCC26StartSzKey);
        if (s.count < 2) return;
        NSUInteger sw = s[0].unsignedIntegerValue, sh = s[1].unsignedIntegerValue;
        CGPoint t = [g translationInView:ov.view];
        CCUILayoutSize next = CC26ResizeCandidate(mid, sw, sh, t);
        if (!CC26SizeAllowed(next.width, next.height)) {
            next = gCC26PendingResizeSize;
        }
        if (next.width != gCC26PendingResizeSize.width ||
            next.height != gCC26PendingResizeSize.height) {
            gCC26PendingResizeSize = next;

            NSArray<NSNumber *> *cur = CC26GetOrigin(mid);
            if (cur.count >= 2) {
                NSUInteger cCol = cur[0].unsignedIntegerValue;
                NSUInteger cAbs = cur[1].unsignedIntegerValue;
                NSUInteger cRow = cAbs % kCC26Rows;
                // A wider size (4x2) slides the widget left so it stays on the grid.
                if (cCol + next.width > kCC26Cols) cCol = kCC26Cols - next.width;
                [self computeArrangementForMid:mid
                                           col:cCol
                                           row:cRow
                                             w:next.width
                                             h:next.height
                                       overlay:ov];
            }

            [self relayout:ov];
            CC26SettleEditLayout(ov);
        }

    } else if (g.state == UIGestureRecognizerStateEnded ||
               g.state == UIGestureRecognizerStateCancelled ||
               g.state == UIGestureRecognizerStateFailed) {
        CCUILayoutSize p = gCC26PendingResizeSize;
        gCC26PendingResizeID = nil;
        gCC26PendingResizeSize = (CCUILayoutSize){0, 0};
        // A relayout during the drag can cancel the pan; the size shown when the finger lifts
        // is still the one the user chose, so keep it (it used to fall back to the old size).
        if ((g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) &&
            p.width && p.height && CC26SizeAllowed(p.width, p.height)) {
            [self commitResize:mid w:p.width h:p.height overlay:ov];
        }
        objc_setAssociatedObject(g, kCC26StartSzKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [self relayout:ov];
        CC26SettleEditLayout(ov);
        NSUInteger epochAtResizeEnd = gCC26EditEpoch;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.30 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (epochAtResizeEnd != gCC26EditEpoch) return;
            if (!gEditModeActive) return;
            for (UIViewController *m in ModuleControllers(ov)) {
                CC26ApplyRadiusToModule(m);
                CC26ApplyChrome(m, ov);
                CC26RefreshPresentation(m, ov);
            }
            UIView *shield = [ov.view viewWithTag:kCC26ShieldTag];
            if (shield) [ov.view bringSubviewToFront:shield];
            for (UIViewController *m in ModuleControllers(ov)) {
                UIButton *rm = objc_getAssociatedObject(m.view, kCC26RemoveKey);
                UIButton *rz = objc_getAssociatedObject(m.view, kCC26ResizeKey);
                if (rm) [ov.view bringSubviewToFront:rm];
                if (rz) [ov.view bringSubviewToFront:rz];
                UIView *pr = objc_getAssociatedObject(m.view, kCC26PresKey);
                if (pr) [ov.view bringSubviewToFront:pr];
            }
            UIView *rp = [ov.view viewWithTag:kCC26ResetTag];
            if (rp) [ov.view bringSubviewToFront:rp];
        });
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.62 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (epochAtResizeEnd != gCC26EditEpoch) return;
            if (!gEditModeActive) return;
            for (UIViewController *m in ModuleControllers(ov)) {
                CC26ApplyRadiusToModule(m);
                CC26RefreshPresentation(m, ov);
            }
            CC26DiagDump(ov, [@"resize " stringByAppendingString:mid]);
        });
    }
}

- (void)commitResize:(NSString *)mid w:(NSUInteger)w h:(NSUInteger)h overlay:(UIViewController *)ov {
    CC26EnsureStore();
    if (!CC26SizeAllowed(w, h)) return;

    NSArray<NSNumber *> *o = CC26GetOrigin(mid);
    if (o.count < 2) return;
    NSUInteger col = o[0].unsignedIntegerValue;
    NSUInteger absRow = o[1].unsignedIntegerValue;
    NSUInteger page = absRow / kCC26Rows;
    NSUInteger row = absRow % kCC26Rows;
    // Keep the size the user dragged to (4x2 included): move the origin instead of trimming it.
    if (col + w > kCC26Cols) col = kCC26Cols - w;
    if (row + h > kCC26Rows) row = kCC26Rows - h;
    if (!CC26SizeAllowed(w, h)) return;

    NSUInteger capR = CC26VisibleRowCap(ov);
    // Keep the resized module on the visible rows: a widget grown at the bottom moves up
    // instead of falling back to its old size.
    if (capR + 1 >= h && row + h > capR + 1) row = capR + 1 - h;

    NSMutableDictionary<NSString *, NSValue *> *snapshot = [NSMutableDictionary dictionary];
    for (UIViewController *m in ModuleControllers(ov)) {
        NSString *oid = CC26Mid(m);
        if (!oid.length || [oid isEqualToString:mid]) continue;
        NSArray<NSNumber *> *oo = CC26GetOrigin(oid);
        if (oo.count < 2) continue;
        NSUInteger oc = oo[0].unsignedIntegerValue;
        NSUInteger oa = oo[1].unsignedIntegerValue;
        if (oa / kCC26Rows != page) continue;
        NSUInteger orow = oa % kCC26Rows;
        NSUInteger ow = 1, oh = 1;
        CC26EffectiveSize(oid, &ow, &oh);
        CC26Rect r = {oc, orow, ow, oh};
        snapshot[oid] = [NSValue value:&r withObjCType:@encode(CC26Rect)];
    }

    BOOL resolved = NO;

    if (row + h <= capR + 1) {
        CC26Rect targetRect = {col, row, w, h};

        NSMutableDictionary<NSString *, NSValue *> *placed =
            [NSMutableDictionary dictionaryWithDictionary:snapshot];

        NSMutableArray<NSString *> *colliders = [NSMutableArray array];
        for (NSString *oid in snapshot) {
            CC26Rect other = {};
            [snapshot[oid] getValue:&other];
            if (CC26RectsOverlap(targetRect, other)) [colliders addObject:oid];
        }
        for (NSString *oid in colliders) [placed removeObjectForKey:oid];
        placed[mid] = [NSValue value:&targetRect withObjCType:@encode(CC26Rect)];

        [colliders sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
            CC26Rect ra = {}, rb = {};
            [snapshot[a] getValue:&ra];
            [snapshot[b] getValue:&rb];
            if (ra.r != rb.r) return ra.r < rb.r ? NSOrderedAscending : NSOrderedDescending;
            if (ra.c != rb.c) return ra.c < rb.c ? NSOrderedAscending : NSOrderedDescending;
            return [a compare:b];
        }];

        NSMutableArray<NSString *> *overflow = [NSMutableArray array];
        for (NSString *oid in colliders) {
            CC26Rect orig = {};
            [snapshot[oid] getValue:&orig];
            NSUInteger cMaxRow = (capR + 1 >= orig.h) ? (capR - orig.h + 1) : 0;
            NSUInteger nc = 0, nr = 0;
            if (!CC26FindFreeCellFor(placed, orig.c, orig.r, orig.w, orig.h, cMaxRow, &nc, &nr)) {
                // No room left on this page: it moves to the next page instead of the
                // resize being dropped (which put the widget back to 1x1).
                [overflow addObject:oid];
                continue;
            }
            CC26Rect np = {nc, nr, orig.w, orig.h};
            placed[oid] = [NSValue value:&np withObjCType:@encode(CC26Rect)];
        }

        {
            resolved = YES;
            gEditSizes[mid] = @[@(w), @(h)];
            for (NSString *oid in placed) {
                CC26Rect r = {};
                [placed[oid] getValue:&r];
                CC26SetOrigin(oid, @[@(r.c), @(page * kCC26Rows + r.r)]);
            }
            if (overflow.count) {
                NSMutableArray<NSString *> *ids = [NSMutableArray array];
                for (UIViewController *m in ModuleControllers(ov)) {
                    NSString *oid = CC26Mid(m);
                    if (oid.length) [ids addObject:oid];
                }
                for (NSString *oid in overflow) {
                    CC26Rect orig = {};
                    [snapshot[oid] getValue:&orig];
                    CC26PlaceNewModule(oid, (CCUILayoutSize){orig.w, orig.h}, ids);
                }
            }
        }
    }

    if (!resolved) {
        NSMutableDictionary<NSString *, NSValue *> *placed =
            [NSMutableDictionary dictionaryWithDictionary:snapshot];
        NSUInteger cMaxRow = (capR + 1 >= h) ? (capR - h + 1) : 0;
        NSUInteger newCol = 0, newRow = 0;
        if (!CC26FindFreeCellFor(placed, col, row, w, h, cMaxRow, &newCol, &newRow)) return;
        gEditSizes[mid]   = @[@(w), @(h)];
        CC26SetOrigin(mid, @[@(newCol), @(page * kCC26Rows + newRow)]);
    }

    CC26InvalidateOtherOrientationOriginForModule(mid);
    CC26SaveStore();

    NSMutableSet<NSString *> *resized = objc_getAssociatedObject(UIApplication.sharedApplication, kCC26ResizedSetKey);
    if (!resized) {
        resized = [NSMutableSet set];
        objc_setAssociatedObject(UIApplication.sharedApplication, kCC26ResizedSetKey, resized, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    [resized addObject:mid];

    for (UIViewController *m in ModuleControllers(ov)) {
        if (![CC26Mid(m) isEqualToString:mid]) continue;
        id contentModule = nil;
        @try { contentModule = [m valueForKey:@"module"]; } @catch (__unused NSException *e) {}
        id ctx = nil;
        @try { ctx = [contentModule valueForKey:@"contentModuleContext"]; } @catch (__unused NSException *e) {}
        if ([ctx respondsToSelector:NSSelectorFromString(@"requestLayoutSizeUpdate")]) {
            ((void (*)(id, SEL))objc_msgSend)(ctx, NSSelectorFromString(@"requestLayoutSizeUpdate"));
        }
        break;
    }
}

- (void)removeTap:(UIButton *)b {
    if (!gEditModeActive) return;
    NSString *mid = objc_getAssociatedObject(b, kCC26MidKey);
    if (!mid.length) return;
    if (gHapticsEnabled) Haptic();

    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;

    UIViewController *victim = nil;
    for (UIViewController *m in ModuleControllers(ov)) {
        if ([CC26Mid(m) isEqualToString:mid]) { victim = m; break; }
    }
    UIView   *victimBorder = victim ? objc_getAssociatedObject(victim.view, kCC26BorderKey) : nil;
    UIButton *victimRM     = victim ? objc_getAssociatedObject(victim.view, kCC26RemoveKey) : nil;
    UIButton *victimRZ     = victim ? objc_getAssociatedObject(victim.view, kCC26ResizeKey) : nil;

    if (victim) {
        [UIView animateWithDuration:0.24
                              delay:0.0
                            options:UIViewAnimationOptionCurveEaseIn |
                                    UIViewAnimationOptionBeginFromCurrentState |
                                    UIViewAnimationOptionAllowUserInteraction
                         animations:^{
            CGAffineTransform s = CGAffineTransformMakeScale(0.35, 0.35);
            victim.view.transform   = s;  victim.view.alpha   = 0.0;
            victimBorder.transform  = s;  victimBorder.alpha  = 0.0;
            victimRM.transform      = s;  victimRM.alpha      = 0.0;
            victimRZ.transform      = s;  victimRZ.alpha      = 0.0;
        } completion:nil];
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.24 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        id prov = CC26SettingsProvider();
        SEL get = NSSelectorFromString(@"orderedUserEnabledModuleIdentifiers");
        SEL set = NSSelectorFromString(@"setAndSaveOrderedUserEnabledModuleIdentifiers:");

        NSUInteger visibleCount = 0;
        for (UIViewController *m in ModuleControllers(ov)) {
            if (CC26Mid(m).length) visibleCount++;
        }
        NSArray *enabledNow = [prov respondsToSelector:get] ? ((id (*)(id, SEL))objc_msgSend)(prov, get) : nil;
        NSUInteger enabledCount = [enabledNow isKindOfClass:NSArray.class] ? enabledNow.count : 0;
        BOOL slide = CC26IsNonNotchedDevice() && (visibleCount == 12 || enabledCount == 12);
        NSDictionary<NSString *, NSValue *> *oldFrames = slide ? CC26CaptureModuleFrames(ov, mid) : nil;

        if ([prov respondsToSelector:get] && [prov respondsToSelector:set]) {
            NSArray *ids = ((id (*)(id, SEL))objc_msgSend)(prov, get);
            NSMutableArray *mut = [ids mutableCopy];
            [mut removeObject:mid];
            ((void (*)(id, SEL, id))objc_msgSend)(prov, set, mut);
        }

        CC26EnsureStore();
        CC26SetOrigin(mid, nil);
        [gEditSizes removeObjectForKey:mid];
        CC26InvalidateOtherOrientationOriginForModule(mid);
        CC26SaveStore();

        if (victim) CC26StripChrome(victim);
        [victimBorder removeFromSuperview];
        [victimRM removeFromSuperview];
        [victimRZ removeFromSuperview];

        [self compactGridAfterRemoval:ov];
        [self relayout:ov];

        NSTimeInterval settleDelay = 0.45;
        if (slide) {
            CC26SlideModules(ov, oldFrames);
            CC26AnimateChromeRefreshExcluding(ov, mid);
            CC26SettleEditLayoutEx(ov, NO);
            CFTimeInterval startedAt = CACurrentMediaTime();
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!gEditModeActive) return;
                if (CACurrentMediaTime() - startedAt > 0.1) return;
                if (CC26SlideModules(ov, oldFrames)) CC26AnimateChromeRefreshExcluding(ov, mid);
            });
            settleDelay = MAX(settleDelay, CC26ResizeSpec().duration + 0.08);
        } else {
            CC26SettleEditLayout(ov);
        }

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(settleDelay * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (!gEditModeActive) return;
            for (UIViewController *m in ModuleControllers(ov)) {
                CC26ApplyRadiusToModule(m);
                CC26ApplyChrome(m, ov);
                CC26RefreshPresentation(m, ov);
            }
            UIView *shield = [ov.view viewWithTag:kCC26ShieldTag];
            if (shield) [ov.view bringSubviewToFront:shield];
            for (UIViewController *m in ModuleControllers(ov)) {
                UIButton *rm = objc_getAssociatedObject(m.view, kCC26RemoveKey);
                UIButton *rz = objc_getAssociatedObject(m.view, kCC26ResizeKey);
                if (rm) [ov.view bringSubviewToFront:rm];
                if (rz) [ov.view bringSubviewToFront:rz];
                UIView *pr = objc_getAssociatedObject(m.view, kCC26PresKey);
                if (pr) [ov.view bringSubviewToFront:pr];
            }
            UIView *rp = [ov.view viewWithTag:kCC26ResetTag];
            if (rp) [ov.view bringSubviewToFront:rp];
        });
    });
}

- (void)resetTap:(UIButton *)b {
    if (!gEditModeActive) return;
    CC26RefreshGridConstants();
    gCC26EditEpoch++;
    NSUInteger epochAtReset = gCC26EditEpoch;
    gEditModeEnteredAt = CACurrentMediaTime();
    gCC26PendingResizeID = nil;
    gCC26PendingResizeSize = (CCUILayoutSize){0, 0};
    gCC26PendingResizeLastTouch = 0;
    if (gHapticsEnabled) {
        UIImpactFeedbackGenerator *gen = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
        [gen prepare];
        [gen impactOccurred];
    }

    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;

    for (UIViewController *m in ModuleControllers(ov)) {
        CC26EnsureBaseSize(m, ov);
    }

    NSArray<NSString *> *ordered = CC26ProviderOrderedIdentifiers();

    CC26EnsureStore();
    NSString *prefix = CC26IsLandscape() ? @"L|" : @"P|";
    for (NSString *key in [gEditOrigins.allKeys copy]) {
        if ([key hasPrefix:prefix]) [gEditOrigins removeObjectForKey:key];
    }
    [gEditSizes removeAllObjects];

    NSMutableDictionary<NSString *, NSValue *> *placed = [NSMutableDictionary dictionary];

    NSMutableArray<NSString *> *ids = [NSMutableArray array];
    if (ordered.count) [ids addObjectsFromArray:ordered];
    for (UIViewController *m in ModuleControllers(ov)) {
        NSString *mid = CC26Mid(m);
        if (!mid.length) continue;
        if (![ids containsObject:mid]) [ids addObject:mid];
    }

    NSUInteger perPage = kCC26Rows;
    for (NSString *mid in ids) {
        NSArray<NSNumber *> *base = gEditBaseSizes[mid];
        if (base.count < 2) base = CC26KnownBaseSize(mid);
        if (base.count < 2) continue;
        NSUInteger w = base[0].unsignedIntegerValue;
        NSUInteger h = base[1].unsignedIntegerValue;
        if (w == 0 || h == 0 || w > kCC26Cols || h > kCC26Rows) continue;

        BOOL found = NO;
        for (NSUInteger page = 0; page < 4 && !found; page++) {
            NSUInteger maxR = kCC26Rows - h;
            NSUInteger maxC = kCC26Cols - w;
            for (NSUInteger r = 0; r <= maxR && !found; r++) {
                for (NSUInteger c = 0; c <= maxC; c++) {
                    CC26Rect t = {c, r, w, h};
                    BOOL ok = YES;
                    for (NSValue *v in placed.allValues) {
                        CC26Rect o = {};
                        [v getValue:&o];
                        if (CC26RectsOverlap(t, o)) { ok = NO; break; }
                    }
                    if (!ok) continue;
                    CC26Rect copy = t;
                    placed[mid] = [NSValue value:&copy withObjCType:@encode(CC26Rect)];
                    CC26SetOrigin(mid, @[@(c), @(page * perPage + r)]);
                    found = YES;
                    break;
                }
            }
        }
    }
    CC26SaveStore();

    for (UIViewController *m in ModuleControllers(ov)) CC26StripChrome(m);
    UIView *hint = [ov.view viewWithTag:kCC26HintTag];
    hint.hidden = YES;

    [UIView animateWithDuration:0.10 animations:^{
        b.transform = CGAffineTransformMakeScale(0.94, 0.94);
    } completion:^(__unused BOOL f) {
        [UIView animateWithDuration:0.18 delay:0.0
                            options:UIViewAnimationOptionCurveEaseOut | UIViewAnimationOptionBeginFromCurrentState
                         animations:^{ b.transform = CGAffineTransformIdentity; }
                         completion:nil];
    }];

    [self relayout:ov];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (epochAtReset != gCC26EditEpoch) return;
        if (!gEditModeActive) return;
        for (UIViewController *m in ModuleControllers(ov)) {
            CC26ApplyRadiusToModule(m);
            CC26ApplyChrome(m, ov);
            CC26RefreshPresentation(m, ov);
        }
        UIView *shield = [ov.view viewWithTag:kCC26ShieldTag];
        if (shield) [ov.view bringSubviewToFront:shield];
        for (UIViewController *m in ModuleControllers(ov)) {
            UIButton *rm = objc_getAssociatedObject(m.view, kCC26RemoveKey);
            UIButton *rz = objc_getAssociatedObject(m.view, kCC26ResizeKey);
            if (rm) [ov.view bringSubviewToFront:rm];
            if (rz) [ov.view bringSubviewToFront:rz];
            UIView *pr = objc_getAssociatedObject(m.view, kCC26PresKey);
            if (pr) [ov.view bringSubviewToFront:pr];
        }
        [ov.view bringSubviewToFront:b];
    });
}

@end

static void CC26RefreshPresentationImpl(UIViewController *m, UIViewController *ov) {
    if (!m || !m.view) return;
    NSString *mid = CC26Mid(m);
    if (!mid.length) return;

    CC26EnsureStore();
    CC26EnsureBaseSize(m, ov);

    if (CC26ModuleIsExpanded(m)) return;

    NSUInteger curW = 1, curH = 1;
    CC26PresentationSize(mid, &curW, &curH);

    UIView *buttonView = CC26ModuleButtonView(m.view);
    if (!buttonView) return;

    BOOL animate = CC26AnimationsAllowed();
    NSUInteger radiusW = 1, radiusH = 1;
    CC26EffectiveSize(mid, &radiusW, &radiusH);
    CGFloat radius = CC26RadiusForSize(radiusW, radiusH);
    CC26SetRadius(buttonView.layer, radius, animate && objc_getAssociatedObject(m.view, kCC26LastRadiusKey) != nil);

    BOOL isResizedFromOneByOne = CC26WasResizedFromOneByOne(mid);

    UIView *pres = objc_getAssociatedObject(m.view, kCC26PresKey);
    if (!isResizedFromOneByOne) {
        if (pres) {
            objc_setAssociatedObject(m.view, kCC26PresKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            if (animate && pres.superview) {
                [UIView animateWithDuration:0.15
                                      delay:0.0
                                    options:UIViewAnimationOptionBeginFromCurrentState |
                                            UIViewAnimationOptionAllowUserInteraction
                                 animations:^{ pres.alpha = 0.0; }
                                 completion:^(__unused BOOL finished) { [pres removeFromSuperview]; }];
            } else {
                [pres removeFromSuperview];
            }
        }
        objc_setAssociatedObject(m.view, kCC26LastPresKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        CC26RestoreModuleIcon(m);
        return;
    }

    CC26LayoutModuleIcon(m);

    NSString *newText = CC26PrettyNameForModule(m);
    CGSize bvSize = buttonView.bounds.size;
    NSUInteger sig = 1469598103934665603ULL;
    sig = (sig ^ (NSUInteger)llround(bvSize.width))  * 1099511628211ULL;
    sig = (sig ^ (NSUInteger)llround(bvSize.height)) * 1099511628211ULL;
    sig = (sig ^ curW) * 1099511628211ULL;
    sig = (sig ^ curH) * 1099511628211ULL;
    sig = (sig ^ (NSUInteger)newText.hash) * 1099511628211ULL;

    NSNumber *lastSig = objc_getAssociatedObject(m.view, kCC26LastPresKey);
    if (lastSig && lastSig.unsignedIntegerValue == sig &&
        pres && pres.superview == buttonView) {
        return;
    }
    objc_setAssociatedObject(m.view, kCC26LastPresKey, @(sig), OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    UILabel *titleLabel = nil;
    BOOL created = (!pres || pres.superview != buttonView);
    if (created) {
        [pres removeFromSuperview];
        pres = [[UIView alloc] initWithFrame:buttonView.bounds];
        pres.userInteractionEnabled = NO;
        pres.backgroundColor = UIColor.clearColor;
        pres.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        pres.clipsToBounds = YES;
        pres.alpha = animate ? 0.0 : 1.0;

        titleLabel = [[UILabel alloc] init];
        titleLabel.tag = 9001;
        titleLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
        titleLabel.textColor = UIColor.whiteColor;
        titleLabel.numberOfLines = 2;
        titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        titleLabel.textAlignment = NSTextAlignmentLeft;
        [pres addSubview:titleLabel];

        objc_setAssociatedObject(m.view, kCC26PresKey, pres, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [buttonView addSubview:pres];
    } else {
        titleLabel = (UILabel *)[pres viewWithTag:9001];
    }

    if (created) {
        [UIView performWithoutAnimation:^{ pres.frame = buttonView.bounds; }];
    } else {
        pres.frame = buttonView.bounds;
    }
    pres.hidden = NO;

    titleLabel.text = newText;

    CGFloat W = CGRectGetWidth(pres.bounds);
    CGFloat H = CGRectGetHeight(pres.bounds);
    CGFloat lineHeight = 14.3333;
    CGFloat textW;
    CGFloat textX;
    CGFloat iconCenterY = H * 0.5;
    if (curW > 1 && curH == 1) {
        textX = kCC26Cell - 10.0;
        iconCenterY = H * 0.5;
        textW = MAX(0.0, W - textX - 12.0);
    } else {
        textX = curW > 1 ? 21.0 : 10.0;
        textW = MAX(0.0, W - textX - (curW > 1 ? 24.0 : 10.0));
    }
    CGSize measured = [titleLabel.text boundingRectWithSize:CGSizeMake(textW, lineHeight * 2.0)
                                                    options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                                 attributes:@{NSFontAttributeName: titleLabel.font}
                                                    context:nil].size;
    CGFloat titleH = measured.height > lineHeight + 1.0 ? lineHeight * 2.0 : lineHeight;

    CGFloat top;
    if (curW > 1 && curH == 1) {
        top = iconCenterY - titleH * 0.5;
        if (top < 4.0) top = 4.0;
        if (top > H - titleH - 4.0) top = H - titleH - 4.0;
    } else {
        top = MAX(kCC26Cell + 7.0, H - 17.3333 - titleH);
    }
    CGRect labelFrame = CGRectMake(textX, top, textW, titleH);
    if (created) {
        [UIView performWithoutAnimation:^{ titleLabel.frame = labelFrame; }];
    } else {
        titleLabel.frame = labelFrame;
    }
    [buttonView bringSubviewToFront:pres];
    [pres bringSubviewToFront:titleLabel];

    if (created && animate) {
        [UIView animateWithDuration:0.22
                              delay:0.08
                            options:UIViewAnimationOptionBeginFromCurrentState |
                                    UIViewAnimationOptionAllowUserInteraction
                         animations:^{ pres.alpha = 1.0; }
                         completion:nil];
    }
}

static void CC26RefreshPresentation(UIViewController *m, UIViewController *ov) {
    if (!m || !m.view) return;
    if (CC26IsLandscape()) return;
    objc_setAssociatedObject(m.view, kCC26LandscapeCleanKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    CC26RunMaybeWithoutAnimation(^{ CC26RefreshPresentationImpl(m, ov); });
}

static void CC26ApplyChrome(UIViewController *m, UIViewController *ov) {
    if (!gEditModeActive) return;
    if (CC26IsLandscape()) return;
    UIView *view = m.view;
    if (!view) return;
    NSString *mid = CC26Mid(m);
    if (!mid.length) return;
    CGRect vis = CC26VisibleFrame(m, ov);
    if (CGRectIsEmpty(vis)) return;

    CC26ApplyRadiusToModule(m);

    CGFloat radius = view.layer.cornerRadius;
    if (radius < 1.0) radius = MIN(CGRectGetWidth(vis), CGRectGetHeight(vis)) * 0.5;

    UIView *border = objc_getAssociatedObject(view, kCC26BorderKey);
    BOOL borderIsNew = (border == nil);
    if (borderIsNew) {
        border = CC26MakeBorder();
        objc_setAssociatedObject(view, kCC26BorderKey, border, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    [ov.view addSubview:border];

    border.frame = CGRectInset(vis, -kCC26BorderInset, -kCC26BorderInset);
    CGFloat anchorRadius = radius;
    if (anchorRadius < 1.0) {
        anchorRadius = MIN(CGRectGetWidth(vis), CGRectGetHeight(vis)) * 0.5;
    }
    border.layer.cornerRadius = anchorRadius + kCC26BorderInset;
    border.hidden = NO;
    if (borderIsNew) CC26AnimateChromeEntry(border);

    UIButton *rm = objc_getAssociatedObject(view, kCC26RemoveKey);
    BOOL rmIsNew = (rm == nil);
    if (rmIsNew) {
        rm = CC26MakeRemoveButton(mid);
        [rm addTarget:[CC26EditProxy shared] action:@selector(removeTap:) forControlEvents:UIControlEventTouchUpInside];
        objc_setAssociatedObject(view, kCC26RemoveKey, rm, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [ov.view addSubview:rm];
    }
    CGFloat rmSize = 30.0;
    rm.frame = CGRectMake(vis.origin.x - 8.0, vis.origin.y - 8.0, rmSize, rmSize);
    rm.hidden = NO;
    if (rmIsNew) CC26AnimateChromeEntryDelayed(rm, 0.04);

    BOOL supportsResize = CC26ModuleSupportsResizing(mid);
    objc_setAssociatedObject(CC26ModuleButtonView(view), kCC26IconPinKey,
                             supportsResize ? @YES : nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    UIButton *rz = objc_getAssociatedObject(view, kCC26ResizeKey);
    if (supportsResize) {
        BOOL rzIsNew = (rz == nil);
        if (rzIsNew) {
            rz = CC26MakeResizeButton(mid);
            objc_setAssociatedObject(view, kCC26ResizeKey, rz, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            UIPanGestureRecognizer *rp = [[UIPanGestureRecognizer alloc] initWithTarget:[CC26EditProxy shared] action:@selector(resizePan:)];
            rp.maximumNumberOfTouches = 1;
            rp.cancelsTouchesInView = YES;
            [rz addGestureRecognizer:rp];
            [ov.view addSubview:rz];
        }
        CGFloat rzSize = 42.0;
        CGFloat rzOverhang = 2.0;
        rz.frame = CGRectMake(CGRectGetMaxX(vis) - rzSize + rzOverhang,
                              CGRectGetMaxY(vis) - rzSize + rzOverhang,
                              rzSize, rzSize);
        rz.hidden = NO;
        if (rzIsNew) CC26AnimateChromeEntryDelayed(rz, 0.04);
    } else if (rz) {
        [rz removeFromSuperview];
        objc_setAssociatedObject(view, kCC26ResizeKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }

    CC26RefreshPresentation(m, ov);
}

static void CC26StripChrome(UIViewController *m) {
    UIView *view = m.view;
    if (!view) return;
    objc_setAssociatedObject(CC26ModuleButtonView(view), kCC26IconPinKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [objc_getAssociatedObject(view, kCC26BorderKey) removeFromSuperview];
    [objc_getAssociatedObject(view, kCC26RemoveKey) removeFromSuperview];
    [objc_getAssociatedObject(view, kCC26ResizeKey) removeFromSuperview];
    objc_setAssociatedObject(view, kCC26BorderKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(view, kCC26RemoveKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(view, kCC26ResizeKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

static void CC26InstallGestures(UIViewController *ov) {
    if (!ov.view) return;
    if (objc_getAssociatedObject(ov, kCC26GestKey)) return;
    objc_setAssociatedObject(ov, kCC26GestKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    UILongPressGestureRecognizer *hold = [[UILongPressGestureRecognizer alloc]
        initWithTarget:[CC26EditProxy shared] action:@selector(bgHold:)];
    hold.minimumPressDuration = 0.55;
    hold.cancelsTouchesInView = NO;
    hold.delegate = [CC26EditProxy shared];
    objc_setAssociatedObject(hold, kCC26OwnGestureKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [ov.view addGestureRecognizer:hold];
}


static CCUILayoutRect (*CC26Orig_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_)(CCUIModuleCollectionViewController *, SEL, id, UIView *);
// A module with no saved origin yet (newly added in Settings) goes into the first free cell,
// page by page, so it never lands on top of another module or past the bottom of a page.
static void CC26PlaceNewModule(NSString *mid, CCUILayoutSize size, NSArray<NSString *> *ids) {
    if (!mid.length) return;
    NSUInteger w = size.width ? size.width : 1, h = size.height ? size.height : 1;
    NSArray<NSNumber *> *own = gEditSizes[mid];
    if (own.count >= 2) { w = own[0].unsignedIntegerValue; h = own[1].unsignedIntegerValue; }
    w = MIN(MAX(w, (NSUInteger)1), kCC26Cols);
    h = MIN(MAX(h, (NSUInteger)1), kCC26Rows);

    NSMutableDictionary<NSNumber *, NSMutableDictionary<NSString *, NSValue *> *> *byPage = [NSMutableDictionary dictionary];
    NSUInteger maxPage = 0;
    for (NSString *oid in ids) {
        if ([oid isEqualToString:mid]) continue;
        NSArray<NSNumber *> *o = CC26GetOrigin(oid);
        if (!o) o = gEditOrigins[oid];
        if (o.count < 2) continue;
        NSArray<NSNumber *> *s = gEditSizes[oid];
        if (s.count < 2) s = gEditBaseSizes[oid];
        if (s.count < 2) s = CC26KnownBaseSize(oid);
        NSUInteger ow = s.count >= 2 ? s[0].unsignedIntegerValue : 1;
        NSUInteger oh = s.count >= 2 ? s[1].unsignedIntegerValue : 1;
        NSUInteger abs = o[1].unsignedIntegerValue;
        NSUInteger page = abs / kCC26Rows;
        CC26Rect rect = {o[0].unsignedIntegerValue, abs % kCC26Rows, ow, oh};
        NSMutableDictionary *occ = byPage[@(page)];
        if (!occ) { occ = [NSMutableDictionary dictionary]; byPage[@(page)] = occ; }
        occ[oid] = [NSValue valueWithBytes:&rect objCType:@encode(CC26Rect)];
        if (page > maxPage) maxPage = page;
    }
    for (NSUInteger page = 0; page <= maxPage + 1; page++) {
        NSUInteger c = 0, r = 0;
        if (CC26FindFreeCellFor(byPage[@(page)] ?: @{}, 0, 0, w, h, kCC26Rows - 1, &c, &r)) {
            CC26SetOrigin(mid, @[@(c), @(page * kCC26Rows + r)]);
            CC26SaveStore();
            return;
        }
    }
}

// Remembers which page each module is on; when the number of module pages changes the
// connectivity and media pages move after them and the page indicator is rebuilt.
static void CC26NoteModulePage(NSString *mid, NSUInteger page, NSArray<NSString *> *ids) {
    static NSMutableDictionary<NSString *, NSNumber *> *sPages = nil;
    if (!sPages) sPages = [NSMutableDictionary dictionary];
    sPages[mid] = @(page);
    if (ids && sPages.count > ids.count) {
        NSMutableSet *stale = [NSMutableSet setWithArray:sPages.allKeys];
        [stale minusSet:[NSSet setWithArray:ids]];
        [sPages removeObjectsForKeys:stale.allObjects];
    }
    NSUInteger maxPage = 0;
    for (NSNumber *p in sPages.allValues) maxPage = MAX(maxPage, p.unsignedIntegerValue);
    CC26SetModulePages(maxPage + 1);
}

static void CC26SetModulePages(NSUInteger count) {
    NSUInteger pages = MIN(MAX(count, (NSUInteger)1), (NSUInteger)4);
    if (pages == gCC26ModulePages) return;
    gCC26ModulePages = pages;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
        if (ov) [CC26.shared installPageIndicatorOnOverlay:ov];
    });
}

// Rows each module page shows: the grid's rows, or fewer when the screen cuts it short.
static NSUInteger CC26RowsPerPage(UIViewController *ov) {
    NSUInteger rows = kCC26Rows ? kCC26Rows : 1;
    if (ov) rows = MIN(rows, CC26VisibleRowCap(ov) + 1);
    return MAX(rows, (NSUInteger)1);
}

// Where each page starts, in stock rows: every `perPage` rows, or earlier when a module would
// be cut in two by the page edge (that module then opens the next page).
static NSArray<NSNumber *> *CC26PageBreaks(NSArray<NSValue *> *rects, NSUInteger perPage) {
    NSMutableArray<NSNumber *> *breaks = [NSMutableArray arrayWithObject:@0];
    if (!perPage) return breaks;
    NSUInteger bottom = 0;
    for (NSValue *v in rects) { CC26Rect r = {}; [v getValue:&r]; bottom = MAX(bottom, r.r + r.h); }
    NSUInteger top = 0;
    while (top + perPage < bottom && breaks.count < 4) {
        NSUInteger cut = top + perPage;
        for (NSValue *v in rects) {
            CC26Rect r = {};
            [v getValue:&r];
            if (r.r > top && r.r < cut && r.r + r.h > cut) cut = r.r;
        }
        [breaks addObject:@(cut)];
        top = cut;
    }
    return breaks;
}

static NSUInteger CC26PageForStockRow(NSArray<NSNumber *> *breaks, NSUInteger y, NSUInteger *row) {
    NSUInteger page = 0;
    for (NSUInteger i = 1; i < breaks.count; i++) if (y >= breaks[i].unsignedIntegerValue) page = i;
    if (row) *row = y - breaks[page].unsignedIntegerValue;
    return page;
}

// mid of a module container view; cached so a layout pass does not walk every container
// for every subview.
static NSString *CC26MidForSubview(id col, UIView *subview) {
    static NSMapTable<UIView *, NSString *> *cache = nil;
    if (!cache) cache = [NSMapTable weakToStrongObjectsMapTable];
    NSString *mid = [cache objectForKey:subview];
    if (mid) return mid.length ? mid : nil;
    NSDictionary *containers = nil;
    @try { containers = [col valueForKey:@"moduleContainerViewByIdentifier"]; }
    @catch (__unused NSException *e) {}
    [cache removeAllObjects];
    [containers enumerateKeysAndObjectsUsingBlock:^(NSString *key, id value, __unused BOOL *stop) {
        UIView *cand = [value isKindOfClass:UIView.class] ? value
                    : ([value respondsToSelector:@selector(view)] ? [value view] : nil);
        if (cand && key.length) [cache setObject:key forKey:cand];
    }];
    mid = [cache objectForKey:subview];
    if (!mid) [cache setObject:@"" forKey:subview];
    return mid;
}

// Stock layout with paging: page breaks for this layout pass (computed once per pass), and the
// stock rect of each module recorded for Copy Stock Layout.
static NSArray<NSNumber *> *CC26StockBreaksForPass(CCUIModuleCollectionViewController *col, id layoutView) {
    static NSArray<NSNumber *> *sBreaks = nil;
    static BOOL sValid = NO;
    if (sValid && sBreaks) return sBreaks;
    NSMutableArray<NSValue *> *rects = [NSMutableArray array];
    BOOL changed = NO;
    if ([layoutView isKindOfClass:UIView.class]) {
        for (UIView *v in [(UIView *)layoutView subviews]) {
            CCUILayoutRect lr = CC26Orig_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_(
                col, @selector(layoutView:layoutRectForSubview:), layoutView, v);
            if (!lr.size.width || !lr.size.height) continue;
            CC26Rect cr = {lr.origin.x, lr.origin.y, lr.size.width, lr.size.height};
            [rects addObject:[NSValue value:&cr withObjCType:@encode(CC26Rect)]];
            NSString *mid = CC26MidForSubview(col, v);
            NSArray<NSNumber *> *native = CC26NativeSize(mid);
            if (CC26_EDIT_MODE_ENABLED && mid.length && native.count >= 2 && native[0].unsignedIntegerValue == lr.size.width &&
                native[1].unsignedIntegerValue == lr.size.height) {
                NSArray *rec = @[@(lr.origin.x), @(lr.origin.y), @(lr.size.width), @(lr.size.height)];
                CC26EnsureStore();
                if (![gCC26StockRects[mid] isEqualToArray:rec]) { gCC26StockRects[mid] = rec; changed = YES; }
            }
        }
    }
    if (changed) CC26SaveStore();
    UIViewController *ov = CC26OverlayForView(((UIViewController *)col).view);
    sBreaks = gPagingEnabled ? CC26PageBreaks(rects, CC26RowsPerPage(ov)) : @[@0];
    sValid = YES;
    dispatch_async(dispatch_get_main_queue(), ^{ sValid = NO; });
    CC26SetModulePages(sBreaks.count);
    return sBreaks;
}

static CCUILayoutRect CC26Hook_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_(CCUIModuleCollectionViewController *self, SEL _cmd, id layoutView, UIView * subview);

// Page dividers: the "Page 2", "Page 3" and "Page 4" modules (modulebundles/PageBreak.m), which
// the user drags in Settings ▸ Control Center like any other control. Every module after a
// divider in that list starts on a new page. The divider itself is never shown.
static BOOL CC26IsPageDivider(NSString *mid) {
    return [mid hasPrefix:@"com.controlcenter26.module.page"];
}

// The user's Control Center order with the dividers in it. The settings provider may leave out
// modules it does not know (the dividers draw nothing), so the saved list is read as well.
static NSArray<NSString *> *CC26PageOrder(NSString **source) {
    NSArray<NSString *> *prov = CC26ProviderOrderedIdentifiers();
    for (NSString *m in prov) if (CC26IsPageDivider(m)) { if (source) *source = @"provider"; return prov; }
    static NSArray<NSString *> *sCached = nil;
    static NSDate *sStamp = nil;
    static NSString *sPath = nil;
    for (NSString *p in @[@"/var/mobile/Library/ControlCenter/ModuleConfiguration_CCSupport.plist",
                          @"/var/mobile/Library/ControlCenter/ModuleConfiguration.plist"]) {
        NSDate *stamp = [[NSFileManager.defaultManager attributesOfItemAtPath:p error:nil] fileModificationDate];
        if (!stamp) continue;
        if (!(sCached && [sPath isEqualToString:p] && [sStamp isEqualToDate:stamp])) {
            NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:p];
            id list = d[@"module-identifiers"];
            sCached = [list isKindOfClass:NSArray.class] ? list : nil;
            sStamp = stamp;
            sPath = p;
        }
        if (sCached.count) { if (source) *source = p.lastPathComponent; return sCached; }
    }
    if (source) *source = @"provider-nodivider";
    return prov;
}

static BOOL CC26FirstFreeCell(NSArray<NSValue *> *occupied, NSUInteger w, NSUInteger h,
                              NSUInteger cols, NSUInteger *outC, NSUInteger *outR) {
    if (!w || !h || w > cols) return NO;
    for (NSUInteger r = 0; r < 512; r++) {
        for (NSUInteger c = 0; c + w <= cols; c++) {
            CC26Rect t = {c, r, w, h};
            BOOL ok = YES;
            for (NSValue *v in occupied) {
                CC26Rect o = {};
                [v getValue:&o];
                if (CC26RectsOverlap(t, o)) { ok = NO; break; }
            }
            if (ok) { *outC = c; *outR = r; return YES; }
        }
    }
    return NO;
}

// One layout pass's plan when the list has a page divider: subview → @[col, page, row], with
// dividers mapped to @[] (hidden). nil when there is no divider (the stock layout is cut into
// pages as before). The modules before the first divider keep their stock places; each later
// group is packed in list order, first free cell, as stock packs the first. A group taller than
// a page goes on to the next page, cut so no module is split.
static NSDictionary<NSValue *, NSArray<NSNumber *> *> *CC26DividerPlanForPass(CCUIModuleCollectionViewController *col, id layoutView) {
    static NSDictionary<NSValue *, NSArray<NSNumber *> *> *sPlan = nil;
    static BOOL sValid = NO;
    if (sValid) return sPlan;
    sPlan = nil;
    sValid = YES;
    dispatch_async(dispatch_get_main_queue(), ^{ sValid = NO; });
    if (!gPagingEnabled || ![layoutView isKindOfClass:UIView.class]) return nil;

    NSUInteger cols = kCC26Cols ? kCC26Cols : 4;
    NSMutableDictionary<NSString *, NSValue *> *viewByID = [NSMutableDictionary dictionary];
    NSMutableDictionary<NSString *, NSValue *> *rectByID = [NSMutableDictionary dictionary];
    BOOL hasDivider = NO;
    for (UIView *v in [(UIView *)layoutView subviews]) {
        NSString *mid = CC26MidForSubview(col, v);
        if (!mid.length) continue;
        CCUILayoutRect lr = CC26Orig_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_(
            col, @selector(layoutView:layoutRectForSubview:), layoutView, v);
        if (!lr.size.width || !lr.size.height) continue;
        CC26Rect cr = {lr.origin.x, lr.origin.y, MIN(lr.size.width, cols), lr.size.height};
        viewByID[mid] = [NSValue valueWithNonretainedObject:v];
        rectByID[mid] = [NSValue value:&cr withObjCType:@encode(CC26Rect)];
        if (CC26IsPageDivider(mid)) hasDivider = YES;
    }
    NSString *orderSource = nil;
    NSArray<NSString *> *order = CC26PageOrder(&orderSource) ?: @[];
    // A divider counts when a module shown in Control Center comes after it, whether or not
    // the divider itself got a view.
    {
        BOOL seenDivider = NO;
        hasDivider = NO;
        for (NSString *m in order) {
            if (CC26IsPageDivider(m)) { seenDivider = YES; continue; }
            if (seenDivider && rectByID[m]) { hasDivider = YES; break; }
        }
    }
    if (!hasDivider) return nil;

    // Groups in Control Center's order: modules not in the user's list (the fixed ones) first.
    NSMutableArray<NSMutableArray<NSString *> *> *groups = [NSMutableArray arrayWithObject:[NSMutableArray array]];
    for (NSString *mid in rectByID) {
        if (![order containsObject:mid] && !CC26IsPageDivider(mid)) [groups[0] addObject:mid];
    }
    for (NSString *mid in order) {
        if (CC26IsPageDivider(mid)) { if (groups.lastObject.count) [groups addObject:[NSMutableArray array]]; continue; }
        if (!rectByID[mid]) continue;
        [groups.lastObject addObject:mid];
    }

    UIViewController *ov = CC26OverlayForView(((UIViewController *)col).view);
    NSUInteger perPage = CC26RowsPerPage(ov);
    NSMutableDictionary<NSValue *, NSArray<NSNumber *> *> *plan = [NSMutableDictionary dictionary];
    NSUInteger firstPage = 0;
    for (NSUInteger g = 0; g < groups.count; g++) {
        NSArray<NSString *> *ids = groups[g];
        if (!ids.count) continue;
        NSMutableDictionary<NSString *, NSValue *> *placed = [NSMutableDictionary dictionary];
        NSMutableArray<NSValue *> *occupied = [NSMutableArray array];
        NSUInteger top = NSUIntegerMax;
        for (NSString *mid in ids) {
            CC26Rect t = {};
            [rectByID[mid] getValue:&t];
            if (g > 0) {
                NSUInteger c = 0, r = 0;
                if (!CC26FirstFreeCell(occupied, t.w, t.h, cols, &c, &r)) continue;
                t.c = c; t.r = r;
            }
            NSValue *tv = [NSValue value:&t withObjCType:@encode(CC26Rect)];
            [occupied addObject:tv];
            placed[mid] = tv;
            top = MIN(top, t.r);
        }
        if (!placed.count) continue;
        // The group starts at the top of its page.
        NSMutableArray<NSValue *> *shifted = [NSMutableArray array];
        for (NSString *mid in placed.allKeys) {
            CC26Rect t = {};
            [placed[mid] getValue:&t];
            t.r -= top;
            placed[mid] = [NSValue value:&t withObjCType:@encode(CC26Rect)];
            [shifted addObject:placed[mid]];
        }
        NSArray<NSNumber *> *breaks = CC26PageBreaks(shifted, perPage);
        NSUInteger lastPage = 0;
        for (NSString *mid in placed) {
            CC26Rect t = {};
            [placed[mid] getValue:&t];
            NSUInteger row = 0;
            NSUInteger page = CC26PageForStockRow(breaks, t.r, &row);
            lastPage = MAX(lastPage, page);
            plan[viewByID[mid]] = @[@(t.c), @(firstPage + page), @(row)];
        }
        firstPage += lastPage + 1;
    }
    for (NSString *mid in rectByID) {
        if (CC26IsPageDivider(mid)) plan[viewByID[mid]] = @[];
    }
    sPlan = plan;
    CC26SetModulePages(MAX(firstPage, (NSUInteger)1));
    return sPlan;
}

// Columns one landscape page shows: what fits between the safe-area insets, leaving room for
// the page indicator on the right.
static NSUInteger CC26LandscapeColumnsPerPage(UIViewController *ov) {
    CGFloat width = CGRectGetWidth(UIScreen.mainScreen.bounds);
    UIEdgeInsets safe = ov.view.window ? ov.view.window.safeAreaInsets : UIEdgeInsetsZero;
    CGFloat step = gCC26GridCell + gCC26GridGap;
    if (step < 1.0) step = kCC26Step;
    CGFloat usable = width - safe.left - safe.right - 64.0 + gCC26GridGap;
    NSInteger cols = (NSInteger)floor(usable / step);
    return (NSUInteger)MIN(MAX(cols, (NSInteger)4), (NSInteger)12);
}

// Landscape, iOS 26 style: the stock grid scrolls sideways; here it is cut into pages of the
// columns that fit the screen (no module split), stacked one PageSpan() below the other like the
// portrait pages. subview → @[col, page, row]; page dividers map to @[] (hidden).
static NSDictionary<NSValue *, NSArray<NSNumber *> *> *CC26LandscapePlanForPass(CCUIModuleCollectionViewController *col, id layoutView) {
    static NSDictionary<NSValue *, NSArray<NSNumber *> *> *sPlan = nil;
    static BOOL sValid = NO;
    if (sValid) return sPlan;
    sPlan = nil;
    sValid = YES;
    dispatch_async(dispatch_get_main_queue(), ^{ sValid = NO; });
    if (!gPagingEnabled || ![layoutView isKindOfClass:UIView.class]) return nil;

    NSMutableArray<NSValue *> *views = [NSMutableArray array];
    NSMutableArray<NSValue *> *stock = [NSMutableArray array];
    NSMutableArray<NSValue *> *transposed = [NSMutableArray array];
    NSMutableDictionary<NSValue *, NSArray<NSNumber *> *> *plan = [NSMutableDictionary dictionary];
    for (UIView *v in [(UIView *)layoutView subviews]) {
        CCUILayoutRect lr = CC26Orig_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_(
            col, @selector(layoutView:layoutRectForSubview:), layoutView, v);
        if (!lr.size.width || !lr.size.height) continue;
        NSString *mid = CC26MidForSubview(col, v);
        if (CC26IsPageDivider(mid)) { plan[[NSValue valueWithNonretainedObject:v]] = @[]; continue; }
        CC26Rect cr = {lr.origin.x, lr.origin.y, lr.size.width, lr.size.height};
        CC26Rect tr = {lr.origin.y, lr.origin.x, lr.size.height, lr.size.width};
        [views addObject:[NSValue valueWithNonretainedObject:v]];
        [stock addObject:[NSValue value:&cr withObjCType:@encode(CC26Rect)]];
        [transposed addObject:[NSValue value:&tr withObjCType:@encode(CC26Rect)]];
    }
    if (!views.count) return nil;
    UIViewController *ov = CC26OverlayForView(((UIViewController *)col).view);
    NSUInteger perPage = CC26LandscapeColumnsPerPage(ov);
    NSArray<NSNumber *> *breaks = CC26PageBreaks(transposed, perPage);
    for (NSUInteger i = 0; i < views.count; i++) {
        CC26Rect cr = {};
        [stock[i] getValue:&cr];
        NSUInteger column = 0;
        NSUInteger page = CC26PageForStockRow(breaks, cr.c, &column);
        plan[views[i]] = @[@(column), @(page), @(cr.r)];
    }
    sPlan = plan;
    CC26SetModulePages(breaks.count);
    return sPlan;
}

static CCUILayoutRect CC26Hook_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_(CCUIModuleCollectionViewController *self, SEL _cmd, id layoutView, UIView * subview) {
    CCUILayoutRect r = CC26Orig_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_(self, _cmd, layoutView, subview);
    if (CC26IsLandscape()) {
        NSDictionary<NSValue *, NSArray<NSNumber *> *> *plan = CC26LandscapePlanForPass(self, layoutView);
        NSArray<NSNumber *> *p = plan[[NSValue valueWithNonretainedObject:subview]];
        if (!p) return r;
        BOOL divider = p.count == 0;
        if (subview.hidden != divider) subview.hidden = divider;
        if (divider) { r.origin.x = 0; r.origin.y = 0; r.size.width = 1; r.size.height = 1; return r; }
        CGFloat step = gCC26GridCell + gCC26GridGap;
        NSUInteger spanRows = step > 1.0 ? (NSUInteger)llround(PageSpan() / step) : 5;
        if (spanRows < 4) spanRows = 4;
        r.origin.x = p[0].unsignedIntegerValue;
        r.origin.y = p[1].unsignedIntegerValue * spanRows + p[2].unsignedIntegerValue;
        return r;
    }
    gCC26LayoutSawEdit = CC26EditAllowed();
    gCC26LayoutSeen = YES;
    if (!gCC26LayoutSawEdit) {
        CC26RefreshGridConstants();
        NSUInteger spanRows = (NSUInteger)llround(PageSpan() / kCC26Step);
        if (spanRows < kCC26Rows) spanRows = kCC26Rows;
        // Page dividers in Settings ▸ Control Center: each group of modules on its own page.
        NSDictionary<NSValue *, NSArray<NSNumber *> *> *plan = CC26DividerPlanForPass(self, layoutView);
        if (plan) {
            NSArray<NSNumber *> *p = plan[[NSValue valueWithNonretainedObject:subview]];
            BOOL divider = p && p.count == 0;
            if (subview.hidden != divider) subview.hidden = divider;
            if (divider) {
                // Out of the way, at the top of the first page, 1×1 and hidden.
                r.origin.x = 0; r.origin.y = 0; r.size.width = 1; r.size.height = 1;
                return r;
            }
            if (p.count == 3) {
                r.origin.x = p[0].unsignedIntegerValue;
                r.origin.y = p[1].unsignedIntegerValue * spanRows + p[2].unsignedIntegerValue;
                NSUInteger cols = kCC26Cols ? kCC26Cols : 4;
                if (r.size.width > cols) r.size.width = cols;
            }
            return r;
        }
        // Stock layout: rows past the first page go to the next module page, cut so no module
        // is split, and never draw in the spacer under the grid or on the connectivity page.
        NSArray<NSNumber *> *breaks = CC26StockBreaksForPass(self, layoutView);
        if (breaks.count > 1) {
            NSUInteger row = 0;
            NSUInteger page = CC26PageForStockRow(breaks, r.origin.y, &row);
            r.origin.y = page * spanRows + row;
        }
        return r;
    }
    CC26RefreshGridConstants();

    NSDictionary *containers = nil;
    @try { containers = [(id)self valueForKey:@"moduleContainerViewByIdentifier"]; }
    @catch (__unused NSException *e) {}
    NSString *mid = CC26MidForSubview(self, subview);
    if (!mid.length) return r;

    CC26EnsureStore();

    // Migrating needs every module's origin; once per store change and orientation is enough
    // (it used to run for every subview of every layout pass).
    static NSUInteger sMigratedGen = NSUIntegerMax;
    static BOOL sMigratedLandscape = NO;
    static NSUInteger sMigratedCount = 0;
    BOOL landscapeNow = CC26IsLandscape();
    if (sMigratedGen != gCC26StoreGeneration || sMigratedLandscape != landscapeNow ||
        sMigratedCount != containers.count) {
        CC26MigrateMissingOrigins(OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController));
        sMigratedGen = gCC26StoreGeneration;
        sMigratedLandscape = landscapeNow;
        sMigratedCount = containers.count;
    }

    if (!CC26GetOrigin(mid) && !gEditOrigins[mid]) {
        CC26PlaceNewModule(mid, r.size, containers.allKeys);
    }

    NSArray<NSNumber *> *sz = gEditSizes[mid];
    if (sz.count >= 2) {
        CCUILayoutSize s = { sz[0].unsignedIntegerValue, sz[1].unsignedIntegerValue };
        r.size = s;
    }

    BOOL pendingFresh = gCC26PendingResizeID &&
                        [mid isEqualToString:gCC26PendingResizeID] &&
                        gCC26PendingResizeSize.width &&
                        gCC26PendingResizeSize.height &&
                        (CACurrentMediaTime() - gCC26PendingResizeLastTouch) < 3.0;
    if (pendingFresh) {
        r.size = gCC26PendingResizeSize;
    }

    NSArray<NSNumber *> *o = CC26GetOrigin(mid);
    if (!o) o = gEditOrigins[mid];
    if (o.count >= 2) {
        // Saved rows are page * kCC26Rows + row; each page is drawn PageSpan() further down,
        // which is where the vertical paging transform shows it.
        NSUInteger abs = o[1].unsignedIntegerValue;
        NSUInteger page = kCC26Rows ? abs / kCC26Rows : 0;
        NSUInteger row = kCC26Rows ? abs % kCC26Rows : abs;
        NSUInteger spanRows = (NSUInteger)llround(PageSpan() / kCC26Step);
        if (spanRows < kCC26Rows) spanRows = kCC26Rows;
        CCUILayoutPoint p = { o[0].unsignedIntegerValue, page * spanRows + row };
        r.origin = p;
        CC26NoteModulePage(mid, page, containers.allKeys);
    }
    return r;
}

static CCUILayoutSize (*CC26Orig_CCUIModuleCollectionViewController_moduleLayoutSizeForContentModuleContext_forOrientation_)(CCUIModuleCollectionViewController *, SEL, id, NSInteger);
static CCUILayoutSize CC26Hook_CCUIModuleCollectionViewController_moduleLayoutSizeForContentModuleContext_forOrientation_(CCUIModuleCollectionViewController *self, SEL _cmd, id context, NSInteger orientation) {
    CCUILayoutSize s = CC26Orig_CCUIModuleCollectionViewController_moduleLayoutSizeForContentModuleContext_forOrientation_(self, _cmd, context, orientation);
    NSString *mid = nil;
    if ([context respondsToSelector:@selector(moduleIdentifier)]) {
        mid = ((id (*)(id, SEL))objc_msgSend)(context, @selector(moduleIdentifier));
    }
    if (mid.length && s.width && s.height && !CC26IsLandscape()) {
        CC26NoteNativeSize(mid, s);
        CC26NoteModuleSeen(mid, s.width, s.height);
    }
    if (!CC26EditAllowed()) {
        // Edit off: the stock size. Settings ▸ Module Sizes is turned off for now
        // (CC26_SETTINGS_SIZES_ENABLED); its code stays for later.
#if CC26_SETTINGS_SIZES_ENABLED
        NSUInteger w = s.width, h = s.height;
        if (CC26SettingsSize(mid, &w, &h)) s = (CCUILayoutSize){ w, h };
#endif
        return s;
    }
    if (!mid.length) return s;
    CC26EnsureStore();

    NSArray<NSNumber *> *sz = gEditSizes[mid];
    if (sz.count >= 2) {
        CCUILayoutSize ns = { sz[0].unsignedIntegerValue, sz[1].unsignedIntegerValue };
        s = ns;
    }

    BOOL pendingFresh = gCC26PendingResizeID &&
                        [mid isEqualToString:gCC26PendingResizeID] &&
                        gCC26PendingResizeSize.width &&
                        gCC26PendingResizeSize.height &&
                        (CACurrentMediaTime() - gCC26PendingResizeLastTouch) < 3.0;
    if (pendingFresh) {
        s = gCC26PendingResizeSize;
    }
    return s;
}



static void (*CC26Orig_CALayer_addAnimation_forKey_)(CALayer *, SEL, CAAnimation *, NSString *);
static void CC26Hook_CALayer_addAnimation_forKey_(CALayer *self, SEL _cmd, CAAnimation * anim, NSString * key) {
    if (gEditModeActive && CC26ShouldBlockGlyphAnimation((CALayer *)self, anim)) return;
    CC26Orig_CALayer_addAnimation_forKey_(self, _cmd, anim, key);
}



static void CC26DiagWrite(NSString *line) {
    os_log(OS_LOG_DEFAULT, "CC26DIAG %{public}@", line);
    static NSString *path;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ path = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Caches/cc26diag.log"]; });
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
    if (!fh) {
        [NSFileManager.defaultManager createFileAtPath:path contents:nil attributes:nil];
        fh = [NSFileHandle fileHandleForWritingAtPath:path];
    }
    [fh seekToEndOfFile];
    [fh writeData:[[line stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [fh closeFile];
}

static void CC26DiagLayers(CALayer *l, int depth, NSString *mid, BOOL all) {
    if (depth > 9) return;
    for (CALayer *s in l.sublayers) {
        CGFloat half = MIN(s.bounds.size.width, s.bounds.size.height) * 0.5;
        BOOL big = half > 0.5 && s.cornerRadius > half + 0.5;
        if (big || (all && (s.cornerRadius > 20.0 || s.mask))) {
            CGRect f = [s convertRect:s.bounds toLayer:l];
            CC26DiagWrite([NSString stringWithFormat:@"lay %@ d%d %s %@ r=%.1f curve=%@ mask=%d clip=%d big=%d hidden=%d",
                           mid, depth, object_getClassName(s.delegate ? (id)s.delegate : (id)s), NSStringFromCGRect(f),
                           s.cornerRadius, s.cornerCurve, s.mask != nil, s.masksToBounds, big, s.hidden]);
        }
        CC26DiagLayers(s, depth + 1, mid, all);
        if (all) {
            for (id f in s.filters ?: @[]) {
                NSMutableString *line = [NSMutableString stringWithFormat:@"filt %@ d%d %s f=%@", mid, depth, object_getClassName(s), f];
                for (NSString *k in @[@"inputRadius", @"inputCornerRadius", @"inputSize", @"inputRect", @"inputShape", @"inputAmount", @"inputBounds", @"inputScale"]) {
                    id val = nil; @try { val = [f valueForKey:k]; } @catch (__unused NSException *e) {}
                    if (val) [line appendFormat:@" %@=%@", k, val];
                }
                CC26DiagWrite(line);
            }
            if ([s isKindOfClass:CAShapeLayer.class] && ((CAShapeLayer *)s).path) {
                CC26DiagWrite([NSString stringWithFormat:@"shape %@ d%d bounds=%@ pathbox=%@ fill=%@ stroke=%@ usedAsMask=%d",
                               mid, depth, NSStringFromCGRect(s.bounds),
                               NSStringFromCGRect(CGPathGetBoundingBox(((CAShapeLayer *)s).path)),
                               ((CAShapeLayer *)s).fillColor, ((CAShapeLayer *)s).strokeColor, s.superlayer == nil]);
            }
            if (!CATransform3DIsIdentity(s.transform))
                CC26DiagWrite([NSString stringWithFormat:@"xform %@ d%d %s a=%.2f d=%.2f b=%.2f", mid, depth,
                               object_getClassName(s.delegate ?: (id)s), s.transform.m11, s.transform.m22, s.transform.m12]);
            if (s.mask) CC26DiagWrite([NSString stringWithFormat:@"maskof %@ d%d %s mask=%s maskbox=%@", mid, depth,
                               object_getClassName(s.delegate ?: (id)s), object_getClassName(s.mask),
                               [s.mask isKindOfClass:CAShapeLayer.class] && ((CAShapeLayer *)s.mask).path ?
                               NSStringFromCGRect(CGPathGetBoundingBox(((CAShapeLayer *)s.mask).path)) : NSStringFromCGRect(s.mask.frame)]);
        }
    }
}

static void CC26DiagViews(UIView *v, int depth, NSString *mid, UIView *root) {
    if (depth > 6) return;
    for (UIView *s in v.subviews) {
        CC26DiagWrite([NSString stringWithFormat:@"view %@ d%d %s %@ hidden=%d alpha=%.2f",
                       mid, depth, object_getClassName(s), NSStringFromCGRect([s convertRect:s.bounds toView:root]),
                       s.hidden, s.alpha]);
        CC26DiagViews(s, depth + 1, mid, root);
    }
}

static void CC26DiagDump(UIViewController *ov, NSString *why) {
    UIViewController *col = ModuleCollection(ov);
    CATransform3D t = col.view.layer.sublayerTransform;
    CC26DiagWrite([NSString stringWithFormat:@"== %@ %@ page=%ld m42=%.1f pages=%lu edit=%d",
                   why, NSDate.date, (long)gCurrentPage, t.m42, (unsigned long)gCC26ModulePages, gEditModeActive]);
    for (UIViewController *m in ModuleControllers(ov)) {
        NSString *mid = CC26Mid(m);
        if (!mid.length) continue;
        CGRect raw = [m.view convertRect:m.view.bounds toView:ov.view];
        CGRect vis = CC26VisibleFrame(m, ov);
        NSArray *nat = CC26NativeSize(mid);
        NSUInteger ew = 0, eh = 0;
        CC26EffectiveSize(mid, &ew, &eh);
        CC26DiagWrite([NSString stringWithFormat:@"mod %@ %s raw=%@ vis=%@ native=%@ edit=%@ base=%@ eff=%lux%lu r=%.1f resized1x1=%d",
                       mid, object_getClassName(m), NSStringFromCGRect(raw), NSStringFromCGRect(vis),
                       [nat componentsJoinedByString:@"x"], [gEditSizes[mid] componentsJoinedByString:@"x"],
                       [gEditBaseSizes[mid] componentsJoinedByString:@"x"], (unsigned long)ew, (unsigned long)eh,
                       m.view.layer.cornerRadius, CC26WasResizedFromOneByOne(mid)]);
        NSString *lower = mid.lowercaseString;
        BOOL focus = [lower containsString:@"nowplaying"] || [lower containsString:@"weather"] ||
                     [lower containsString:@"bettercc"] || [lower containsString:@"media"];
        CC26DiagLayers(m.view.layer, 0, mid, focus);
        if (focus) {
            int lvl = 0;
            for (UIView *sv = m.view; sv && lvl < 7; sv = sv.superview, lvl++) {
                CALayer *L = sv.layer;
                CGRect mb = CGRectNull;
                if ([L.mask isKindOfClass:CAShapeLayer.class] && ((CAShapeLayer *)L.mask).path) mb = CGPathGetBoundingBox(((CAShapeLayer *)L.mask).path);
                CC26DiagWrite([NSString stringWithFormat:@"up %@ u%d %s b=%@ r=%.1f curve=%@ clip=%d mask=%s maskframe=%@ maskpath=%@ sublayers=%lu xf=%.2f/%.2f/%.2f",
                               mid, lvl, object_getClassName(sv), NSStringFromCGRect(sv.bounds), L.cornerRadius, L.cornerCurve,
                               L.masksToBounds, L.mask ? object_getClassName(L.mask) : "-", NSStringFromCGRect(L.mask.frame),
                               NSStringFromCGRect(mb), (unsigned long)L.sublayers.count, L.transform.m11, L.transform.m12, L.transform.m22]);
                if (sv.maskView) CC26DiagWrite([NSString stringWithFormat:@"up %@ u%d maskView=%s %@", mid, lvl, object_getClassName(sv.maskView), NSStringFromCGRect(sv.maskView.frame)]);
                if (lvl > 0) for (CALayer *sib in L.sublayers) {
                    if (sib == sv.subviews.firstObject.layer) continue;
                    if ([sib isKindOfClass:CAShapeLayer.class] || sib.mask || sib.cornerRadius > 30)
                        CC26DiagWrite([NSString stringWithFormat:@"upsib %@ u%d %s f=%@ r=%.1f mask=%s path=%@", mid, lvl,
                                       object_getClassName(sib.delegate ?: (id)sib), NSStringFromCGRect(sib.frame), sib.cornerRadius,
                                       sib.mask ? object_getClassName(sib.mask) : "-",
                                       [sib isKindOfClass:CAShapeLayer.class] && ((CAShapeLayer *)sib).path ? NSStringFromCGRect(CGPathGetBoundingBox(((CAShapeLayer *)sib).path)) : @"-"]);
                }
            }
        }
        if (focus) {
            NSMutableArray<UIView *> *q = [NSMutableArray arrayWithObject:m.view];
            while (q.count) { UIView *v = q.lastObject; [q removeLastObject]; CC26FixLGShape(v); CC26FixLGShape(v.layer); [q addObjectsFromArray:v.subviews];
                if (strcmp(object_getClassName(v), "LGLiveBackdropView") == 0) {
                    NSMutableString *line = [NSMutableString stringWithFormat:@"lgiv %@ b=%@ r=%.1f", mid, NSStringFromCGRect(v.bounds), v.layer.cornerRadius];
                    for (Class c = v.class; c && c != UIView.class; c = class_getSuperclass(c)) {
                        unsigned int n = 0; Ivar *iv = class_copyIvarList(c, &n);
                        for (unsigned int i = 0; i < n; i++) {
                            const char *t = ivar_getTypeEncoding(iv[i]); const char *nm = ivar_getName(iv[i]);
                            ptrdiff_t off = ivar_getOffset(iv[i]);
                            uint8_t *base = (uint8_t *)(__bridge void *)v;
                            if (!t) continue;
                            if (t[0] == 'd') [line appendFormat:@" %s=%.2f", nm, *(double *)(base + off)];
                            else if (t[0] == 'q' || t[0] == 'Q' || t[0] == 'l') [line appendFormat:@" %s=%ld", nm, *(long *)(base + off)];
                            else if (t[0] == 'B' || t[0] == 'c') [line appendFormat:@" %s=%d", nm, *(char *)(base + off)];
                            else if (strncmp(t, "{CGRect", 7) == 0) [line appendFormat:@" %s=%@", nm, NSStringFromCGRect(*(CGRect *)(base + off))];
                            else if (strncmp(t, "{CGSize", 7) == 0) [line appendFormat:@" %s=%@", nm, NSStringFromCGSize(*(CGSize *)(base + off))];
                            else if (t[0] == '@') { id o = object_getIvar(v, iv[i]); [line appendFormat:@" %s=%s", nm, o ? object_getClassName(o) : "nil"]; }
                        }
                        free(iv);
                    }
                    CC26DiagWrite(line);
                }
            }
        }
        if ([lower containsString:@"weather"] || [lower containsString:@"bettercc"]) CC26DiagViews(m.view, 0, mid, m.view);
    }
}

static void (*CC26Orig_UIViewController_viewDidAppear_)(UIViewController *, SEL, BOOL);
static void CC26Hook_UIViewController_viewDidAppear_(UIViewController *self, SEL _cmd, BOOL animated) {
    CC26Orig_UIViewController_viewDidAppear_(self, _cmd, animated);
    if (!CC26IsControlCenterClass(self)) return;
    if ([NSStringFromClass(self.class) containsString:@"ControlCenterOverlayViewController"]) {
        // TEMP diagnostic: dumps module frames and media/weather layers a few times while open.
        UIViewController *dov = (UIViewController *)self;
        for (int i = 1; i <= 4; i++) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(i * 3.0 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{ if (dov.view.window) CC26DiagDump(dov, @"open"); });
        }
    }
    if (!CC26EditAllowed()) return;
    if ([NSStringFromClass(self.class) containsString:@"ControlCenterOverlayViewController"]) {
        CC26RefreshGridConstants();
        CC26InstallGestures((UIViewController *)self);
    }
}

static void (*CC26Orig_UIViewController_viewDidDisappear_)(UIViewController *, SEL, BOOL);
static void CC26Hook_UIViewController_viewDidDisappear_(UIViewController *self, SEL _cmd, BOOL animated) {
    CC26Orig_UIViewController_viewDidDisappear_(self, _cmd, animated);
    if (CC26IsControlCenterClass(self) &&
        [NSStringFromClass(self.class) containsString:@"ControlCenterOverlayViewController"]) {
        CC26ConnectivityDismissAllDetails();
    }
    if (!gEditModeActive || !CC26IsControlCenterClass(self)) return;
    if ([NSStringFromClass(self.class) containsString:@"ControlCenterOverlayViewController"]) {
        [[CC26EditProxy shared] exitEditOn:(UIViewController *)self];
    }
}


static void (*CC26Orig_CCUIContentModuleContainerViewController_viewDidLayoutSubviews)(CCUIContentModuleContainerViewController *, SEL);
static void CC26Hook_CCUIContentModuleContainerViewController_viewDidLayoutSubviews(CCUIContentModuleContainerViewController *self, SEL _cmd) {
    CC26Orig_CCUIContentModuleContainerViewController_viewDidLayoutSubviews(self, _cmd);
    if (!CC26EditAllowed()) {
        if (CC26IsLandscape()) CC26TearDownModule((UIViewController *)self);
        return;
    }
    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;
    UIViewController *module = (UIViewController *)self;

    CC26ApplyRadiusToModule(module);
    CC26RefreshPresentation(module, ov);
}



static void (*CC26Orig_CCUIButtonModuleView_layoutSubviews)(CCUIButtonModuleView *, SEL);
static void CC26Hook_CCUIButtonModuleView_layoutSubviews(CCUIButtonModuleView *self, SEL _cmd) {
    CC26Orig_CCUIButtonModuleView_layoutSubviews(self, _cmd);
    if (gEnabled) {
        // The active/highlighted fill (e.g. Flashlight turning white) can be added or resized
        // after the container's own layout pass already squared its corners, leaving the stock
        // rounder corner showing through at the four corners for a frame or more. Re-square the
        // container right after every layout of the button itself, in and out of edit mode.
        UIView *moduleContainer = CC26Ancestor((UIView *)(id)self, @"CCUIContentModuleContainerView");
        CC26SquareCornersForContainer(moduleContainer);
    }
    BOOL landscape = CC26IsLandscape();
    if (!landscape && !CC26EditAllowed()) return;
    UIResponder *r = (UIResponder *)(id)self;
    UIViewController *module = nil;
    while (r) {
        if ([r isKindOfClass:UIViewController.class] &&
            [NSStringFromClass(((UIViewController *)r).class) containsString:@"ContentModuleContainerViewController"]) {
            module = (UIViewController *)r;
            break;
        }
        r = r.nextResponder;
    }
    if (!module) return;
    if (landscape) { CC26TearDownModule(module); return; }
    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;

    CC26ApplyRadiusToModule(module);
    CC26RefreshPresentation(module, ov);
}



static void (*CC26Orig_CCUIModularControlCenterOverlayViewController_viewWillTransitionToSize_withTransitionCoordinator_)(CCUIModularControlCenterOverlayViewController *, SEL, CGSize, id<UIViewControllerTransitionCoordinator>);
static void CC26Hook_CCUIModularControlCenterOverlayViewController_viewWillTransitionToSize_withTransitionCoordinator_(CCUIModularControlCenterOverlayViewController *self, SEL _cmd, CGSize size, id<UIViewControllerTransitionCoordinator> coordinator) {
    CC26Orig_CCUIModularControlCenterOverlayViewController_viewWillTransitionToSize_withTransitionCoordinator_(self, _cmd, size, coordinator);
    gCC26RotationQuietUntil = CACurrentMediaTime() + 1.0;
    if (size.width > size.height) {
        UIViewController *ov = (UIViewController *)self;
        if (gEditModeActive) [[CC26EditProxy shared] exitEditOn:ov];
        CC26TearDownAllModules(ov);
    }
    [coordinator animateAlongsideTransition:nil
                                 completion:^(__unused id<UIViewControllerTransitionCoordinatorContext> ctx) {
        CC26ScheduleRotationRefresh();
    }];
}

static void (*CC26Orig_CCUIModularControlCenterOverlayViewController_setPresentationState_)(CCUIModularControlCenterOverlayViewController *, SEL, NSInteger);
static void CC26Hook_CCUIModularControlCenterOverlayViewController_setPresentationState_(CCUIModularControlCenterOverlayViewController *self, SEL _cmd, NSInteger state) {
    CC26Orig_CCUIModularControlCenterOverlayViewController_setPresentationState_(self, _cmd, state);
    if (state == 1) return;
    CC26ConnectivityDismissAllDetails();
    if (!gEditModeActive) return;
    if (CACurrentMediaTime() - gEditModeEnteredAt < 1.0) return;
    [[CC26EditProxy shared] exitEditOn:(UIViewController *)self];
}

static void (*CC26Orig_CCUIModularControlCenterOverlayViewController_viewDidAppear_)(CCUIModularControlCenterOverlayViewController *, SEL, BOOL);
static void CC26Hook_CCUIModularControlCenterOverlayViewController_viewDidAppear_(CCUIModularControlCenterOverlayViewController *self, SEL _cmd, BOOL animated) {
    CC26Orig_CCUIModularControlCenterOverlayViewController_viewDidAppear_(self, _cmd, animated);
    if (CC26IsLandscape()) {
        CC26TearDownAllModules((UIViewController *)self);
        return;
    }
    if (!CC26EditAllowed()) return;
    UIViewController *ov = (UIViewController *)self;
    if (!ov.view) return;

    CC26RefreshGridConstants();

    for (NSInteger i = 0; i < 8; i++) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,
                                     (int64_t)(i * 0.12 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            UIViewController *o2 = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
            if (!o2) return;
            if (!CC26EditAllowed()) return;
            for (UIViewController *m in ModuleControllers(o2)) {
                CC26ApplyRadiusToModule(m);
                CC26RefreshPresentation(m, o2);
            }
        });
    }
}


static void CC26PostRotationRefresh(void) {
    UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
    if (!ov) return;
    if (CC26IsLandscape()) {
        if (gEditModeActive) [[CC26EditProxy shared] exitEditOn:ov];
        CC26TearDownAllModules(ov);
        return;
    }
    if (!CC26EditAllowed()) return;
    CC26RefreshGridConstants();
    for (UIViewController *m in ModuleControllers(ov)) {
        if (!m.view) continue;
        objc_setAssociatedObject(m.view, kCC26LastPresKey,   nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        objc_setAssociatedObject(m.view, kCC26LastRadiusKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        CC26ApplyRadiusToModule(m);
        CC26RefreshPresentation(m, ov);
    }
}

static void CC26ScheduleRotationRefresh(void) {
    gCC26RotationQuietUntil = CACurrentMediaTime() + 1.0;
    static const double delays[] = { 0.0, 0.15, 0.45, 0.90 };
    for (size_t i = 0; i < sizeof(delays) / sizeof(delays[0]); i++) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delays[i] * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ CC26PostRotationRefresh(); });
    }
}

static BOOL CC26ApplyStockLayout(UIViewController *ov);

// Asks every module for its size again and lays the grid out with the layout now in force:
// Control Center keeps the sizes it got, so turning CC26 Edit on or off left stock sizes on
// edited origins (or the other way round) until a respring.
static void CC26RefreshForEditToggle(UIViewController *ov) {
    UIViewController *col = ov ? ModuleCollection(ov) : nil;
    if (!col) return;
    BOOL on = CC26EditAllowed();
    if (on) {
        // Nothing arranged yet: start from the stock layout as it is drawn now.
        CC26EnsureStore();
        BOOL any = NO;
        for (UIViewController *m in ModuleControllers(ov)) if (CC26GetOrigin(CC26Mid(m))) { any = YES; break; }
        if (!any && CC26ApplyStockLayout(ov)) return;
    } else if (gEditModeActive) {
        [[CC26EditProxy shared] exitEditOn:ov];
    }
    for (UIViewController *m in ModuleControllers(ov)) {
        id module = nil, ctx = nil;
        @try { module = [m valueForKey:@"module"]; } @catch (__unused NSException *e) {}
        @try { ctx = [module valueForKey:@"contentModuleContext"]; } @catch (__unused NSException *e) {}
        if ([ctx respondsToSelector:NSSelectorFromString(@"requestLayoutSizeUpdate")]) {
            ((void (*)(id, SEL))objc_msgSend)(ctx, NSSelectorFromString(@"requestLayoutSizeUpdate"));
        }
    }
    if (on) {
        [[CC26EditProxy shared] relayout:ov];
    } else {
        CC26SetModulePages(1);
        [col.view setNeedsLayout];
        [col.view layoutIfNeeded];
    }
    for (UIViewController *m in ModuleControllers(ov)) {
        CC26ApplyRadiusToModule(m);
        CC26RefreshPresentation(m, ov);
    }
}

static void CC26EditReload(__unused CFNotificationCenterRef c,
                          __unused void *o, __unused CFStringRef n,
                          __unused const void *obj,
                          __unused CFDictionaryRef u) {
    // tweak.m reads the new prefs from its own observer; look once both have run.
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *ov = OverlayIn(UIApplication.sharedApplication.keyWindow.rootViewController);
        if (!gEditModeEnabled && gEditModeActive && ov) [[CC26EditProxy shared] exitEditOn:ov];
        if (ov && gCC26LayoutSeen && !CC26IsLandscape() && gCC26LayoutSawEdit != CC26EditAllowed()) {
            CC26RefreshForEditToggle(ov);
        }
    });
}

// "Copy Stock Layout" from the prefs: every module gets the rect stock iOS gives it (recorded
// while CC26 Edit was off), cut into pages so no module is split; a module without a recorded
// rect gets its stock size in the first free cell, in Control Center's order.
static BOOL gCC26PendingStockCopy;

static BOOL CC26ApplyStockLayout(UIViewController *ov) {
    UIViewController *col = ov ? ModuleCollection(ov) : nil;
    NSArray<UIViewController *> *mods = ov ? ModuleControllers(ov) : nil;
    if (!col || !mods.count) return NO;
    if (gEditModeActive) [[CC26EditProxy shared] exitEditOn:ov];

    CC26RefreshGridConstants();
    CC26EnsureStore();
    [gEditOrigins removeAllObjects];
    [gEditSizes removeAllObjects];
    gCC26PendingResizeID = nil;

    UIInterfaceOrientation orient = ov.view.window.windowScene.interfaceOrientation;
    if (orient == UIInterfaceOrientationUnknown) orient = UIInterfaceOrientationPortrait;

    // Control Center's order: the fixed modules (not in the user's list) first, then the
    // user's modules in the order Settings shows them.
    NSMutableDictionary<NSString *, UIViewController *> *byID = [NSMutableDictionary dictionary];
    for (UIViewController *m in mods) {
        NSString *mid = CC26Mid(m);
        if (mid.length) byID[mid] = m;
    }
    NSArray<NSString *> *userOrder = CC26ProviderOrderedIdentifiers() ?: @[];
    NSMutableArray<NSString *> *ids = [NSMutableArray array];
    for (UIViewController *m in mods) {
        NSString *mid = CC26Mid(m);
        if (mid.length && ![userOrder containsObject:mid] && ![ids containsObject:mid]) [ids addObject:mid];
    }
    for (NSString *mid in userOrder) {
        if (byID[mid] && ![ids containsObject:mid]) [ids addObject:mid];
    }

    NSMutableDictionary<NSString *, NSValue *> *sizes = [NSMutableDictionary dictionary];
    for (NSString *mid in ids) {
        UIViewController *m = byID[mid];
        CC26EnsureBaseSize(m, ov);
        id module = nil, ctx = nil;
        @try { module = [m valueForKey:@"module"]; } @catch (__unused NSException *e) {}
        @try { ctx = [module valueForKey:@"contentModuleContext"]; } @catch (__unused NSException *e) {}
        CCUILayoutSize s = {0, 0};
        if (ctx && CC26Orig_CCUIModuleCollectionViewController_moduleLayoutSizeForContentModuleContext_forOrientation_) {
            s = CC26Orig_CCUIModuleCollectionViewController_moduleLayoutSizeForContentModuleContext_forOrientation_(
                    (CCUIModuleCollectionViewController *)col,
                    @selector(moduleLayoutSizeForContentModuleContext:forOrientation:), ctx, (NSInteger)orient);
        }
        NSUInteger w = s.width, h = s.height;
        if (w == 0 || h == 0) CC26EffectiveSize(mid, &w, &h);
        CCUILayoutSize fs = {MAX((NSUInteger)1, MIN(w, kCC26Cols)), MAX((NSUInteger)1, MIN(h, kCC26Rows))};
        sizes[mid] = [NSValue value:&fs withObjCType:@encode(CCUILayoutSize)];
    }

    // Stock rects recorded while Edit was off, kept only when they still match the stock size
    // and do not overlap one another.
    NSMutableDictionary<NSString *, NSValue *> *stock = [NSMutableDictionary dictionary];
    for (NSString *mid in ids) {
        NSArray<NSNumber *> *a = gCC26StockRects[mid];
        if (a.count < 4) continue;
        CCUILayoutSize fs = {};
        [sizes[mid] getValue:&fs];
        CC26Rect t = {a[0].unsignedIntegerValue, a[1].unsignedIntegerValue,
                      a[2].unsignedIntegerValue, a[3].unsignedIntegerValue};
        if (t.w != fs.width || t.h != fs.height || t.c + t.w > kCC26Cols) continue;
        BOOL clash = NO;
        for (NSValue *v in stock.allValues) {
            CC26Rect o = {};
            [v getValue:&o];
            if (CC26RectsOverlap(t, o)) { clash = YES; break; }
        }
        if (!clash) stock[mid] = [NSValue value:&t withObjCType:@encode(CC26Rect)];
    }

    NSMutableArray<NSValue *> *placed = [NSMutableArray array];   // CC26Rect, r = page * kCC26Rows + row
    NSArray<NSNumber *> *breaks = CC26PageBreaks(stock.allValues, CC26RowsPerPage(ov));
    for (NSString *mid in ids) {
        NSValue *sv = stock[mid];
        if (!sv) continue;
        CC26Rect t = {};
        [sv getValue:&t];
        NSUInteger row = 0;
        NSUInteger page = CC26PageForStockRow(breaks, t.r, &row);
        if (row + t.h > kCC26Rows) { [stock removeObjectForKey:mid]; continue; }
        CC26Rect e = {t.c, page * kCC26Rows + row, t.w, t.h};
        [placed addObject:[NSValue value:&e withObjCType:@encode(CC26Rect)]];
        CC26SetOrigin(mid, @[@(e.c), @(e.r)]);
    }

    NSUInteger perPage = CC26RowsPerPage(ov);
    for (NSString *mid in ids) {
        if (stock[mid]) continue;
        CCUILayoutSize fs = {};
        [sizes[mid] getValue:&fs];
        NSUInteger w = fs.width, h = MIN(fs.height, perPage);
        BOOL found = NO;
        for (NSUInteger page = 0; page < 4 && !found; page++) {
            for (NSUInteger r = 0; r + h <= perPage && !found; r++) {
                for (NSUInteger c = 0; c + w <= kCC26Cols; c++) {
                    CC26Rect t = {c, page * kCC26Rows + r, w, h};
                    BOOL ok = YES;
                    for (NSValue *v in placed) {
                        CC26Rect o = {};
                        [v getValue:&o];
                        if (CC26RectsOverlap(t, o)) { ok = NO; break; }
                    }
                    if (!ok) continue;
                    [placed addObject:[NSValue value:&t withObjCType:@encode(CC26Rect)]];
                    CC26SetOrigin(mid, @[@(c), @(t.r)]);
                    found = YES;
                    break;
                }
            }
        }
    }

    for (NSString *mid in ids) {
        CCUILayoutSize fs = {};
        [sizes[mid] getValue:&fs];
        NSUInteger bw = 1, bh = 1;
        NSArray<NSNumber *> *base = gEditBaseSizes[mid];
        if (base.count >= 2) { bw = base[0].unsignedIntegerValue; bh = base[1].unsignedIntegerValue; }
        if (fs.width != bw || fs.height != bh) gEditSizes[mid] = @[@(fs.width), @(fs.height)];
    }
    CC26SaveStore();

    for (NSString *mid in ids) {
        UIViewController *m = byID[mid];
        id module = nil, ctx = nil;
        @try { module = [m valueForKey:@"module"]; } @catch (__unused NSException *e) {}
        @try { ctx = [module valueForKey:@"contentModuleContext"]; } @catch (__unused NSException *e) {}
        if ([ctx respondsToSelector:NSSelectorFromString(@"requestLayoutSizeUpdate")]) {
            ((void (*)(id, SEL))objc_msgSend)(ctx, NSSelectorFromString(@"requestLayoutSizeUpdate"));
        }
    }
    [[CC26EditProxy shared] relayout:ov];
    for (UIViewController *m in ModuleControllers(ov)) {
        CC26ApplyRadiusToModule(m);
        CC26RefreshPresentation(m, ov);
    }
    os_log(OS_LOG_DEFAULT, "CC26 copied stock layout: %lu modules, %lu from recorded stock rects",
           (unsigned long)ids.count, (unsigned long)stock.count);
    return YES;
}

__attribute__((constructor)) static void CC26Ctor_CC26Edit(void) {
    @autoreleasepool {
        CC26InitCachedClasses();
        CC26InstallHooks_CC26Edit__ungrouped();
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                        NULL, CC26EditReload,
                                        (__bridge CFStringRef)kReloadNotification,
                                        NULL,
                                        CFNotificationSuspensionBehaviorDeliverImmediately);

    }
}

static void CC26InstallHooks_CC26Edit__ungrouped(void) {
    CC26HookMessage(objc_getClass("CCUIModuleCollectionViewController"), @selector(layoutView:layoutRectForSubview:), (IMP)CC26Hook_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_, (IMP *)&CC26Orig_CCUIModuleCollectionViewController_layoutView_layoutRectForSubview_);
    CC26HookMessage(objc_getClass("CCUIModuleCollectionViewController"), @selector(moduleLayoutSizeForContentModuleContext:forOrientation:), (IMP)CC26Hook_CCUIModuleCollectionViewController_moduleLayoutSizeForContentModuleContext_forOrientation_, (IMP *)&CC26Orig_CCUIModuleCollectionViewController_moduleLayoutSizeForContentModuleContext_forOrientation_);
    CC26HookMessage(objc_getClass("CALayer"), @selector(addAnimation:forKey:), (IMP)CC26Hook_CALayer_addAnimation_forKey_, (IMP *)&CC26Orig_CALayer_addAnimation_forKey_);
    CC26HookMessage(objc_getClass("UIViewController"), @selector(viewDidAppear:), (IMP)CC26Hook_UIViewController_viewDidAppear_, (IMP *)&CC26Orig_UIViewController_viewDidAppear_);
    CC26HookMessage(objc_getClass("UIViewController"), @selector(viewDidDisappear:), (IMP)CC26Hook_UIViewController_viewDidDisappear_, (IMP *)&CC26Orig_UIViewController_viewDidDisappear_);
    CC26HookMessage(objc_getClass("CCUIContentModuleContainerViewController"), @selector(viewDidLayoutSubviews), (IMP)CC26Hook_CCUIContentModuleContainerViewController_viewDidLayoutSubviews, (IMP *)&CC26Orig_CCUIContentModuleContainerViewController_viewDidLayoutSubviews);
    CC26HookMessage(objc_getClass("CCUIButtonModuleView"), @selector(layoutSubviews), (IMP)CC26Hook_CCUIButtonModuleView_layoutSubviews, (IMP *)&CC26Orig_CCUIButtonModuleView_layoutSubviews);
    CC26HookMessage(objc_getClass("CCUIModularControlCenterOverlayViewController"), @selector(viewWillTransitionToSize:withTransitionCoordinator:), (IMP)CC26Hook_CCUIModularControlCenterOverlayViewController_viewWillTransitionToSize_withTransitionCoordinator_, (IMP *)&CC26Orig_CCUIModularControlCenterOverlayViewController_viewWillTransitionToSize_withTransitionCoordinator_);
    CC26HookMessage(objc_getClass("CCUIModularControlCenterOverlayViewController"), @selector(setPresentationState:), (IMP)CC26Hook_CCUIModularControlCenterOverlayViewController_setPresentationState_, (IMP *)&CC26Orig_CCUIModularControlCenterOverlayViewController_setPresentationState_);
    CC26HookMessage(objc_getClass("CCUIModularControlCenterOverlayViewController"), @selector(viewDidAppear:), (IMP)CC26Hook_CCUIModularControlCenterOverlayViewController_viewDidAppear_, (IMP *)&CC26Orig_CCUIModularControlCenterOverlayViewController_viewDidAppear_);
}
