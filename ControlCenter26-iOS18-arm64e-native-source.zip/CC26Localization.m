#import "CC26.h"

// System strings: /System/Library never moves, on roothide or rootless.
NSString *CC26SystemString(NSString *bundlePath, NSString *table, NSString *key, NSString *fallback) {
    static NSMutableDictionary<NSString *, NSBundle *> *cache;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ cache = [NSMutableDictionary dictionary]; });
    NSBundle *bundle;
    @synchronized (cache) {
        bundle = cache[bundlePath];
        if (!bundle) {
            bundle = [NSBundle bundleWithPath:bundlePath];
            if (bundle) cache[bundlePath] = bundle;
        }
    }
    if (!bundle || !key.length) return fallback;
    static NSString *const missing = @"\001CC26_MISSING";
    NSString *s = [bundle localizedStringForKey:key value:missing table:table];
    if (!s.length || [s isEqualToString:missing] || [s isEqualToString:key]) return fallback;
    return s;
}

// The tweak's own strings, in the package's Localization.bundle, found at run time
// under the bootstrap's root (jbroot on roothide, /var/jb on rootless).
static NSBundle *CC26TweakBundle(void) {
    static NSBundle *bundle;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *path = ApelinBootstrapPath(@"/Library/Application Support/ControlCenter26/Localization.bundle");
        if (path) bundle = [NSBundle bundleWithPath:path];
    });
    return bundle;
}

NSString *CC26LocalizedString(NSString *key, NSString *fallback) {
    NSBundle *bundle = CC26TweakBundle();
    if (!bundle) return fallback;
    NSString *s = [bundle localizedStringForKey:key value:fallback table:nil];
    return s.length ? s : fallback;
}
