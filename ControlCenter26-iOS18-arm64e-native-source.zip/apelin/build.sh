#!/bin/sh
# Apelin build for ControlCenter26: compiles the tweak, the preference bundle and the
# Control Center module bundles with the on-device toolchain and writes one .deb.
# Run through apelin_project_build; it sets the variables checked below.
set -eu
: "${APELIN_PACKAGE_DIR:?run this through apelin_project_build}"
: "${APELIN_PROJECT_ROOT:?}" "${APELIN_BOOTSTRAP:?}" "${APELIN_ARCHITECTURE:?}"
: "${APELIN_BUILD_ID:?}" "${TMPDIR:?}"
: "${APELIN_PREFIX?}" # set, and empty on roothide
stage="$(mktemp -d "${TMPDIR:?}stage.XXXXXX")"
obj="$(mktemp -d "${TMPDIR:?}obj.XXXXXX")"
trap 'rm -rf -- "${stage:?}" "${obj:?}"' EXIT

PKG_ID="$(sed -n 's/^Package: *//p' control)"
: "${PKG_ID:?control has no Package}"

case "$APELIN_BOOTSTRAP" in
    rootless) ARCHS="arm64e"; BOOT_DEF="-DAPELIN_BOOTSTRAP_ROOTLESS=1"; RPATH="-Wl,-rpath,/var/jb/Library/Frameworks" ;;
    *) echo "This iOS 18 build supports rootless arm64e only" >&2; exit 1 ;;
esac
if [ "$APELIN_ARCHITECTURE" != "iphoneos-arm64" ]; then
    echo "Expected package architecture iphoneos-arm64, got: $APELIN_ARCHITECTURE" >&2
    exit 1
fi
if [ "${APELIN_CONFIGURATION:-debug}" = release ]; then OPT="-O2"; else OPT="-O0"; fi

CFLAGS="-fobjc-arc -fmodules -g $OPT -miphoneos-version-min=18.0 -Iapelin/support/include \
 $BOOT_DEF -DAPELIN_PACKAGE_ID=\"$PKG_ID\" -DAPELIN_BUILD_ID=\"$APELIN_BUILD_ID\" \
 -Wno-unused-function -Wno-unused-variable -Wno-deprecated-declarations"

# build <out> <ldflags> <extra cflags> <sources...>: one Mach-O per arch, joined with lipo.
build() {
    out="$1"; ldflags="$2"; extra="$3"; shift 3
    slices=""
    for arch in $ARCHS; do
        objs=""
        for src in "$@"; do
            o="$obj/$(basename "$out")-$arch-$(echo "$src" | tr '/.' '__').o"
            # shellcheck disable=SC2086
            clang -arch "$arch" $CFLAGS $extra -c "$src" -o "$o"
            objs="$objs $o"
        done
        # shellcheck disable=SC2086
            clang -arch "$arch" -miphoneos-version-min=18.0 $objs $ldflags -o "$obj/$(basename "$out").$arch"
        slices="$slices $obj/$(basename "$out").$arch"
    done
    # shellcheck disable=SC2086
    lipo -create $slices -output "$out"
    ldid -S "$out"
}

P="$stage$APELIN_PREFIX"
LIB="$P/Library"

# 1. Tweak (SpringBoard)
mkdir -p "$LIB/MobileSubstrate/DynamicLibraries"
build "$LIB/MobileSubstrate/DynamicLibraries/ControlCenter26.dylib" \
    "-dynamiclib -Lapelin/support/lib/$APELIN_BOOTSTRAP -lsubstrate $RPATH \
     -framework Foundation -framework UIKit -framework QuartzCore -framework CoreGraphics \
     -framework CFNetwork -framework MediaPlayer -framework AVFoundation \
     -install_name /Library/MobileSubstrate/DynamicLibraries/ControlCenter26.dylib" "" \
    tweak.m CC26.m CC26Anim.m CC26Indicator.m CC26Media.m CC26Coordinator.m CC26Design.m \
    CC26Edit.m CC26LIQ.m CC26Connectivity.m CC26ConnectivityDetail.m CC26SliderStretch.m \
    CC26Localization.m CC26Sizes.m
cp ControlCenter26.plist "$LIB/MobileSubstrate/DynamicLibraries/ControlCenter26.plist"

# Settings ▸ Control Center: page headers in the included list (com.apple.Preferences only).
build "$LIB/MobileSubstrate/DynamicLibraries/ControlCenter26Settings.dylib" \
    "-dynamiclib -Lapelin/support/lib/$APELIN_BOOTSTRAP -lsubstrate $RPATH \
     -framework Foundation -framework UIKit \
     -install_name /Library/MobileSubstrate/DynamicLibraries/ControlCenter26Settings.dylib" "" \
    CC26Settings.m
cp ControlCenter26Settings.plist "$LIB/MobileSubstrate/DynamicLibraries/ControlCenter26Settings.plist"

# Tweak resources: private symbols and the tweak's own strings.
mkdir -p "$LIB/Application Support/ControlCenter26"
cp -R "layout/Library/Application Support/ControlCenter26/." "$LIB/Application Support/ControlCenter26/"
mkdir -p "$LIB/Application Support/ControlCenter26/Localization.bundle"
cp -R Resources/Localization/. "$LIB/Application Support/ControlCenter26/Localization.bundle/"

# 2. Preference bundle
PB="$LIB/PreferenceBundles/ControlCenter26Prefs.bundle"
mkdir -p "$PB" "$LIB/PreferenceLoader/Preferences"
build "$PB/ControlCenter26Prefs" \
    "-bundle -Fapelin/support/stubs -framework Preferences -framework Foundation -framework UIKit" \
    "-Iprefs" prefs/ControlCenter26RootListController.m prefs/ControlCenter26SizesController.m
for f in prefs/Resources/*; do
    case "$(basename "$f")" in H|ControlCenter26Prefs.plist) ;; *) cp -R "$f" "$PB/" ;; esac
done
cp prefs/Resources/ControlCenter26Prefs.plist "$LIB/PreferenceLoader/Preferences/ControlCenter26Prefs.plist"

# 3. Control Center module bundles (loaded by CCSupport), one per radio.
for pair in "0 WiFi WiFi" "1 Bluetooth Bluetooth" "2 Airplane Airplane" "3 Cellular Cellular" \
            "4 AirDrop Airdrop" "5 Hotspot Hotspot"; do
    set -- $pair
    kind="$1"; name="$2"; res="$3"
    MB="$LIB/ControlCenter/Bundles/CC26${name}Module.bundle"
    mkdir -p "$MB"
    build "$MB/CC26${name}Module" "-bundle -framework Foundation -framework UIKit" \
        "-DCC26_KIND=$kind -DCC26_MODULE_CLASS=CC26${name}Module -DCC26_VC_CLASS=CC26${name}ViewController" \
        modulebundles/Module.m
    cp -R "modulebundles/Resources/$res/." "$MB/"
    rm -f -- "${MB:?}/H"
done

# Page dividers: "Page 2" to "Page 4", dragged in Settings ▸ Control Center to start a new page.
for n in 2 3 4; do
    MB="$LIB/ControlCenter/Bundles/CC26Page${n}Module.bundle"
    mkdir -p "$MB"
    build "$MB/CC26Page${n}Module" "-bundle -framework Foundation -framework UIKit" \
        "-DCC26_MODULE_CLASS=CC26Page${n}Module -DCC26_VC_CLASS=CC26Page${n}ViewController" \
        modulebundles/PageBreak.m
    cp -R "modulebundles/Resources/Page${n}/." "$MB/"
done

# 4. Control file from the repository's, with this target's architecture.
mkdir -p "$stage/DEBIAN"
grep -v '^Architecture:' control | sed '/^$/d' > "$stage/DEBIAN/control"
echo "Architecture: $APELIN_ARCHITECTURE" >> "$stage/DEBIAN/control"

find "$stage" -name .DS_Store -exec rm -f {} +
dpkg-deb -b --root-owner-group "$stage" "$APELIN_PACKAGE_DIR/"
