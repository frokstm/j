// SPDX-License-Identifier: MIT
//
// ApelinBootstrap.h — spell a bootstrap path the way compiled code must open
// it, on both roothide and rootless, from one source (Apelin's helper).
// A bootstrap path such as /Library/... is under /var/jb on rootless and under
// the randomly named jbroot this image was loaded from on roothide. System
// paths (/System, /var/mobile/...) are already real: never pass them here.
// The build defines APELIN_BOOTSTRAP_ROOTHIDE or APELIN_BOOTSTRAP_ROOTLESS.
#pragma once

#import <Foundation/Foundation.h>
#import <dlfcn.h>

// The bootstrap's root as the kernel spells it, or nil (roothide, no
// .jbroot- ancestor). Cached for the process; never persist it.
static inline NSString *_Nullable ApelinBootstrapRoot(void) {
#ifdef APELIN_BOOTSTRAP_ROOTHIDE
    static NSString *root;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        static const char anchor = 0;
        Dl_info info;
        if (dladdr(&anchor, &info) == 0 || info.dli_fname == NULL) {
            return;
        }
        NSArray<NSString *> *parts =
            [@(info.dli_fname) componentsSeparatedByString:@"/"];
        for (NSUInteger i = 0; i < parts.count; i++) {
            if ([parts[i] hasPrefix:@".jbroot-"]) {
                root = [[parts subarrayWithRange:NSMakeRange(0, i + 1)]
                    componentsJoinedByString:@"/"];
                break;
            }
        }
    });
    return root;
#else
    return @"/var/jb";
#endif
}

// A bootstrap path (/Library/..., /usr/bin/x) as code must open it.
// Nil only when the roothide root cannot be found; handle it.
static inline NSString *_Nullable ApelinBootstrapPath(NSString *_Nonnull path) {
    NSString *root = ApelinBootstrapRoot();
    return root == nil ? nil : [root stringByAppendingString:path];
}
