# ControlCenter26 — Apelin notes

## Build
- Plain Objective-C (no Theos/Logos). Hooks use `MSHookMessageEx` via `CC26HookMessage()` in `CC26.h`.
- `apelin/build.sh` (declared in `apelin-project.json` → `external`) builds everything; run it only through `apelin_project_build`.
  - Tweak `ControlCenter26.dylib` from `tweak.m CC26*.m` → `Library/MobileSubstrate/DynamicLibraries/`.
  - Prefs bundle `prefs/` → `Library/PreferenceBundles/ControlCenter26Prefs.bundle` + PreferenceLoader plist.
  - Six CCSupport module bundles from `modulebundles/Module.m` → `Library/ControlCenter/Bundles/`.
- This build targets rootless arm64e only for iOS 18 and Dopamine. Use the native macOS/Xcode workflow in `.github/workflows/build-arm64e.yml`; do not use WSL/Allemande to produce the arm64e binaries. Signed with `ldid -S`. Control file from `control`.
- Support headers/stubs: `apelin/support/` (substrate, Preferences, `ApelinBootstrap.h`).
- Load marker: `ApelinLoaded <build id>` logged in `tweak.m`'s constructor (subsystem `com.controlcenter26`).

## Localization
- System strings: `CC26ConnStr`, `CC26MediaStr`, `CC26InfoStr` (`CC26.h`) read Apple's tables under `/System/Library` with an English fallback.
- Own strings: `CC26L(key, english)` reads `Resources/Localization/<lang>.lproj/Localizable.strings`, packaged as
  `Library/Application Support/ControlCenter26/Localization.bundle`, found at run time with `ApelinBootstrapPath()`.
- Prefs: `prefs/Resources/<lang>.lproj/Localizable.strings`, keyed by Root.plist's English text; "General" comes from Settings.
- Languages: en, ja, zh-Hans, zh-Hant.

## Edit-mode sizes
- `CC26Edit.m`: `CC26SizeAllowed` lists allowed sizes (up to 4 wide). Resizing past the right edge moves the origin left
  (preview and `commitResize:`) instead of trimming the width. Sizes persist in `com.controlcenter26.preferences` → `EditGridSizes`.

## Test
- Install with `apelin_package_install`, confirm with `apelin_package_confirm_loaded` target SpringBoard, `respring: true`.
- Depends on ellekit/mobilesubstrate, CCSupport (`com.opa334.ccsupport`), PreferenceLoader.
